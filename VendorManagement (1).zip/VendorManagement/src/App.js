import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./assets/css/main.css";
import "./assets/css/style.css";
import "./assets/css/rtl.css";
import "./assets/vendor/themify-icons/themify-icons.css";
import "./assets/vendor/fontawesome/css/font-awesome.min.css";
import "./assets/vendor/metisMenu/metisMenu.css";

import Login from "./pages/Login";
import AllVendors from "./pages/AllVendors";
import Blacklisted from "./pages/Blacklisted";
import ApprovedRequests from "./pages/ApprovedRequests";
import RejectedRequests from "./pages/RejectedRequests";
import PendingRequests from "./pages/PendingRequests";
import ActivityLog from "./pages/ActivityLog";
import AddNewVendor from "./pages/AddNewVendor";
import ViewVendor from "./pages/ViewVendor";
import UpdateVendor from "./pages/UpdateVendor";
import RequestDetails from "./pages/RequestDetails";
import DashboardPage from "./pages/Dahboard";
import PreApprovedDetails from "./components/Requests/PreApprovedRequestDetails";
import PreApprovedRequests from "./pages/preApprovedRequests";
import PendingRequestDetails from "./pages/PendingRequestDetails";
import { ProtectedRoutes } from "./ProtectedRoutes";


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path={"/"} element={<Login />} />
        <Route path="/vendormanagement/dashboard" element={
        <ProtectedRoutes>
        <DashboardPage />
        </ProtectedRoutes>
        } />
        <Route path="/vendormanagement/all-vendors" element={
          <ProtectedRoutes>
        <AllVendors />
        </ProtectedRoutes>
        } />
        <Route
          path={"/vendormanagement/blacklisted-vendors"}
          element={
          <ProtectedRoutes>
          <Blacklisted />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendormanagement/approved-requests"}
          element={
            <ProtectedRoutes>
          <ApprovedRequests />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendormanagement/rejected-requests"}
          element={
            <ProtectedRoutes>
          <RejectedRequests />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendormanagement/pending-requests"}
          element={
            <ProtectedRoutes>
          <PendingRequests />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendormanagement/activity-log"}
          element={
            <ProtectedRoutes>
          <ActivityLog />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendormanagement/add-vendor"}
          element={
           <ProtectedRoutes>
          <AddNewVendor />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendormanagement/view-vendor/:id"}
          element={
            <ProtectedRoutes>
          <ViewVendor />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendormanagement/pending-view-vendor/:id"}
          element={
            <ProtectedRoutes>
          <PendingRequestDetails />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendormanagement/update-vendor/:id"}
          element={
            <ProtectedRoutes>
          <UpdateVendor />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendormanagement/request-details/:id"}
          element={
          <ProtectedRoutes>
           <RequestDetails />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendorManagement/preapproved-requests"}
          element={
          <ProtectedRoutes>
           <PreApprovedRequests />
          </ProtectedRoutes>
        }
        />
        <Route
          path={"/vendormanagement/pre-request-details/:id"}
          element={
            <ProtectedRoutes>
              <PreApprovedDetails />
            </ProtectedRoutes>  
        }
        />
        <Route path="*" element={<Login />} />
      </Routes>
    </BrowserRouter>
  );
}


export default App;
