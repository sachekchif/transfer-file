import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';

export const ProtectedRoutes = ({ children }) => {
  const location = useLocation();
  const token = sessionStorage.getItem('role');

  // Check if the user is logged in
  const isLoggedIn = !!token;

  if (!isLoggedIn) {
    // If the user is not logged in, redirect to the login page
    return <Navigate to="/" state={{ from: location }} replace />;
  }

  // If the user is logged in, render the children (all other routes)
  return children;
};
