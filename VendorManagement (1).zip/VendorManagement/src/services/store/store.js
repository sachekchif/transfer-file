import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from 'redux';
import { setupListeners } from "@reduxjs/toolkit/query";
import thunkMiddleWare from "redux-thunk";
import vendorsReducer from "./reducer/vendorsReducer";
import getApprovedVendorsReducer from "../Requests/getApprovedVendors";
import getVendorByIdReducer from "../Requests/getVendorByIdReducer";
import getRejectedVendorsReducer from "../Requests/getRejectedVendors";
import getPendingVendorsReducer  from "../Requests/getPendingRequests";
import getAllVendorsReducer from "../Requests/getAllVendors";



const middleware = [
    thunkMiddleWare,
    
  ];
  
  // const rootReducer = combineReducers({
  //   account:vendorsReducer
  // });
  
export const store = configureStore({
    reducer:{
      vendorsReducer,
      getApprovedVendorsReducer,
      getVendorByIdReducer,
      getRejectedVendorsReducer,
      getPendingVendorsReducer,
      getAllVendorsReducer
    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(middleware),
    devTools:true
  });
  
  setupListeners(store.dispatch);
  
  