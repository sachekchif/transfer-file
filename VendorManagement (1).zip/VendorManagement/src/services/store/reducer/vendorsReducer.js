import { createSlice , createAsyncThunk} from "@reduxjs/toolkit"
import axios from "axios";
import { baseUrl, dataSlice,http } from "../../../Utils/helper";




const initialState = {
    error: "",
    loading: false,
    error2: "",
    data: [],
    isSuccessful: false,
  };
   
  export const getVendorLists = createAsyncThunk("expense/getExpenseByReferenceId", async (id) => {
    //   console.log(">>>>>>>>rest", rest);
    try {
        // console.log(">>>>>>>> from activity", rest);
        const response = await axios.post(
          `${baseUrl}staff/vendor/details`,
            {id},
          {
            headers: {
              //"ngrok-skip-browser-warning": "yes",
              "Content-Type": "application/json",
            },
          }
        );
    
        // console.log(">>>>>>>>>>vendorsList", response.data.data);
    
        if (response.data.statusCode === "96") {
        //   Swal.fire("Sorry, Something went wrong", "error").then((result) => {
        //     if (result.isConfirmed) {
        //       dispatch(getActivities(rest?.newData.ExpenseRequestID));
        //       reset();
        //     }
        //   });
          return response.data.data;
        }
    
        if (response.data.statusCode === "00") {
        //   Swal.fire("Comment Submitted Successfully", "success").then((result) => {
        //     if (result.isConfirmed) {
        //       dispatch(getActivities(id));
        //       rest.Decision === "Approved"
        //         ? toggleApprovalModal()
        //         : toggleRejectionModal();
        //       reset();
        //     }
        //   });
        console.log(response.data.data)
          return response.data.data;
        }
      } catch (e) {
        return e.response.data;
      }
    });



   const getAllVendorLists = dataSlice(
    "submitActivity",
    initialState,
    {},
    getVendorLists
   );
  

  
  export default getAllVendorLists.reducer