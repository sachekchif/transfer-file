import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl, dataSlice, http, postData } from "../../Utils/helper";
import Swal from "sweetalert2";


const initialState ={
    error:"",
    loading:false,
    error2:"",
    data:[],
    isSuccessful:false
}

export const getActivities = createAsyncThunk("getActivities", async (id) => {
    // console.log(">>>>>>>>id for activities", id)
  try {
    const response = await axios.post(
      `${baseUrl}/expense/activities`,
      { id },
      {
        headers: {
          //"ngrok-skip-browser-warning": "yes",
          "Content-Type": "application/json",
        },
      }
    );
    // console.log(">>>>>> Activities", response.data.data);   

    if (response.data.statusCode === "00") {
      return response.data.data;
    }
  } catch (e) {
    return e.response.data;
  }
});


const getApprovedVendors = dataSlice(
    "getApprovedRequests",
    initialState,
    {},
    getActivities
  );

  export default getApprovedVendors.reducer;