import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../Utils/helper";
import Swal from "sweetalert2";

const initialState = {
  error: "",
  loading: false,
  error2: "",
  data: [],
//   isSuccessful: false,
};
// const getAllApprovedVendors = async () => {
//     try {
//       const token = localStorage.getItem("token");
//       fetch(`${baseUrl}/staff/vendor/active/list`, {
//         method: "GET",
//         mode: "cors",
//         headers: {
//           "Content-Type": "application/json",
//         },
//       }).then(async (response) => {
//         let res = await response.json();

//         if (res.responseCode === "00") {
//            return res.data
//         } else {
//           Swal.fire("Something Went Wrong!", "", "error");
//         }
//       });
//     } catch (error) {
//       Swal.fire("Something Went Wrong!", "", "error");
//       return e.response.data
//     }
//   };

export const getApprovedVendors = createAsyncThunk(
  "vendor/getApprovedVendors",
  
  async () => {
    console.log("hi there")
    try {
      const token = localStorage.getItem("token");
      fetch(`${baseUrl}/staff/vendor/active/list`, {
        method: "GET",
        mode: "cors",
        headers: {
          "Content-Type": "application/json",
        },
      }).then(async (response) => {
        let res = await response.json();
        if (res.responseCode === "00") {
          
          return res.data;
        } else {
          Swal.fire("Something Went Wrong!", "", "error");
        }
        
      });
      
    } catch (e) {
      Swal.fire("Something Went Wrong!", "", "error");
      return e.response.data;
    }
  }
);

const getApprovedVendorsSlice = createSlice({
  name: "vendors/getVendorsByStaff",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(getApprovedVendors.rejected, (state, action) => {
      state.error = action.payload;
      state.error2 = action.error.name;
      state.loading = false;
      state.isSuccessful = false;
    });
    builder.addCase(getApprovedVendors.fulfilled, (state, action) => {
      state.loading = true;
      state.data = action.payload;
      state.loading = false;
      state.isSuccessful = true;
      state.error = "";
    });
    builder.addCase(getApprovedVendors.pending, (state, action) => {
      state.loading = true;
      state.error = action.payload;
    });
  },
});

export default getApprovedVendorsSlice.reducer;
