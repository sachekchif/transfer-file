import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import Swal from "sweetalert2";
import {getApprovedVendors} from "./getApprovedVendors";


initialState = {
    error:"",
    loading:false,
    error2:"",
    data:{},
    isSuccessful:false,
}


export const approveVendor = createAsyncThunk(
    "approveVendor",
    async (newData, {rejectWithValue})=>{
        const {dispatch, toggleApprovalModal, toggleRejectionModal, reset, ...rest} = newData;
        try {
            const response = await  axios.post(`${baseUrl}staff/vendor/approval`,
            rest
            );
            if(response.statusCode == "96"){
                Swal.fire({
                    icon:"error",
                    title:"Something went wrong",
                    text:"Vendor cannot be raised twice"
                })
                if(response.status = 201){
                    Swal.fire("Successful", "Successful", "success").then(
                        (result)=>{
                            if(result.isConfirmed){
                                dispatch(getApprovedVendors());
                                reset.status == "Approved" ? toggleApprovalModal(): toggleRejectionModal()
                                reset();
                            }
                        }
                    )
                }
                return response.data
            }
            return response.data
        } catch (error) {
            return rejectWithValue(error.response.data)
        }
    }
)


const approveVendorSlice = createSlice({
    name:"vendor",
    initialState,
    reducers:{},
    extraReducers:(builder)=>{
        builder.addCase(approveVendor.rejected, (state, action)=>{
            state.error = action.payload;
            state.error2 = action.error.name;
            state.loading=false;
            state.isSuccessful=false;
        })
        builder.addCase(approveVendor.fulfilled, (state, action)=>{
            state.loading=true;
            state.data=action.payload;
            state.laoding = false;
            state.isSuccessful =true;
            state.error ="";


        })
        builder.addCase(approveVendor.pending, (state, action)=>{
            state.loading=true;
            state.error = action.payload
        })
    }
})

export default approveVendorSlice.reducer