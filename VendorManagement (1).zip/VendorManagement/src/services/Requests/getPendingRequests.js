import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../Utils/helper";

const initialState={
    error:"",
    loading:false,
    error2:"",
    data:[],
    isSuccessful:false,
}

export const getAllPendingVendors = createAsyncThunk(
    "vendor/getAllPendingVendors",
   
    async ()=>{
        
        try {
            
            const response = await axios.get(`${baseUrl}/staff/vendor/pending/list`);
            if(response.status === 200){
               
                return response.data
            }
        } catch (error) {
          return error.response.data  
        }
    }
)

const getPendingVendors = createSlice({
    name:"vendor/getAllPendingVendors",
    initialState,
    reducers:{},
    extraReducers:(builder)=>{
        builder.addCase(getAllPendingVendors.rejected, (state, action)=>{
            state.error = action.payload;
            state.error2 = action.error.name;
            state.loading =false;
            state.isSuccessful =false;
          
        });
        builder.addCase(getAllPendingVendors.fulfilled, (state, action)=>{
            state.loading = true;
            state.data = action.payload;
            state.loading = false;
            state.isSuccessful =true;
            state.error ="";
        });
        builder.addCase(getAllPendingVendors.pending, (state, action)=>{
            state.loading = true;
            state.error = action.payload;
        })
    }
})


export default getPendingVendors.reducer