import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import axios from "axios";
import Swal from "sweetalert2";
import { baseUrl } from "../../Utils/helper";
// import { expenseUrl } from "../../utils/helper";

const initialState = {
  error: "",
  loading: false,
  error2: "",
  data: [],
  isSuccessful: false,
};

export const getVendors = createAsyncThunk("vendors/getVendors", async () => {
    console.log('hi')
    try {
      const response = await axios.get(`${baseUrl}/staff/vendor/active/list`);
      const res = response.data;
      console.log({res})
      if (res.responseCode === "00") {
        return res.data;
      } else {
        Swal.fire("Something Went Wrong!", "", "error");
      }
    } catch (error) {
      Swal.fire("Something Went Wrong!", "", "error");
      throw error;
    }
  });
// export const getVendors = createAsyncThunk(
//   "vendors/getVendors",
//   async () => {
//     console.log("hi there")
//     try {
  
//       fetch(`${baseUrl}/staff/vendor/pending/list`, {
//         method: "GET",
//         mode: "cors",
//         headers: {
//           "Content-Type": "application/json",
//         },
//       }).then(async (response) => {
//         let res = await response.json();
//         if (res.responseCode === "00") {
          
//           return res.data;
//         } else {
//           Swal.fire("Something Went Wrong!", "", "error");
//         }
        
//       });
      
//     } catch (e) {
//       Swal.fire("Something Went Wrong!", "", "error");
//       return e.response.data;
//     }
//   }
// );

const getAllVendors = createSlice({
  name: "vendors/getVendors",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(getVendors.rejected, (state, action) => {
      state.error = action.payload;
      state.error2 = action.error.name;
      state.loading = false;
      state.isSuccessful = false;
    });
    builder.addCase(getVendors.fulfilled, (state, action) => {
      state.loading = true;
      state.data = action.payload;
      state.loading = false;
      state.isSuccessful = true;
      state.error = "";
    });
    builder.addCase(getVendors.pending, (state, action) => {
      state.loading = true;
      state.error = action.payload;
    });
  },
});

// export const { useRegisterMutation } = AuthHandler;
export default getAllVendors.reducer;
