import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../Utils/helper";

const initialState={
    error:"",
    loading:false,
    error2:"",
    data:[],
    isSuccessful:false,
}

export const getAllRejectedVendors = createAsyncThunk(
    "vendor/getAllRejectedVendors",
    async ()=>{
        try {
            const response = await axios.get(`${baseUrl}/vendor/declined/list`);
            if(response.status === 200){
                return response.data
            }
        } catch (error) {
          return error.response.data  
        }
    }
)

const getRejectedVendors = createSlice({
    name:"vendor/getAllRejectedVendors",
    initialState,
    reducers:{},
    extraReducers:(builder)=>{
        builder.addCase(getAllRejectedVendors.rejected, (state, action)=>{
            state.error = action.payload;
            state.error2 = action.error.name;
            state.loading =false;
            state.isSuccessful =false;
          
        });
        builder.addCase(getAllRejectedVendors.fulfilled, (state, action)=>{
            state.loading = true;
            state.data = action.payload;
            state.loading = false;
            state.isSuccessful =true;
            state.error ="";
        });
        builder.addCase(getAllRejectedVendors.pending, (state, action)=>{
            state.loading = true;
            state.error = action.payload;
        })
    }
})


export default getRejectedVendors.reducer