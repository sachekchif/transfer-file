import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../Utils/helper";

const initialState={
    error:"",
    loading:false,
    error2:"",
    data:{},
    isSuccessful:false,
}

export const getVendorById = createAsyncThunk(
    "vendor'getVendorById",
   async (id, {rejectWithValue})=>{
    console.log("vendorId",id);
    try {
        const response = await axios.get(`xxxxxxxxxxxx`);
        if(response.status === 200){
            return response.data
        }
        return response.data

    } catch (error) {
        return rejectWithValue(error.response.data)
    }
   } 
)


const getVendorByIdSlice =createSlice({
    name:"vendor/getVendorById",
    initialState,
    reducers:{},
    extraReducers:(builder)=>{
        builder.addCase(getVendorById.rejected, (state, action)=>{
            state.error = action.payload;
            state.error2 = action.error.name;
            state.loading = false;
            state.isSuccessful =false;
        })
        builder.addCase(getVendorById.fulfilled, (state, action)=>{
            state.loading=true;
            state.data = action.payload;
            state.loading=false;
            state.isSuccessful=true;
            state.error =""
        })
        builder.addCase(getVendorById.pending, (state, action)=>{
            state.loading=true;
            state.error =action.payload
        })
    }

})

export default getVendorByIdSlice.reducer