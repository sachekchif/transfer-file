import React from 'react'
import AddVendors from '../components/Vendors/AddVendor'
import Header from "../../src/components/Header";
import SideBar from "../../src/components/SideBar";


const AddNewVendor = () => {
  return (
    <div className="theme-indigo">
      <Header />
      <div className="main_content" id="main-content">
        <SideBar />

        <div className="page page_bground">
          <AddVendors />
        </div>
      </div>
    </div>
  )
}

export default AddNewVendor