import React from 'react'
import Header from '../../src/components/Header'
import SideBar from '../../src/components/SideBar'
import Dashboard from '../components/Dashboard'
import { Navigate } from 'react-router-dom'

import animationData from "../assets/images/dashlogo.json"

const DashboardPage = () => {
  // const navigate = useNavigate()
 

  return (
    
    <div className='theme-indigo'>
    <Header />
    <div className="main_content" id="main-content">
      <SideBar />

      <div className="page page_bground">
      <Dashboard />
      
      </div>
      
    </div>
  
    </div>
  )
}

export default DashboardPage