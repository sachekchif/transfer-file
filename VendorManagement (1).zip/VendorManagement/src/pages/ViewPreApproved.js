import React from 'react'
import Header from "../../src/components/Header";
import SideBar from "../../src/components/SideBar";
import PreApprovedDetails from '../components/Requests/PreApprovedRequestDetails';


const ViewPreApproved = () => {
  return (
    <div className="theme-indigo">
    <Header />
    <div className="main_content" id="main-content">
      <SideBar />

      <div className="page page_bground">
        <PreApprovedDetails />
      </div>
    </div>
  </div>
  )
}

export default ViewPreApproved