import React from 'react'
import Loginer from '../components/Login/Loginer'




const Login = () => {
  return (
    <div><Loginer/></div>
  )
}

export default Login