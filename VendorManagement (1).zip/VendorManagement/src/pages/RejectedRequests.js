import React from "react";
import Header from "../../src/components/Header";
import SideBar from "../../src/components/SideBar";
import Rejected from "../components/Requests/RejectedRequests";

const RejectedRequests = () => {
  return (
    <div className="theme-indigo">
      <Header />
      <div className="main_content" id="main-content">
        <SideBar />

        <div className="page page_bground">
          <Rejected />
        </div>
      </div>
    </div>
  );
};

export default RejectedRequests;
