import React from 'react'
import Header from "../../src/components/Header";
import SideBar from "../../src/components/SideBar";
import Pending from "../components/Requests/PendingRequests";


const PendingRequests = () => {
  return (
    <div className="theme-indigo">
      <Header />
      <div className="main_content" id="main-content">
        <SideBar />

        <div className="page page_bground">
          <Pending />
        </div>
      </div>
    </div>
  )
}

export default PendingRequests