import React from 'react'
import AllTheVendors from '../components/Vendors/AllVendors'
import Header from "../../src/components/Header";
import SideBar from "../../src/components/SideBar";
const AllVendors = () => {
  return (
    <div className='theme-indigo'>
        <Header />
        <div className="main_content" id="main-content">
          <SideBar />

          <div className="page page_bground">
          <AllTheVendors />
          </div>
        </div>
        
        </div>
  )
}

export default AllVendors