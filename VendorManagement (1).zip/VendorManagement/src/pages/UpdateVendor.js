import React from 'react'
import Header from "../../src/components/Header";
import SideBar from "../../src/components/SideBar";
import UpdateTheVendors from '../components/Vendors/UpdateVendor'



const UpdateVendor = () => {
  return (
    <div className='theme-indigo'>
        <Header />
        <div className="main_content" id="main-content">
          <SideBar />

          <div className="page page_bground">
          <UpdateTheVendors />
          </div>
        </div>
        
        </div>
  )
}

export default UpdateVendor