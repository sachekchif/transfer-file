import axios from 'axios'

import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';

export const baseUrl = 'http://10.11.200.98:7009/suntrust/vendor/api'
// export const baseUrl ='https://vendor-management-system.onrender.com/suntrust/vendor/api'
// export const baseUrl = 'http://10.70.1.81:7009/suntrust/vendor/api'




export const pre_approve_columns = [
  {
    title: "S/N",
    render: (text, record, index) => <h2 className="table-avatar">{index + 1}</h2>,
  },
  
    {
      title: "ACCT NO.",
      dataIndex: "suntrustAccountNumber",
      render: (text, record) => <h2 className="table-avatar">{text}</h2>,
    },
    {
      title: "COMPANY NAME",
      dataIndex: "orgName",
      render: (text, record) => <h2 className="table-avatar">{text}</h2>,
    },
    {
        title: "PHONE NO",
        dataIndex: "orgPhoneNo",
        render: (text, record) => <h2 className="table-avatar">{text}</h2>,
      },
      {
        title: "EMAIL",
        dataIndex: "orgEmail",
        render: (text, record) => <h2 className="table-avatar">{text}</h2>,
      },
      
      {
        title: "SPECIALIZATION",
        dataIndex: "orgSpec",
        render: (text, record) => <h2 className="table-avatar">{text}</h2>,
      },
      {
        title: "DOCUMENTS UPLOADED",
        dataIndex: "documentsUploaded",
        render: (text, record) => <h2 className="table-avatar ">{text}</h2>,
      },
    
      {
        title: "Action",
        render: (text, record) => (
          
          <Link
            to={`/vendormanagement/pre-request-details/${text.vendorId}`}
            className="btn btn-sm btn-outline-primary m-r-10"
          >
            <i className="fa fa-eye m-r-5" />
            View Details
          </Link>
        ),
      },
  ];


export const approve_columns = [
  {
    title: "S/N",
    // dataIndex: "vendorId",
    render: (text, record, index) => <h2 className="table-avatar">{index + 1}</h2>,
  },
    {
      title: "ACCT NO.",
      dataIndex: "suntrustAccountNumber",
      render: (text, record) => <h2 className="table-avatar">{text}</h2>,
    },
    {
      title: "COMPANY NAME",
      dataIndex: "orgName",
      render: (text, record) => <h2 className="table-avatar">{text}</h2>,
    },
    {
        title: "PHONE NO",
        dataIndex: "orgPhoneNo",
        render: (text, record) => <h2 className="table-avatar">{text}</h2>,
      },
      {
        title: "EMAIL",
        dataIndex: "orgEmail",
        render: (text, record) => <h2 className="table-avatar">{text}</h2>,
      },
      
      {
        title: "SPECIALIZATION",
        dataIndex: "orgSpec",
        render: (text, record) => <h2 className="table-avatar">{text}</h2>,
      },
      {
        title: "DOCUMENTS UPLOADED",
        dataIndex: "documentsUploaded",
        render: (text, record) => <h2 className="table-avatar ">{text}</h2>,
      },
    
      {
        title: "Action",
        render: (text, record) => (
          <Link
            to={`/vendormanagement/view-vendor/${text.vendorId}`}
            className="btn btn-sm btn-outline-primary m-r-10"
          >
            <i className="fa fa-eye m-r-5" />
            View Details
          </Link>
        ),
      },
  ];

 

  export const http = (createAsyncThunk,name, url,method, body)=>{
    return createAsyncThunk(name, async ()=>{
        try {
           const response = await axios({
            method,
            url,
            body,
            headers:{
                "Content-Type": "application",
            }
           })
           if(response.data.statusCode === "00"){
            return response.data.data
           }
            
        } catch (error) {
            return error.response.data
        }
    })

  }

  export const postData = async(url, data)=>{

    const response = await fetch(url,{
        method:"POST",
        mode: "cors",
        headers:{
            "Content-Type":"application/json"
        },
        redirect:"follow",
        referrerPolicy:"no-referrer",
        body:JSON.stringify(data)
        
    })
    return response.json()
  }


  export const getDate =(dateString)=>{
    const dateTime = new Date(dateString);
  const year = dateTime.getFullYear();
  const month = (dateTime.getMonth() + 1).toString().padStart(2, '0');
  const day = dateTime.getDate().toString().padStart(2, '0');

  const extractedDate = `${year}-${month}-${day}`;
  return extractedDate;
  }

  export const getTime=(dateString)=> {
    const dateTime = new Date(dateString);
    const hours = dateTime.getUTCHours().toString().padStart(2, '0');
    const minutes = dateTime.getUTCMinutes().toString().padStart(2, '0');
    const extractedTime = `${hours}:${minutes}`;
    return extractedTime;
  }
  

  


  export const dataSlice = (name, initialState, reducers, api) => {
    return createSlice({
      name,
      initialState,
      reducers,
      extraReducers: (builder) => {
        builder.addCase(api.rejected, (state, action) => {
          state.error = action.payload;
          state.error2 = action.error.name;
          state.loading = false;
          state.isSuccessful = false;
        });
        builder.addCase(api.fulfilled, (state, action) => {
          state.loading = true;
          state.data = action.payload;
          state.loading = false;
          state.isSuccessful = true;
          state.error = "";
        });
        builder.addCase(api.pending, (state, action) => {
          state.loading = true;
          state.error = action.payload;
        });
      },
    });
  };

 
  