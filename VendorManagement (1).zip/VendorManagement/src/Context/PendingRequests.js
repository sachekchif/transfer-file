import { createContext } from "react";

const PendingRequestContext = createContext()

export default PendingRequestContext;