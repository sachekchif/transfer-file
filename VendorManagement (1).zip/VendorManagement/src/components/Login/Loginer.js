import theImage from "../../assets/images/new_logo.png";
import React, { useState } from "react";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";
import Loader from "../../assets/loader.gif";
import { useNavigate } from "react-router-dom";

export default function Loginer() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [inputError, setInputError] = useState("");
  const [loading, setLoading] = useState("");

  let navigate = useNavigate();
  const loginHandler = (e) => {
    e.preventDefault();
    if (!(email && password)) {
      return setInputError("Please fill the required fields");
    }

    const data = {
      email,
      password,
      // isADAuthenticated: false,
    };
    setLoading(true);

    axios
      .post("http://10.11.200.134/vendor_management_login/user/login", data)
      .then(async(response) => {
        if (response.data.responseCode === "96") {
          
          toast.error("Invalid Login Details");
          setLoading(false);
        } else {
          toast.success("Login Successful");

          let theRes = response.data;

          let user = JSON.stringify(theRes);
         

          sessionStorage.setItem("user", user);
          let ressy = response.data;
          let getRole = ressy.roleResponses[0];
          let theRole = getRole.roleName;
          let dept = ressy.departmentCode;
          sessionStorage.setItem("role", theRole);
          sessionStorage.setItem("department", dept)

          setTimeout(() => {
            setLoading(false);
            navigate("/vendormanagement/dashboard");
          }, 2000);
        }
      })
      .catch((error) => {
        setLoading(false);
        console.log(error);
        toast.error("Something went wrong");
      });
  };

  return (
    <div>
      <Toaster position="top-right" />
      <div className="vertical-align-wrap">
        <div className="vertical-align-middle auth-main">
          <div className="auth-box">
            <div className="top">
              <div className="image">
                <img
                  src={theImage}
                  style={{ width: "110px", height: "100px" }}
                  alt="User"
                />
              </div>
            </div>

            <div className="card">
              <div className="header text-center font-weight-700">
                <div className="lead">Login to your account</div>
              </div>
              <div className="body">
                <p className="text-danger">{inputError}</p>

                <form className="form-auth-small" onSubmit={loginHandler}>
                  <div className="form-group">
                    <label className="control-label">Email</label>
                    <input
                      type="text"
                      className="form-control"
                      value={email}
                      placeholder="Enter your Username"
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label className="control-label">Password</label>
                    <input
                      type="password"
                      value={password}
                      className="form-control"
                      placeholder="Password"
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>

                  <button
                    type="submit"
                    className="btn btn-suntrust btn-lg btn-block"
                    onClick={loginHandler}
                  >
                    {loading ? (
                      <img src={Loader}  height={20} alt="loader"/>
                    ) : (
                      "LOGIN"
                    )}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
