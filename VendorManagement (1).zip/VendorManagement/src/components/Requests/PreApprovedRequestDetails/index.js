import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { baseUrl, getDate } from "../../../Utils/helper";
import { BulletList } from "react-content-loader";
import DocumentModal from "../../Modals/DocumentModal";
import Swal from "sweetalert2";
import Loader from '../../../assets/loader.gif'


const PreApprovedDetails = () => {
  let navigate = useNavigate();
  const [buffer, setBuffer] = useState(true);
  const [approvedLoading, setApprovedLoading] = useState(false);
  const [loadingRejected, setLoadingRejected] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [detail, setDetail] = useState("first");
  const [vendor, setVendor] = useState({});
  const [remark, setRemark] = useState("");
  const [staffId, setStaffId] = useState("");
  const [staffName, setStaffName] = useState("");
  const [isThereVendor, setIsThereVendor] = useState(false);
  const [status, setStatus] = useState("");
  const [viewDocument, setViewDocument] = useState(false);
  // const [documentRef, setDocumentRef] = useState("");
  const [selectedDocument, setSelectedDocument] = useState(null);

  const user = JSON.parse(sessionStorage.getItem("user"));
  const departmentCode = sessionStorage.getItem("department");
 

  // console.log(user.roleResponses[0].roleName)
  const role = user.roleResponses[0].roleName

 
  const openDocumentModal = (documentRef) => {
    setSelectedDocument(documentRef);
    setViewDocument(true);
  };

  const closeDocumentModal = () => {
    setSelectedDocument(null);
    setViewDocument(false);
  };

  const updateLoading = () => {
    setTimeout(() => setLoaded(true), 2000);
  };

  useEffect(() => {
    axios
      .post(`${baseUrl}/staff/pendingVendor/details`, body)
      .then((response) => {
        let reply = response.data;

        if (reply.success === true) {
          setBuffer(false);
          setIsThereVendor(true);
          setVendor(reply.data);
        } else {
          setLoaded(true);
          setIsThereVendor(false);
        }
      })
      .catch((error) => {
        console.error("ERRAR", error);
        Swal.fire("Something Went Wrong!", "", "error");
      });
    updateLoading();
  }, []);

  const submitApprovedVendor = () => {
    Swal.fire({
      title: "Add Remark",
      input: "text",
      inputPlaceholder: "Enter your Remark",
      showCancelButton: true,
      confirmButtonText: "Approve",
    }).then(async (result) => {
      if (result.isConfirmed && result.value) {
        setRemark(result.value);

        let body = {
          action: "approve",
          staffId: staffId,
          staffName: staffName,
          vendorId: id,
          remark: result.value,
          department:departmentCode
        };
        try {
          setApprovedLoading(true);
          const response = await axios.post(
            `${baseUrl}/staff/initiator/vendor/approval`,
            body
          );
          if (response.data.responseCode === "00") {
            setApprovedLoading(false);
            navigate("/vendorManagement/all-vendors");
            Swal.fire(`${response.data.responseDescription}`, "", "success");
          } else {
            setLoaded(false)
            setApprovedLoading(false);
            Swal.fire(`${response.data.responseDescription}`, "", "error");
          
          }
        } catch (error) {
          setApprovedLoading(false);
          console.log(error);
        }
      }
    });
  };

  const submitRejectedVendor = () => {
    Swal.fire({
      title: "Add Remark",
      input: "text",
      inputPlaceholder: "Enter your Remark",
      showCancelButton: true,
      confirmButtonText: "Reject",
    }).then(async (result) => {
      if (result.isConfirmed && result.value) {
        setRemark(result.value);

        let body = {
          action: "decline",
          staffId: staffId,
          staffName: staffName,
          vendorId: id,
          remark: result.value,
          department:departmentCode
        };
        try {
          setLoadingRejected(true);
          const response = await axios.post(
            `${baseUrl}/staff/initiator/vendor/approval`,
            body
          );
          if (response.data.responseCode === "90") {
            setLoaded(false)
            setLoadingRejected(false);
            Swal.fire(`${response.data.responseDescription}`, "", "error");
            navigate("/vendorManagement/all-vendors");
          } else {
            setLoadingRejected(false);
            Swal.fire(`${response.data.responseDescription}`, "", "success");
            navigate("/vendorManagement/all-vendors");
          }
        } catch (error) {
            setLoaded(false)
            setLoadingRejected(false);
          console.log(error);
        }
      }
    });
  };
  useEffect(() => {
    setStaffId(user.staffId);
    setStaffName(user.staffName);
  }, [user]);

  const { id } = useParams();

  let body = {
    vendorId: id,
  };

  useEffect(() => {
    setRemark(remark);
  }, [remark]);



  return buffer ? (
    <MyBulletListLoader />
  ) : (
    <div className="container-fluid">
      <div className="row clearfix">
        <div className="col-sm-12">
          <div className="pt-20 pb-10 d-flex align-items-center">
            <button
              className="btn font-weight-700"
              onClick={() => navigate("/vendorManagement/all-vendors")}
            >
              <i className="fa fa-arrow-left m-r-10 m-t-20" />
              BACK
            </button>
            
          </div>

          <div className="text-center">
            <label className="font-18 font-weight-700 m-b-10">
              VENDOR DETAILS
            </label>
          </div>
        </div>
      </div>

      <div className="row clearfix">
        <div className="col-sm-12">
          <div className="card p-20">
            {loaded ? (
              <div className="col-lg-12 m-t-20">
                {/* <!-- Main Tab Shows Here --> */}
                <ul
                  className="nav nav-pills nav-fill flex-column flex-sm-row"
                  id="myTab"
                  role="tablist"
                >
                  {detail == "first" ? (
                    <li className="nav-item">
                      <button
                        className="nav-link mb-sm-3 active"
                        id="vendor-tab"
                        data-toggle="tab"
                        href="#"
                        role="tab"
                        aria-controls="vendor"
                        aria-selected="true"
                        onClick={() => setDetail("first")}
                      >
                        VENDOR DETAILS
                      </button>
                    </li>
                  ) : (
                    <li className="nav-item">
                      <button
                        className="nav-link mb-sm-3"
                        id="vendor-tab"
                        data-toggle="tab"
                        href="#"
                        role="tab"
                        aria-controls="vendor"
                        aria-selected="true"
                        onClick={() => setDetail("first")}
                      >
                        VENDOR DETAILS
                      </button>
                    </li>
                  )}

                  {detail == "second" ? (
                    <li className="nav-item">
                      <button
                        className="nav-link mb-sm-3 active"
                        id="vendor-tab"
                        data-toggle="tab"
                        href="#"
                        role="tab"
                        aria-controls="vendor"
                        aria-selected="true"
                        onClick={() => setDetail("second")}
                      >
                        VERIFIABLE CLIENTELLE
                      </button>
                    </li>
                  ) : (
                    <li className="nav-item">
                      <button
                        className="nav-link mb-sm-3"
                        id="vendor-tab"
                        data-toggle="tab"
                        href="#"
                        role="tab"
                        aria-controls="vendor"
                        aria-selected="true"
                        onClick={() => setDetail("second")}
                      >
                        VERIFIABLE CLIENTELLE
                      </button>
                    </li>
                  )}

                  {detail == "third" ? (
                    <li className="nav-item">
                      <button
                        className="nav-link mb-sm-3 active"
                        id="vendor-tab"
                        data-toggle="tab"
                        href="#"
                        role="tab"
                        aria-controls="vendor"
                        aria-selected="true"
                        onClick={() => setDetail("third")}
                      >
                        OWNED EQUIPMENT
                      </button>
                    </li>
                  ) : (
                    <li className="nav-item">
                      <button
                        className="nav-link mb-sm-3"
                        id="vendor-tab"
                        data-toggle="tab"
                        href="#"
                        role="tab"
                        aria-controls="vendor"
                        aria-selected="true"
                        onClick={() => setDetail("third")}
                      >
                        OWNED EQUIPMENT
                      </button>
                    </li>
                  )}

                  {detail == "fourth" ? (
                    <li className="nav-item">
                      <button
                        className="nav-link mb-sm-3 active"
                        id="vendor-tab"
                        data-toggle="tab"
                        href="#"
                        role="tab"
                        aria-controls="vendor"
                        aria-selected="true"
                        onClick={() => setDetail("fourth")}
                      >
                        UPLOADED DOCUMENTS
                      </button>
                    </li>
                  ) : (
                    <li className="nav-item">
                      <button
                        className="nav-link mb-sm-3"
                        id="vendor-tab"
                        data-toggle="tab"
                        href="#"
                        role="tab"
                        aria-controls="vendor"
                        aria-selected="true"
                        onClick={() => setDetail("fourth")}
                      >
                        UPLOADED DOCUMENTS
                      </button>
                    </li>
                  )}
                </ul>

                {/* <!-- Contents for the Review Tabs Shows Here --> */}
                <div className="tab-content" id="myTabContent">
                  {/* <!-- Loan Details Tab --> */}

                  {detail == "first" && (
                    <div
                      className="tab-pane fade show active"
                      id="vendor"
                      role="tabpanel"
                      aria-labelledby="loan-tab"
                    >
                      {role === 'APPROVER'
                       && vendor.approvalStatus === "PENDING"
                        &&
                        <label
                        class="alert pending_class m-t-10 m-b-10 p-10"
                        role="alert"
                      >
                        {`${vendor.initiatorName} requests approval for ${vendor.action}`}
                      </label>
                      }
                      

                      <div className="panel-heading text-center bg-gray white-text text-white m-t-20 m-b-30 font-16 font-weight-700">
                        COMPANY DETAILS
                      </div>

                      {/* <!-- <div className="m-t-20"> --> */}
                      <div className="row">
                        <div className="col-lg-12 col-md-12 col-sm-12">
                          <div className="card col-lg-12 col-md-12 col-sm-12">
                            <div className="d-flex m-t-20 m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                COMPANY NAME:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.orgName}
                              </div>
                            </div>
                            <div className="d-flex m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                PHONE NUMBER:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.orgPhoneNo}
                              </div>
                            </div>
                            <div className="d-flex m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                EMAIL:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.orgEmail}
                              </div>
                            </div>
                            <div className="d-flex m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                ADDRESS:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.orgAddress}
                              </div>
                            </div>

                            <div className="d-flex m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                WEBSITE ADDRESS:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.orgWebSite}
                              </div>
                            </div>
                            <div className="d-flex m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                SPECIALIZATION:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.orgSpec}
                              </div>
                            </div>

                            {/* <!-- Contact Person Information  --> */}
                            <div className="col-lg-12 m-t-20">
                              <div className="font-14 font-weight-800 border-bottom p-1">
                                COMPANY CONTACT PERSON
                              </div>
                            </div>

                            <div className="d-flex m-b-10 margin_bottom font_size m-t-20">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                FULLNAME:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.contactFullName}
                              </div>
                            </div>
                            <div className="d-flex m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                PHONE NUMBER:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.contactPhone}
                              </div>
                            </div>
                            <div className="d-flex m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                SUNTRUST BANK ACCOUNT NUMBER:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.orgAccNum}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="panel-heading text-center bg-gray white-text text-white col-lg-12 m-t-50 m-b-30 font-16 font-weight-700 border-bottom">
                        COMPLIANCE WITH LAWS AND REGULATIONS
                      </div>

                      <div className="row">
                        <div className="col-lg-12 col-md-12 col-sm-12">
                          <div className="card col-lg-12 col-md-12 col-sm-12">
                            <div className="m-t-20 m-b-10 margin_bottom font_size">
                              Lorem Ipsum is simply dummy text of the printing
                              and typesetting industry. Lorem Ipsum has been the
                              industry's standard dummy text ever since the
                              1500s, when an unknown printer took a galley of
                              type and scrambled it to make a type specimen
                              book. It has survived not only five centuries, but
                              also the leap into electronic typesetting,
                              remaining essentially unchanged. It was
                              popularised in the 1960s with the release of
                              Letraset sheets containing Lorem Ipsum passages,
                              and more recently with desktop publishing software
                              like Aldus PageMaker including versions of Lorem
                              Ipsum.
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="panel-heading text-center bg-gray white-text text-white col-lg-12 m-t-50 m-b-30 font-16 font-weight-700 border-bottom">
                        FINANCIAL RESOURCES
                      </div>

                      <div className="row">
                        <div className="col-lg-12 col-md-12 col-sm-12">
                          <div className="card col-lg-12 col-md-12 col-sm-12">
                            <div className="d-flex m-t-20 m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                COMPANY'S WORKING CAPITAL:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                N{vendor.orgWorkingCapital}
                              </div>
                            </div>

                            {/* <!-- Company’s Bankers and the limit of credit  --> */}
                            <div className="col-lg-12 m-t-20">
                              <div className="font-14 font-weight-800 border-bottom p-1">
                                COMPANY'S BANKERS & LIMITS
                              </div>
                            </div>

                            <div className="d-flex m-b-10 margin_bottom font_size m-t-20">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                BANK NAME:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                Suntrust Bank
                              </div>
                            </div>
                            <div className="d-flex m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                ACCOUNT NAME:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.orgAccName}
                              </div>
                            </div>
                            <div className="d-flex m-b-10 margin_bottom font_size">
                              <label className="col-lg-6 col-md-6 col-sm-12">
                                ACCOUNT NUMBER:
                              </label>
                              <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                                {vendor.orgAccNum}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* <!-- VERIFIABLE CLIENTELLE Tab --> */}

                  {detail == "second" && (
                    <div
                      className="tab-pane fade show active"
                      id="verify_client"
                      role=" tabpanel"
                      aria-labelledby="checklist-tab"
                    >
                      <div className="panel-heading text-center bg-gray white-text text-white m-t-20 m-b-30 font-16 font-weight-700">
                        CLIENTELLE DETAILS
                      </div>

                      <div className="row m-b-30">
                        <div className="form-group col-lg-12 col-md-12 col-sm-12 font-weight-700">
                          <div className="table-responsive border">
                            <table className="table table-hover mb-0 c_list">
                              <thead
                                className="font-weight-700"
                                style={{ backgroundColor: "#ddd" }}
                              >
                                <tr>
                                  <th>S/N</th>
                                  <th>COMPANY NAME</th>
                                  <th>CONTACT PERSON</th>
                                  <th>PHONE NUMBER</th>
                                </tr>
                              </thead>
                              <tbody>
                                {vendor.verifiedClients.map((data, index) => {
                                  index = index === 0 ? 1 : index + 1;
                                  return (
                                    <tr>
                                      <td>{index}</td>
                                      <td>{data.compName}</td>
                                      <td>{vendor.contactFullName}</td>
                                      <td>{data.compNumb}</td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* <!-- TECHNICAL CAPABILITY & OWNED EQUIPMENT Tab --> */}
                  {detail == "third" && (
                    <div
                      className="tab-pane fade show active"
                      id="owned_equip"
                      role="tabpanel"
                      aria-labelledby="checklist-tab"
                    >
                      <div className="panel-heading text-center bg-gray white-text text-white m-t-20 m-b-30 font-16 font-weight-700">
                        TECHNICAL CAPABILITY & OWNED EQUIPMENT
                      </div>

                      <div className="row m-b-30">
                        <div className="form-group col-lg-12 col-md-12 col-sm-12 font-weight-700">
                          <div className="table-responsive border">
                            <table className="table table-hover mb-0 c_list">
                              <thead
                                className="font-weight-700"
                                style={{ backgroundColor: "#ddd" }}
                              >
                                <tr>
                                  <th>S/N</th>
                                  <th>EQUIPMENT NAME</th>
                                  <th>NUMBER</th>
                                  <th>MODEL</th>
                                  <th>AGE</th>
                                </tr>
                              </thead>
                              <tbody>
                                {vendor.ownedEquips.map((data, index) => {
                                  index = index === 0 ? 1 : index + 1;
                                  return (
                                    <tr>
                                      <td>{index}</td>
                                      <td>{data.description}</td>
                                      <td>{data.number}</td>
                                      <td>{data.model}</td>
                                      <td>{data.age}</td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {detail == "fourth" && (
                    <div
                      className="tab-pane fade show active"
                      id="documents"
                      role="tabpanel"
                      aria-labelledby="documents-tab"
                    >
                      <div className="panel-heading text-center bg-gray white-text text-white m-t-20 m-b-30 font-16 font-weight-700">
                        LIST OF DOCUMENTS UPLOADED
                      </div>

                      <div className="row">
                        <div className="form-group col-lg-12 col-md-12 col-sm-12 font-weight-700">
                          <div className="table-responsive border">
                            <table className="table table-hover mb-0 c_list">
                              <thead style={{ backgroundColor: "#c4c4c4" }}>
                                <tr>
                                  <th colSpan="3">S/N</th>
                                  <th colSpan="3">TITLE</th>
                                  <th colSpan="3">ATTACHMENT</th>
                                  <th>DATE UPDATED</th>
                                  <th>ACTION</th>
                                </tr>
                              </thead>
                              <tbody>
                                {vendor.documents.map((doc, index) => {
                                  index = index === 0 ? 1 : index + 1;
                                  return (
                                    <tr key={index}>
                                      <td colSpan="3">{index}</td>
                                      <td colSpan="3">{doc.fileName}</td>
                                      <td colSpan="3">{doc.documentName}</td>
                                      <td>{getDate(doc.uploadedAt)}</td>
                                      <td>
                                        <button
                                          type="button"
                                          className="btn btn-success btn-sm m-b-5"
                                          title="View"
                                          onClick={() =>
                                            openDocumentModal(doc.base64)
                                          }
                                        >
                                          View
                                        </button>
                                      </td>
                                    </tr>
                                  );
                                })}
                                <DocumentModal
                                  displayImageModal={viewDocument}
                                  toggleImageModal={closeDocumentModal}
                                  documentRef={selectedDocument}
                                />
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <span></span>
            )}
          </div>
        </div>
      </div>

      {/* {vendor.approvalStatus === "PENDING" ? ( */}
      {vendor.approvalStatus !== "PENDING" && 
       <div>
       <button
         type="submit"
         className="btn btn-primary btn-lg"
         onClick={submitApprovedVendor}
       >
         {approvedLoading ? (
              <img src={Loader} height={20} alt="loader" />
            ) : (
              " Approve Vendor"
            )}  
       </button>
       <button
         type="submit"
         className="btn btn-danger btn-lg ml-3"
         onClick={submitRejectedVendor}
       >
            {loadingRejected ? (
              <img src={Loader} height={20} alt="loader" />
            ) : (
              " Reject Vendor"
            )} 
       </button>
     </div>
      }
       
     
    </div>
  );
};

export default PreApprovedDetails;
const MyBulletListLoader = () => <BulletList />;
