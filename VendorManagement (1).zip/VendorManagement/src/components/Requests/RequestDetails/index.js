import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getVendorLists } from "../../../services/store/reducer/vendorsReducer";
import { getApprovedVendors } from "../../../services/Requests/getApprovedVendors";
import { getVendorById } from "../../../services/Requests/getVendorByIdReducer";
import { baseUrl } from "../../../Utils/helper";
import Swal from "sweetalert2";
import axios from "axios";

const ApprovedVendor = () => {
  const { id } = useParams();

  const dispatch = useDispatch();
  const [reason, setReason] = useState({});
  const [showApproval, setShowApprovalModal] = useState(false);
  const [showRejection, setShowRejectionModal] = useState(false);
  const [pendingRequests, setPendingRequests] = useState({});

  const [loaded, setLoaded] = useState(false);
  const [vendor, setVendor] = useState("")
  const [remark, setRemark] = useState("")
  const [staffId, setStaffId] = useState("")
  const [isThereVendor, setIsThereVendor] = useState(false)
  const [detail, setDetail] = useState("first");
  const user = JSON.parse(sessionStorage.getItem("user"));

  let navigate = useNavigate();
 

  useEffect(() => {
    setStaffId(user.staffId);
  }, [user]);


  const getData = () => {
    let body = {
      vendorId: id,
    };
    try {
      fetch(`${baseUrl}/staff/vendor/details`, {
        method: "POST",
        mode: "cors",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body), // Include the body here
      }).then(async (response) => {
        let res = await response.json();
        if (res.responseCode === "00") {
          setPendingRequests(res.data);
          return res.data;
        } else {
          Swal.fire("Something Went Wrong!", "", "error");
        }
      });
    } catch (e) {
      Swal.fire("Something Went Wrong!", "", "error");
      return e.response.data;
    }
  };




  const setReasonState = (text) => {
    const reason = specificVendor?.details.find(
      (vendor) => vendor.vendorId === text
    );
    setReason(reason);
  };

  useEffect(() => {
    getData();
  }, []);


  useEffect(() => {
   setRemark(remark)
  }, [remark])
  

  const handleApprove = () => {
    setRemark(remark)
    setTimeout(() => {
      
      let body = {
        action: "approve",
        staffId: staffId,
        vendorId: id,
        remark:remark
      }
    }, 2000);


  }
  
  
 
  // useEffect(()=>{
  //     dispatch(getApprovedVendors())
  // },[])

  return (
    <div className="container-fluid">
      <div className="row clearfix">
        <div className="col-sm-12">
          <div className="pt-20 pb-10">
            <a
              href="#"
              className="font-weight-700"
              onClick={() => navigate("/vendorManagement/all-vendors")}
            >
              <i className="fa fa-arrow-left m-r-10 m-t-20" />
              BACK
            </a>
          </div>

          <div className="text-center">
            <label className="font-18 font-weight-700 m-b-10">
              VENDOR DETAILS
            </label>
          </div>
        </div>
      </div>

      <div className="row clearfix">
        <div className="col-sm-12">
          <div className="card p-20">

          {
            loaded ? (



              <div className="col-lg-12 m-t-20">
              {/* <!-- Main Tab Shows Here --> */}
              <ul
                className="nav nav-pills nav-fill flex-column flex-sm-row"
                id="myTab"
                role="tablist"
              >
                {detail == "first" ? (
                  <li className="nav-item">
                    <button
                      className="nav-link mb-sm-3 active"
                      id="vendor-tab"
                      data-toggle="tab"
                      href="#"
                      role="tab"
                      aria-controls="vendor"
                      aria-selected="true"
                      onClick={() => setDetail("first")}
                    >
                      VENDOR DETAILS
                    </button>
                  </li>
                ) : (
                  <li className="nav-item">
                    <button
                      className="nav-link mb-sm-3"
                      id="vendor-tab"
                      data-toggle="tab"
                      href="#"
                      role="tab"
                      aria-controls="vendor"
                      aria-selected="true"
                      onClick={() => setDetail("first")}
                    >
                      VENDOR DETAILS
                    </button>
                  </li>
                )}

                {detail == "second" ? (
                  <li className="nav-item">
                    <button
                      className="nav-link mb-sm-3 active"
                      id="vendor-tab"
                      data-toggle="tab"
                      href="#"
                      role="tab"
                      aria-controls="vendor"
                      aria-selected="true"
                      onClick={() => setDetail("second")}
                    >
                      VERIFIABLE CLIENTELLE
                    </button>
                  </li>
                ) : (
                  <li className="nav-item">
                    <button
                      className="nav-link mb-sm-3"
                      id="vendor-tab"
                      data-toggle="tab"
                      href="#"
                      role="tab"
                      aria-controls="vendor"
                      aria-selected="true"
                      onClick={() => setDetail("second")}
                    >
                      VERIFIABLE CLIENTELLE
                    </button>
                  </li>
                )}

                {detail == "third" ? (
                  <li className="nav-item">
                    <button
                      className="nav-link mb-sm-3 active"
                      id="vendor-tab"
                      data-toggle="tab"
                      href="#"
                      role="tab"
                      aria-controls="vendor"
                      aria-selected="true"
                      onClick={() => setDetail("third")}
                    >
                      OWNED EQUIPMENT
                    </button>
                  </li>
                ) : (
                  <li className="nav-item">
                    <button
                      className="nav-link mb-sm-3"
                      id="vendor-tab"
                      data-toggle="tab"
                      href="#"
                      role="tab"
                      aria-controls="vendor"
                      aria-selected="true"
                      onClick={() => setDetail("third")}
                    >
                      OWNED EQUIPMENT
                    </button>
                  </li>
                )}

                {detail == "fourth" ? (
                  <li className="nav-item">
                    <button
                      className="nav-link mb-sm-3 active"
                      id="vendor-tab"
                      data-toggle="tab"
                      href="#"
                      role="tab"
                      aria-controls="vendor"
                      aria-selected="true"
                      onClick={() => setDetail("fourth")}
                    >
                      UPLOADED DOCUMENTS
                    </button>
                  </li>
                ) : (
                  <li className="nav-item">
                    <button
                      className="nav-link mb-sm-3"
                      id="vendor-tab"
                      data-toggle="tab"
                      href="#"
                      role="tab"
                      aria-controls="vendor"
                      aria-selected="true"
                      onClick={() => setDetail("fourth")}
                    >
                      UPLOADED DOCUMENTS
                    </button>
                  </li>
                )}
              </ul>

              {/* <!-- Contents for the Review Tabs Shows Here --> */}
              <div className="tab-content" id="myTabContent">
                {/* <!-- Loan Details Tab --> */}

                {detail == "first" && (
                  <div
                    className="tab-pane fade show active"
                    id="vendor"
                    role="tabpanel"
                    aria-labelledby="loan-tab"
                  >
                    <div className="panel-heading text-center bg-gray white-text text-white m-t-20 m-b-30 font-16 font-weight-700">
                      COMPANY DETAILS
                    </div>

                    {/* <!-- <div className="m-t-20"> --> */}
                    <div className="row">
                      <div className="col-lg-12 col-md-12 col-sm-12">
                        <div className="card col-lg-12 col-md-12 col-sm-12">
                          <div className="d-flex m-t-20 m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              COMPANY NAME:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              {vendor.orgName}
                            </div>
                          </div>
                          <div className="d-flex m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              PHONE NUMBER:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              {vendor.orgPhoneNo}
                            </div>
                          </div>
                          <div className="d-flex m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              EMAIL:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              {vendor.orgEmail}
                            </div>
                          </div>
                          <div className="d-flex m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              ADDRESS:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              {vendor.orgAddress}
                            </div>
                          </div>
                         
                          <div className="d-flex m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              WEBSITE ADDRESS:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                            {vendor.orgWebSite}
                            </div>
                          </div>
                          <div className="d-flex m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              SPECIALIZATION:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              {vendor.orgSpec}
                            </div>
                          </div>

                          {/* <!-- Contact Person Information  --> */}
                          <div className="col-lg-12 m-t-20">
                            <div className="font-14 font-weight-800 border-bottom p-1">
                              COMPANY CONTACT PERSON
                            </div>
                          </div>

                          <div className="d-flex m-b-10 margin_bottom font_size m-t-20">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              FULLNAME:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              {vendor.contactFullName}
                            </div>
                          </div>
                          <div className="d-flex m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              PHONE NUMBER:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              {vendor.contactPhone}
                            </div>
                          </div>
                          <div className="d-flex m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              SUNTRUST BANK ACCOUNT NUMBER:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                             {vendor.orgAccNum}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="panel-heading text-center bg-gray white-text text-white col-lg-12 m-t-50 m-b-30 font-16 font-weight-700 border-bottom">
                      COMPLIANCE WITH LAWS AND REGULATIONS
                    </div>

                    <div className="row">
                      <div className="col-lg-12 col-md-12 col-sm-12">
                        <div className="card col-lg-12 col-md-12 col-sm-12">
                          <div className="m-t-20 m-b-10 margin_bottom font_size">
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and
                            scrambled it to make a type specimen book. It has
                            survived not only five centuries, but also the leap
                            into electronic typesetting, remaining essentially
                            unchanged. It was popularised in the 1960s with the
                            release of Letraset sheets containing Lorem Ipsum
                            passages, and more recently with desktop publishing
                            software like Aldus PageMaker including versions of
                            Lorem Ipsum.
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="panel-heading text-center bg-gray white-text text-white col-lg-12 m-t-50 m-b-30 font-16 font-weight-700 border-bottom">
                      FINANCIAL RESOURCES
                    </div>

                    <div className="row">
                      <div className="col-lg-12 col-md-12 col-sm-12">
                        <div className="card col-lg-12 col-md-12 col-sm-12">
                          <div className="d-flex m-t-20 m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              COMPANY'S WORKING CAPITAL:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              N{vendor.orgWorkingCapital}
                            </div>
                          </div>

                          {/* <!-- Company’s Bankers and the limit of credit  --> */}
                          <div className="col-lg-12 m-t-20">
                            <div className="font-14 font-weight-800 border-bottom p-1">
                              COMPANY'S BANKERS & LIMITS
                            </div>
                          </div>

                          <div className="d-flex m-b-10 margin_bottom font_size m-t-20">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              BANK NAME:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              Suntrust Bank
                            </div>
                          </div>
                          <div className="d-flex m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              ACCOUNT NAME:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              {vendor.orgAccName}
                            </div>
                          </div>
                          <div className="d-flex m-b-10 margin_bottom font_size">
                            <label className="col-lg-6 col-md-6 col-sm-12">
                              ACCOUNT NUMBER:
                            </label>
                            <div className="col-lg-6 col-md-6 col-sm-12 font-weight-700">
                              {vendor.orgAccNum}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* <!-- VERIFIABLE CLIENTELLE Tab --> */}

                {detail == "second" && (
                  <div
                    className="tab-pane fade show active"
                    id="verify_client"
                    role=" tabpanel"
                    aria-labelledby="checklist-tab"
                  >
                    <div className="panel-heading text-center bg-gray white-text text-white m-t-20 m-b-30 font-16 font-weight-700">
                      CLIENTELLE DETAILS
                    </div>

                    <div className="row m-b-30">
                      <div className="form-group col-lg-12 col-md-12 col-sm-12 font-weight-700">
                        <div className="table-responsive border">
                          <table className="table table-hover mb-0 c_list">
                            <thead
                              className="font-weight-700"
                              style={{ backgroundColor: "#ddd" }}
                            >
                              <tr>
                                <th>S/N</th>
                                <th>COMPANY NAME</th>
                                <th>CONTACT PERSON</th>
                                <th>PHONE NUMBER</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>1</td>
                                <td>Samsung Group of Companies</td>
                                <td>Majekodunmi Olowolayemo</td>
                                <td>09025226796</td>
                              </tr>

                              <tr>
                                <td>2</td>
                                <td>Toshiba Group</td>
                                <td>James Ching Chung</td>
                                <td>09025226796</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* <!-- TECHNICAL CAPABILITY & OWNED EQUIPMENT Tab --> */}
                {detail == "third" && (
                  <div
                    className="tab-pane fade show active"
                    id="owned_equip"
                    role="tabpanel"
                    aria-labelledby="checklist-tab"
                  >
                    <div className="panel-heading text-center bg-gray white-text text-white m-t-20 m-b-30 font-16 font-weight-700">
                      TECHNICAL CAPABILITY & OWNED EQUIPMENT
                    </div>

                    <div className="row m-b-30">
                      <div className="form-group col-lg-12 col-md-12 col-sm-12 font-weight-700">
                        <div className="table-responsive border">
                          <table className="table table-hover mb-0 c_list">
                            <thead
                              className="font-weight-700"
                              style={{ backgroundColor: "#ddd" }}
                            >
                              <tr>
                                <th>S/N</th>
                                <th>EQUIPMENT NAME</th>
                                <th>NUMBER</th>
                                <th>MODEL</th>
                                <th>AGE</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>1</td>
                                <td>Computers</td>
                                <td>09301</td>
                                <td>2018</td>
                                <td>3years</td>
                              </tr>

                              <tr>
                                <td>2</td>
                                <td>Elevators</td>
                                <td>08948</td>
                                <td>2019</td>
                                <td>2 years</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {detail == "fourth" && (
                  <div
                    className="tab-pane fade show active"
                    id="documents"
                    role="tabpanel"
                    aria-labelledby="documents-tab"
                  >
                    <div className="panel-heading text-center bg-gray white-text text-white m-t-20 m-b-30 font-16 font-weight-700">
                      LIST OF DOCUMENTS UPLOADED
                    </div>

                    <div className="row">
                      <div className="form-group col-lg-12 col-md-12 col-sm-12 font-weight-700">
                        <div className="table-responsive border">
                          <table className="table table-hover mb-0 c_list">
                            <thead style={{ backgroundColor: "#c4c4c4" }}>
                              <tr>
                                <th>S/N</th>
                                <th>TITLE</th>
                                <th>ATTACHMENT</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>1</td>
                                <td>Company Profile</td>
                                <td>CompanyProfile.pdf</td>
                              </tr>
                              <tr>
                                <td>2</td>
                                <td>
                                  Copy of Certificate of Registration or
                                  Incorporation
                                </td>
                                <td>certificateofregistration.PDF</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            ):(
              <span>
                
              </span>
            )
          }


          
          </div>
        </div>
      </div>

      {/* <!-- View Comment Modal goes here for Business Segment Head! -->
    <div className="modal fade" id="update_modal" tabindex="-1" role="dialog" aria-labelledby="update_modal"
        aria-hidden="true">
        <div className="modal-dialog modal-dialog-centered" role="document">
            <div className="modal-content">
                <div className="modal-header bg-primary align-items-center justify-content-center">
                    <h5 className="modal-title text-white font-weight-700" id="modal_title_6">CONFIRM UPDATE?
                    </h5>
                </div>
                <div className="modal-body">
                    <div className="py-3 text-center">
                        <i className="fa fa-exclamation-circle fa-4x"></i>
                        <h4 className="heading mt-4">Are you sure you want to Update this Vendor Profile?</h4>
                    </div>
                </div>

                <div className="modal-footer  justify-content-center align-items-center">
                    <a className="btn btn-primary" data-dismiss="modal">UPDATE VENDOR</a>
                    <a className="btn btn-outline-danger" data-dismiss="modal">CANCEL</a>
                </div>
            </div>
        </div>
    </div> */}

    <button type="submit" className="btn btn-primary btn-lg" onClick={async ()=> {
        const { value: remark } = await Swal.fire({
          title: 'Add Remark',
          input: 'text',
          // inputLabel: 'Remark',
          
          inputPlaceholder: 'Enter your Remark'
        })
        
        if (remark) {
          setRemark(remark)
          handleApprove()
        }
    }}>Approve Vendor</button>
    </div>
  );
};

export default ApprovedVendor;
