import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";
import "../../../assets/css/antdstyle.css";
import { getDate } from "../../../Utils/helper";
import { approve_columns } from "../../../Utils/helper";

import { Table} from "antd";
import { itemRender, onShowSizeChange } from "../../Pagination";
import { baseUrl } from "../../../Utils/helper";
import { BulletList } from "react-content-loader";
import { utils as XLSXUtils, write as XLSXWrite } from 'xlsx';
import { saveAs } from "file-saver";



const ApprovedVendors = () => {


  const [buffer, setBuffer] = useState(true);
  const  [startDate, setStartDate] =useState('')
  const [endDate, setEndDate] = useState('')
  const [errorMsg, setErrorMsg] = useState("")
  const [filteredData, setFilteredData]=useState([])

  const [approvedVendors, setApprovedVendors]= useState([])

  const handleExportData = () => {
    if (!startDate && !endDate) {
      setErrorMsg("Please select dates");
      return;
    }
    setErrorMsg("");
    const filtered = approvedVendors.filter(
      (item) =>
        getDate(item.createdAt) >= startDate &&
        getDate(item.createdAt) <= endDate 
       
    );

    if (filtered.length < 1) {
      setErrorMsg("No data found");
      return;
    }

    const timestamp = new Date().getTime();
    const fileName = `filtered_data_${timestamp}.xlsx`;

    const workbook = XLSXUtils.book_new();
    const worksheet = XLSXUtils.json_to_sheet(filtered);
    XLSXUtils.book_append_sheet(workbook, worksheet, "Filtered Data");
    const excelBuffer = XLSXWrite(workbook, {
      bookType: "xlsx",
      type: "array",
    });
    const excelData = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(excelData, fileName);
  };
  const updateLoading = () => {
    setTimeout(() => setBuffer(false), 2000);
  };


  const getData = async () => {
    try {
      const department = sessionStorage.getItem('department');
      const response = await axios.post(`${baseUrl}/staff/vendor/active/list`, {
        department
      },
       {
        headers: {
          'Content-Type': 'application/json',
        },
      });
  
      if (response.data.responseCode === '00') {
        // Assuming you have a function setPendingRequests to handle the data
        setApprovedVendors(response.data.data);
        return response.data.data;
      } else {
        Swal.fire('Something Went Wrong!', '', 'error');
      }
    } catch (error) {
      Swal.fire('Something Went Wrong!', '', 'error');
      return error.response.data;
    }
  };

 

  useEffect(() => {
    getData()
    updateLoading()
  }, []);

  return (
    <div className="container-fluid">
      <div className="row clearfix">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <label className="font-18 font-weight-700 m-t-20">
            APPROVED REQUESTS
          </label>
          <div className="card">
            <div className="body">
              <div className="row filter-row m-b-10">
                <div className="col-lg-3 col-md-12 col-sm-12">
                  <div className="form-group form-focus">
                    <label>FROM DATE:</label>
                    <input
                     type="date"
                      className="form-control"
                      value ={startDate}
                      onChange={(e)=>setStartDate(e.target.value)}
                       />
                  </div>
                </div>

                <div className="col-lg-3 col-md-12 col-sm-12">
                  <div className="form-group form-focus">
                    <label>TO DATE:</label>
                    <input
                     type="date"
                      className="form-control"
                      value={endDate}
                      onChange={(e)=>setEndDate(e.target.value)}
                       />
                  </div>
                </div>

                <div className="col-lg-3 col-md-12 col-sm-12">
                  <label>&nbsp;</label>
                  <div className="form-group form-focus">
                    <div className="col-lg-3 col-md-12 col-sm-12">
                      <div className="dropdown mb-50">
                        <button
                          className="btn btn-secondary "
                          type="button"
                          aria-expanded="false"
                          onClick={handleExportData}
                        >
                          Export to Excel
                        </button>
                        {/* <ul className="dropdown-menu">
                          <li>
                            <a
                              className="dropdown-item"
                              href="#"
                              
                              // onClick={() => setStatus("Pending")}
                            >
                              Export to Excel
                            </a>
                          </li>
                          <li>
                            <a
                              className="dropdown-item"
                              href="#"
                              // onClick={() => setStatus("Completed")}
                            >
                              Download Data
                            </a>
                          </li>
                        </ul> */}
                        {errorMsg  ?( <p className="text-danger">{errorMsg}</p>) :""}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="form-group">
                <div className="input-group input-group-transparent mb-4">
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fa fa-search" />
                    </span>
                  </div>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>
              </div>

              {buffer ? (
                <MyBulletListLoader />
              ) : (
                <div className=" table-responsive m-b-50">
                  <Table
                    className="table-striped"
                    pagination={{
                      total: approvedVendors?.length,
                      showTotal: (total, range) =>
                        `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                      showSizeChanger: true,
                      onShowSizeChange: onShowSizeChange,
                      itemRender: itemRender,
                    }}
                    style={{ overflowX: "auto" }}
                    columns={approve_columns}
                    // bordered
                    dataSource={approvedVendors}
                    rowKey={(record) => record.vendorId}
                    // onChange={console.log("change")}
                  />
                </div>
              )}
            </div>
            {/* <!-- </div> --> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApprovedVendors;

const MyBulletListLoader = () => <BulletList />;
