import React, { useState, useEffect } from "react";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { getAllRejectedVendors } from "../../../services/Requests/getRejectedVendors";
import { Table, Empty } from "antd";
import { BulletList } from "react-content-loader";
import { getDate } from "../../../Utils/helper";
import { onShowSizeChange, itemRender } from "../../Pagination";
import { utils as XLSXUtils, write as XLSXWrite } from 'xlsx';
import { baseUrl } from "../../../Utils/helper";

import { saveAs } from "file-saver";



const RejectedVendors = () => {
  let navigate = useNavigate();
  const [buffer, setBuffer] = useState(true);
  const  [startDate, setStartDate] =useState('')
  const [endDate, setEndDate] = useState('')
  const [errorMsg, setErrorMsg] = useState("")
  const [filteredData, setFilteredData]=useState([])
  const [getRejectedRequests, setGetRejectedRequests] = useState([])


  const role = JSON.parse(sessionStorage.getItem("user"));

const user = (role.roleResponses[0])

const userRole = user.roleName

const handleExportData = () => {
  if (!startDate && !endDate) {
    setErrorMsg("Please select dates");
    return;
  }
  setErrorMsg("");
  const filtered = getRejectedRequests.filter(
    (item) =>
      getDate(item.createdAt) >= startDate &&
      getDate(item.createdAt) <= endDate 
     
  );

  if (filtered.length < 1) {
    setErrorMsg("No data found");
    return;
  }

  const timestamp = new Date().getTime();
  const fileName = `filtered_data_${timestamp}.xlsx`;

  const workbook = XLSXUtils.book_new();
  const worksheet = XLSXUtils.json_to_sheet(filtered);
  XLSXUtils.book_append_sheet(workbook, worksheet, "Filtered Data");
  const excelBuffer = XLSXWrite(workbook, {
    bookType: "xlsx",
    type: "array",
  });
  const excelData = new Blob([excelBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  saveAs(excelData, fileName);
};

const getData =()=>{
  try {
   
    fetch(`${baseUrl}staff/vendor/declined/list`, {
      method: "GET",
      mode: "cors",
      headers: {
        "Content-Type": "application/json",
      },
    }).then(async (response) => {
      let res = await response.json();
      if (res.responseCode === "00") {
        setGetRejectedRequests(res.data)
        return res.data;
      } else {
        Swal.fire("Something Went Wrong!", "", "error");
      }
      
    });
    
  } catch (e) {
    Swal.fire("Something Went Wrong!", "", "error");
    return e.response.data;
  }

}



 

  const updateLoading = () => {
    setTimeout(() => setBuffer(false), 2000);
  };

  useEffect(() => {
    getData()
    updateLoading();
  }, []);

  const columns = [
    {
      title: "S/N",
      dataIndex: "vendorId",
      render: (text, record, index) => <h2 className="table-avatar">{index + 1}</h2>,
    },
    {
      title: "ACCT NO.",
      dataIndex: "suntrustAccountNumber",
      render: (text, record) => <h2 className="table-avatar">{text}</h2>,
    },
    {
      title: "COMPANY NAME",
      dataIndex: "orgName",
      render: (text, record) => <h2 className="table-avatar">{text}</h2>,
    },
    {
      title: "PHONE NO",
      dataIndex: "vendorPhone",
      render: (text, record) => <h2 className="table-avatar">{text}</h2>,
    },
    {
      title: "EMAIL",
      dataIndex: "orgEmail",
      render: (text, record) => <h2 className="table-avatar">{text}</h2>,
    },
    {
      title: "SPECIALIZATION",
      dataIndex: "specialization",
      render: (text, record) => <h2 className="table-avatar">{text}</h2>,
    },

    {
      title: "DOCUMENTS UPLOADED",
      dataIndex: "documentsUploaded",
      render: (text, record) => <h2 className="table-avatar ">{text}</h2>,
    },

    {
      title: "Action",
      render: (text, record) => (
        <div className="btn-group dropup  ">
          <div className="d-flex ">
            <button
              className="btn btn-secondary dropdown-toggle  position-relative mr-2 "
              type="button"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              Select Action
            </button>

            <ul className="dropdown-menu">
              <li>
                <button
                  className="dropdown-item"
                  href="#"
                  onClick={() => navigate(`/vendorManagement/update-vendor/${text.vendorId}`)}
                >
                  Update Vendor
                </button>
              </li>

              <li>
                <button
                  className="dropdown-item"
                  href="#"
                  onClick={() => {
                    Swal.fire({
                      title: "Are you sure?",
                      text: "Are you sure you want to Blacklist this Vendor?",
                      icon: "warning",
                      showCancelButton: true,
                      confirmButtonColor: "#3085d6",
                      cancelButtonColor: "#d33",
                      confirmButtonText: "Yes, Blacklist",
                    }).then((result) => {
                      if (result.isConfirmed) {
                        Swal.fire(
                          "Blacklisted!",
                          "vendor has been blacklisted.",
                          "success"
                        );
                      }
                    });
                  }}
                >
                  Blacklist Vendor
                </button>
              </li>
            </ul>
            <button
              className="btn btn-secondary"
              onClick={() => navigate(`/vendorManagement/view-vendor/${text.vendorId}`)}
            >
              view
            </button>
          </div>
        </div>
      ),
      // <Link
      //   to={`/vendormanagement/request-details/${text.vendorId}`}
      //   className="btn btn-sm btn-outline-primary m-r-10"
      // >
      //   <i className="fa fa-eye m-r-5" />
      //   View Details
      // </Link>
    },
  ];
  return (
    <div className="container-fluid">
      <div className="row clearfix">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <label className="font-18 font-weight-700 m-t-20">
            REJECTED REQUESTS
          </label>
          <div className="card">
            <div className="body">
              <div className="row filter-row m-b-10">
                <div className="col-lg-3 col-md-12 col-sm-12">
                  <div className="form-group form-focus">
                    <label>FROM DATE:</label>
                    <input
                     type="date"
                    className="form-control"
                    value ={startDate}
                    onChange={(e)=>setStartDate(e.target.value)}
                     />
                  </div>
                </div>

                <div className="col-lg-3 col-md-12 col-sm-12">
                  <div className="form-group form-focus">
                    <label>TO DATE:</label>
                    <input
                     type="date"
                      value={endDate}
                      className="form-control"
                      onChange={(e)=>setEndDate(e.target.value)}
                       />
                      
                  </div>
                </div>

                <div className="col-lg-3 col-md-12 col-sm-12">
                  <label>&nbsp;</label>
                  <div className="form-group form-focus">
                    <div className="col-lg-3 col-md-12 col-sm-12">
                      <div className="dropdown mb-50 ">
                       
                       
                        <button
                          className="btn btn-secondary dropdown-toggle"
                          type="button"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                          onClick={handleExportData}
                        >
                          Export to Excel
                        </button>
                        {errorMsg && <p className="text-danger">{errorMsg}</p>}
                        {/* <ul className="dropdown-menu">
                          <li>
                            <a
                              className="dropdown-item"
                              href="#"
                              // onClick={() => setStatus("Pending")}
                            >
                              Export to Excel
                            </a>
                          </li>
                          <li>
                            <a
                              className="dropdown-item"
                              href="#"
                              // onClick={() => setStatus("Completed")}
                            >
                              Download Data
                            </a>
                          </li>
                        </ul> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="form-group">
                <div className="input-group input-group-transparent mb-4">
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fa fa-search" />
                    </span>
                  </div>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>
              </div>
              
               {buffer ? (
                <MyBulletListLoader />
              ) : (
              
              <div className=" table-responsive m-b-50">
                <Table
                  className="table-striped"
                  pagination={{
                    total: getRejectedRequests?.length,
                    showTotal: (total, range) =>
                      `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                    showSizeChanger: true,
                    onShowSizeChange: onShowSizeChange,
                    itemRender: itemRender,
                  }}
                  style={{ overflowX: "auto" }}
                  columns={columns}
                  // bordered
                  dataSource={getRejectedRequests}
                  rowKey={(record) => record.vendorId}
                  // onChange={console.log("change")}
                />
              
              </div>
                )}
              {/* <!-- <div className="col-lg-6"> --> */}
              {/* <!-- Pagination with text --> */}
           
            </div>
            {/* <!-- </div> --> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RejectedVendors;

const MyBulletListLoader = () => <BulletList />;