import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../../../assets/css/antdstyle.css";
import { getDate } from "../../../Utils/helper";
// import { approve_columns } from "../../../Utils/helper";


import { Table } from "antd";
import { itemRender, onShowSizeChange } from "../../Pagination";
import { BulletList } from "react-content-loader";
import { utils as XLSXUtils, write as XLSXWrite } from "xlsx";
import { saveAs } from "file-saver";
import { baseUrl } from "../../../Utils/helper";

const PendingVendors = () => {
  const role = sessionStorage.getItem("role");
 
  let navigate = useNavigate();
 const approve_columns = [
    {
      title: "S/N",
      // dataIndex: "vendorId",
      render: (text, record, index) => <h2 className="table-avatar">{index + 1}</h2>,
    },
      {
        title: "ACCT NO.",
        dataIndex: "suntrustAccountNumber",
        render: (text, record) => <h2 className="table-avatar">{text}</h2>,
      },
      {
        title: "COMPANY NAME",
        dataIndex: "orgName",
        render: (text, record) => <h2 className="table-avatar">{text}</h2>,
      },
      {
          title: "PHONE NO",
          dataIndex: "orgPhoneNo",
          render: (text, record) => <h2 className="table-avatar">{text}</h2>,
        },
        {
          title: "EMAIL",
          dataIndex: "orgEmail",
          render: (text, record) => <h2 className="table-avatar">{text}</h2>,
        },
        
        {
          title: "SPECIALIZATION",
          dataIndex: "orgSpec",
          render: (text, record) => <h2 className="table-avatar">{text}</h2>,
        },
        {
          title: "DOCUMENTS UPLOADED",
          dataIndex: "documentsUploaded",
          render: (text, record) => <h2 className="table-avatar ">{text}</h2>,
        },
      
        {
          title: "Action",
          render: (text, record) => (
            <div>
            {role === "Approver" ? (
              <button
                className="btn btn-secondary"
                onClick={() =>
                  navigate(
                    `/vendormanagement/pending-view-vendor/${text.vendorId}`
                  )
                }
              >
                view
              </button>
            ) : role === "Initiator" ? (
              <button
                className="btn btn-secondary"
                onClick={() =>
                  navigate(
                    `/vendormanagement/view-vendor/${text.vendorId}`
                  )
                }
              >
                view
              </button>
            ) : null}
            </div>
          ),
        },
    ];
  const [buffer, setBuffer] = useState(true);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [pendingRequests, setPendingRequests] = useState([]);
  const [search, setSearch] = useState("");
  const [filteredData, setFilteredData] = useState([]);

 


  const handleSearch = (e) => {
    const input = e.target.value;
    setSearch(input);
    const filtered = pendingRequests.filter((item) => {
      return item.orgEmail
        .toLowerCase()
        .toString()
        .startsWith(input.toLowerCase().toString());
    });
    setFilteredData(filtered);
  };

  const handleExportData = () => {
    if (!startDate && !endDate) {
      setErrorMsg("Please select dates");
      return;
    }
    setErrorMsg("");
    const filtered = pendingRequests.filter(
      (item) =>
        getDate(item.createdAt) >= startDate &&
        getDate(item.createdAt) <= endDate
    );

    if (filtered.length < 1) {
      setErrorMsg("No data found");
      return;
    }

    const timestamp = new Date().getTime();
    const fileName = `filtered_data_${timestamp}.xlsx`;

    const workbook = XLSXUtils.book_new();
    const worksheet = XLSXUtils.json_to_sheet(filtered);
    XLSXUtils.book_append_sheet(workbook, worksheet, "Filtered Data");
    const excelBuffer = XLSXWrite(workbook, {
      bookType: "xlsx",
      type: "array",
    });
    const excelData = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(excelData, fileName);
  };

  const updateLoading = () => {
    setTimeout(() => setBuffer(false), 2000);
  };

 
 
  
  const getData = async () => {
    try {
      const department = sessionStorage.getItem('department');
      const response = await axios.post(`${baseUrl}/staff/vendor/pending/list`, {
        department
      },
       {
        headers: {
          'Content-Type': 'application/json',
        },
      });
  
      if (response.data.responseCode === '00') {
        // Assuming you have a function setPendingRequests to handle the data
        setPendingRequests(response.data.data);
        return response.data.data;
      } else {
        Swal.fire('Something Went Wrong!', '', 'error');
      }
    } catch (error) {
      Swal.fire('Something Went Wrong!', '', 'error');
      return error.response.data;
    }
  };

  useEffect(() => {
    getData();
    updateLoading();
  }, []);

  return (
    <div className="container-fluid">
      <div className="row clearfix">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <label className="font-18 font-weight-700 m-t-20">
            PENDING REQUESTS
          </label>
          <div className="card">
            <div className="body">
              <div className="row filter-row m-b-10">
                <div className="col-lg-3 col-md-12 col-sm-12">
                  <div className="form-group form-focus">
                    <label>FROM DATE:</label>
                    <input
                      type="date"
                      className="form-control"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                </div>

                <div className="col-lg-3 col-md-12 col-sm-12">
                  <div className="form-group form-focus">
                    <label>TO DATE:</label>
                    <input
                      type="date"
                      className="form-control"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                </div>

                <div className="col-lg-3 col-md-12 col-sm-12">
                  <label>&nbsp;</label>
                  <div className="form-group form-focus">
                    <div className="col-lg-3 col-md-12 col-sm-12">
                      <div className="dropdown mb-50">
                        <button
                          className="btn btn-secondary "
                          type="button"
                          aria-expanded="false"
                          onClick={handleExportData}
                        >
                          Export to Excel
                        </button>
                        
                        {errorMsg ? (
                          <p className="text-danger">{errorMsg}</p>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="form-group">
                <div className="input-group input-group-transparent mb-4">
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fa fa-search" />
                    </span>
                  </div>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search by email"
                    value={search}
                    onChange={handleSearch}
                  />
                </div>
              </div>

              {buffer ? (
                <MyBulletListLoader />
              ) : (
                <div className=" table-responsive m-b-50">
                  <Table
                    className="table-striped"
                    pagination={{
                      total:  `${search === "" ? pendingRequests?.length : filteredData?.length}`,
                      showTotal: (total, range) =>
                        `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                      showSizeChanger: true,
                      onShowSizeChange: onShowSizeChange,
                      itemRender: itemRender,
                    }}
                    style={{ overflowX: "auto" }}
                    columns={approve_columns}
                    // bordered
                    dataSource={search === "" ? pendingRequests : filteredData}
                    rowKey={(record) => record.vendorId}
                    // onChange={console.log("change")}
                  />
                </div>
              )}
            </div>
            {/* <!-- </div> --> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PendingVendors;

const MyBulletListLoader = () => <BulletList />;
