import React from 'react'
import { Modal } from 'react-bootstrap'



const DocumentModal = ({
  displayImageModal,
  toggleImageModal,
  documentRef,
}) => {
  return (
    <Modal show={displayImageModal} centered backdrop="static" keyboard={false}>
      <div className="modal-90vw modal-dialog-centered modal-xl" role="document">
        <div className="modal-content">
          <div className="modal-header">
            <button
              type="button"
              className="close"
              onClick={() => toggleImageModal()}
            >
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <iframe
            src={documentRef}
            style={{ height: "600px", width: "60vw" }}
            title="Iframe Example"
          />
          {/* </div> */}
        </div>
      </div>
    </Modal>
  );
};





export default DocumentModal
