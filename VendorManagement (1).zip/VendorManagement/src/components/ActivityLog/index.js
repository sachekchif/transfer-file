import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Table, Empty } from "antd";
import { baseUrl } from "../../Utils/helper";
import { utils as XLSXUtils, write as XLSXWrite } from "xlsx";
import { saveAs } from "file-saver";
import { itemRender, onShowSizeChange } from "../Pagination";
import { BulletList } from "react-content-loader";
import { getDate, getTime } from "../../Utils/helper";

const Index = () => {
  let navigate = useNavigate();

  const role = sessionStorage.getItem("role");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [status, setStatus] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [buffer, setBuffer] = useState(true);
  const [activityLog, setActivityLog] = useState([]);
  const [search, setSearch] = useState("")
  const [filteredData, setFilteredData]= useState([])

  const handleSearch=(e)=>{
    const input = e.target.value;
    setSearch(input);
    const filtered=activityLog.filter((item)=>{
      return (
        item.vendorEmail
        .toLowerCase().toString().startsWith(input.toLowerCase().toString())
      )
    })
    setFilteredData(filtered);

  }

  const handleExportData = () => {
    if (!startDate && !endDate) {
      setErrorMsg("Please select dates");
      return;
    }
    setErrorMsg("");
    let filtered;
   if(status === "ALL REQUESTS"){
    filtered = activityLog.filter((item)=>
    getDate(item.createdAt) >= startDate &&
    getDate(item.createdAt) <= endDate
    )
   }else{
    filtered = activityLog.filter((item)=>
    getDate(item.createdAt) >= startDate &&
    getDate(item.createdAt) <= endDate && 
    item.status === status
    )
   }

    if (filtered.length < 1) {
      setErrorMsg("No data found");
      return;
    }

    const timestamp = new Date().getTime();
    const fileName = `filtered_data_${timestamp}.xlsx`;

    const workbook = XLSXUtils.book_new();
    const worksheet = XLSXUtils.json_to_sheet(filtered);
    XLSXUtils.book_append_sheet(workbook, worksheet, "Filtered Data");
    const excelBuffer = XLSXWrite(workbook, {
      bookType: "xlsx",
      type: "array",
    });
    const excelData = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(excelData, fileName);
  };

  const columns = [
    {
      title: "S/N",
      // dataIndex: "vendorId",
      render: (text, record, index) => (
        <h2 className="table-avatar">{index + 1}</h2>
      ),
    },
   
    {
      title: "VENDOR NAME",
      dataIndex: "vendorName",
      render: (text, record) => (
        <h2 className="table-avatar">{text}</h2>
      ),
    },
    {
      title: "EMAIL",
      dataIndex: "vendorEmail",
      render: (text, record) => (
        <h2 className="table-avatar">{text}</h2>
      ),
    },
    {
      title: "STATUS",
      dataIndex: "status",
      render: (text, record) => (
        <label
          className={
            text === "PENDING"
              ? "pending_class"
              : text === "REJECTED"
              ? "rejected_class"
              : text === "APPROVED"
              ? "approved_class"
              : text === "DECLINED"
              ? "declined_class"
              : ""
          }
        >
          {text}
        </label>
      ),
    },

    {
      title: "ACTIONED BY",
      render: (text, record) => (
        <div className="btn-group dropup  ">
          {role === "APPROVER" ? (
              <button
                className="btn btn-secondary"
                onClick={() =>
                  navigate(
                    `/vendormanagement/pending-view-vendor/${text.vendorId}`
                  )
                }
              >
                view
              </button>
            ) : role === "INITIATOR" ? (
              <button
                className="btn btn-secondary"
                onClick={() =>
                  navigate(
                    `/vendormanagement/view-vendor/${text.vendorId}`
                  )
                }
              >
                view
              </button>
            ) : null}
        </div>
      ),
    },
  ];

  const updateLoading = () => {
    setTimeout(() => setBuffer(false), 2000);
  };

  const getData = async () => {
    try {
      const department = sessionStorage.getItem('department');
      const response = await axios.post(`${baseUrl}/staff/activityLog`, {
        department
      },
       {
        headers: {
          'Content-Type': 'application/json',
        },
      });
  
      if (response.data.responseCode === '00') {
        // Assuming you have a function setPendingRequests to handle the data
        setActivityLog(response.data.data);
        return response.data.data;
      } else {
        Swal.fire('Something Went Wrong!', '', 'error');
      }
    } catch (error) {
      Swal.fire('Something Went Wrong!', '', 'error');
      return error.response.data;
    }
  };
  // const getData = () => {
  //   try {
  //     fetch(`${baseUrl}/staff/activityLog`, {
  //       method: "GET",
  //       mode: "cors",
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //     }).then(async (response) => {
  //       let res = await response.json();
  //       if (res.responseCode === "00") {
  //         setActivityLog(res.data);
  //         return res.data;
  //       } else {
  //         Swal.fire("Something Went Wrong!", "", "error");
  //       }
  //     });
  //   } catch (e) {
  //     Swal.fire("Something Went Wrong!", "", "error");
  //     return e.response.data;
  //   }
  // };

  useEffect(() => {
    getData();
    updateLoading();
  }, []);





  return (
    <div className="container-fluid">
      <div className="row clearfix">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <label className="font-18 font-weight-700 m-t-20">ACTIVITY LOG</label>
          <div className="card">
            <div className="body">
              <div className="row filter-row m-b-10">
                <div className="col-lg-3 col-md-12 col-sm-12">
                  <div className="form-group form-focus">
                    <label>FROM DATE:</label>
                    <input
                      type="date"
                      className="form-control"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                </div>

                <div className="col-lg-3 col-md-12 col-sm-12">
                  <div className="form-group form-focus">
                    <label>TO DATE:</label>
                    <input
                      type="date"
                      className="form-control"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                </div>

                <div className="col-lg-2 col-md-12 col-sm-12">
                  <label>&nbsp;</label>
                  <div className="form-group form-focus">
                    <div className="col-lg-3 col-md-12 col-sm-12">
                      <div className="dropdown mb-50">
                        <button
                          className="btn btn-secondary dropdown-toggle"
                          type="button"
                          data-bs-toggle="dropdown"
                          aria-expanded="false"
                        >
                          Status
                        </button>
                        <ul className="dropdown-menu">
                          <li>
                            <button
                              className="dropdown-item"
                              onClick={() => setStatus("ALL REQUESTS")}
                            >
                              All Requests
                            </button>
                          </li>
                          <li>
                            <button
                              className="dropdown-item"
                              onClick={() => setStatus("APPROVED")}
                            >
                              Approved
                            </button>
                          </li>
                          <li>
                            <button
                              className="dropdown-item"
                              onClick={() => setStatus("PENDING")}
                            >
                              Pending
                            </button>
                          </li>
                          <li>
                            <button
                              className="dropdown-item"
                              onClick={() => setStatus("REJECTED")}
                            >
                              Rejected
                            </button>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-lg-2 col-md-12 col-sm-12">
                  <label>&nbsp;</label>
                  <div className="form-group form-focus">
                    <div className="col-lg-12 col-md-12 col-sm-12">
                      <div className="dropdown mb-50">
                        <button
                          className="btn btn-secondary "
                          type="button"
                          aria-expanded="false"
                          onClick={handleExportData}
                        >
                          Export to Excel
                        </button>
                      </div>

                      {errorMsg ? (
                        <p className="text-danger">{errorMsg}</p>
                      ) : (
                        ""
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="form-group">
                <div className="input-group input-group-transparent mb-4">
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fa fa-search" />
                    </span>
                  </div>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search by email"
                    value={search}
                    onChange={handleSearch}
                  />
                </div>
              </div>

              {buffer ? (
                <MyBulletListLoader />
              ) : (
                <div className=" table-responsive m-b-50">
                  
                  <Table
                        className="table-striped"
                        pagination={{
                          total: `${search === "" ? activityLog?.length : filteredData?.length}`,
                          showTotal: (total, range) =>
                            `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                          showSizeChanger: true,
                          onShowSizeChange: onShowSizeChange,
                          itemRender: itemRender,
                        }}
                        style={{ overflowX: "auto" }}
                        columns={columns}
                        // bordered
                        dataSource={search === "" ? activityLog : filteredData}
                        rowKey={(record) => record.id}
                        // onChange={console.log("change")}
                      />
                
                </div>
              )}
            </div>
            {/* <!-- </div> --> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;

const MyBulletListLoader = () => <BulletList />;
