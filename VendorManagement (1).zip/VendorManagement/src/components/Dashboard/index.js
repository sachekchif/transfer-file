import React from "react";
import { useNavigate } from "react-router-dom";
import Lottie from "lottie-react";
import animationData from '../../assets/images/dashlogo.json'

const Dashboard = () => {
    const navigate = useNavigate()
    const role = (sessionStorage.getItem("role"));
  
    
  return (
    <div className="vertical-align-wrap">
      <div className="vertical-align-middle auth-main">
        {/* <div className="auth-box"> */}
        <div className="text-center mb-3">
          <div className="header-text mb-2">
            <h2>Welcome to Vendor Management System</h2>{" "}
          </div>
          {role === 'INITIATOR' && (
             <div>
             <div className="header-text mb-4">
               <h4>Create and Manage all your Vendors.</h4>{" "}
             </div>
             <button
              onClick={() =>
               navigate(`/vendorManagement/add-vendor`)
             }
               className="btn "
               style={{backgroundColor:"#b3cec1"}}
               aria-haspopup="true"
               aria-expanded="false"
             >
               <i className="fa fa-plus" /> Add New Vendor
             </button>
             </div>
          )}
         
          <Lottie animationData={animationData} loop={true} 
              style={{ height: 300}}
            />
          
        </div>
        {/* </div> */}
      </div>
    </div>
  );
};

export default Dashboard;
