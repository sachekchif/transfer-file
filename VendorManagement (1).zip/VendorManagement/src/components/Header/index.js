import React, { useState, useEffect, useContext } from "react";
// import { Link } from "react-router-dom";
import theImage from "../../assets/images/new_logo.png";
import { Link, useNavigate } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";

const Index = () => {
  const [name, setName] = useState("");
  const [role, setRole] = useState("");

  const navigate = useNavigate();

  useEffect(() => {
    const user = JSON.parse(sessionStorage.getItem("user"));
    const role = sessionStorage.getItem("role");

    setName(user.staffName);
    setRole(role);
  }, []);

  const deets = {
    name,
    role,
  };


  return (
    <div>
      <nav className="navbar custom-navbar navbar-expand-lg py-2 theme-white">
        <div className="container-fluid px-0">
          <Link to="#" className="menu_toggle">
            <i className="fa fa-align-left" />
          </Link>
          <div className="image">
            <Link to="/vendormanagement/dashboard">
              <img
                src={theImage}
                width={65}
                height={60}
                alt="User"
                style={{ marginRight: "100px" }}
              />{" "}
            </Link>
            <label>
              <h4>Vendor Managemement System</h4>
            </label>
          </div>
        </div>

        <div className="d-flex m-b-10">
        
          <div className="col-lg-2 col-md-12 col-sm-12">
            <div className="dropdown">
              <button
                className="btn btn-secondary dropdown-toggle"
                type="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                {/* {{name}} */}
                {deets.name}
              </button>
              <ul className="dropdown-menu">
                <li>
                  <button
                    className="dropdown-item"
                    href="#"
                    disabled
                    // onClick={() => setStatus("Pending")}
                  >
                    {deets.role}
                    {/* APPROVER */}
                  </button>
                </li>
                <li>
                  <Link
                    className="dropdown-item"
                    to="/"
                    onClick={() => {
                      toast.success("Logout Successful");
                      // navigate("/standingorder");

                      sessionStorage.clear();
                    }}
                  >
                    <i className="fa fa-sign-out" />
                    Logout
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Index;
