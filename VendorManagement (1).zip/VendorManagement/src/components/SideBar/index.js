import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";
import {BellFilled } from "@ant-design/icons";
import { Badge, Space } from "antd";
import { baseUrl } from "../../Utils/helper";
import { useEffect } from "react";

const Index = () => {
  const [pendingRequests, setPendingRequests] = useState([]);
  const role = sessionStorage.getItem("role");


  const [showVendors, setShowVendors] = useState(false);
  const [showRequests, setShowRequests] = useState(false);


  const getData = () => {
    try {
      fetch(`${baseUrl}/staff/vendor/pending/list`, {
        method: "GET",
        mode: "cors",
        headers: {
          "Content-Type": "application/json",
        },
      }).then(async (response) => {
        let res = await response.json();
        if (res.responseCode === "00") {
          setPendingRequests(res.data);
          return res.data;
        } else {
          setPendingRequests("?")
          // Swal.fire("Something Went Wrong!", "", "error");
        }
      });
    } catch (e) {
      // Swal.fire("Something Went Wrong!", "", "error");
      return e.response.data;
    }
  };
// useEffect(() => {
//   const interValid = setInterval(()=>{
//     getData()
//   },5000)

//   return () => {
//    clearInterval(interValid)
//   }
// }, [pendingRequests])


  return (
    <div className="left_sidebar">
      <nav className="sidebar">
        <ul id="main-menu" className="metismenu left_bar">
          <li>
            <Link
              to="#"
              className="has-arrow"
              onClick={() => setShowVendors(!showVendors)}
            >
              <i className="fa fa-briefcase" />
              <span>Vendors</span>
            </Link>

            {showVendors && (
              <ul>
                <li>
                  <Link to="/vendorManagement/all-vendors">
                    <i className="fa fa-check" />
                    All vendors
                  </Link>
                </li>

                <li>
                  <Link to="/vendorManagement/blacklisted-vendors">
                    <i className="fa fa-ban" />
                    Blacklisted{" "}
                  </Link>
                </li>
              </ul>
            )}
          </li>
          <li>
            <Link
              to="#"
              className="has-arrow"
              onClick={() => setShowRequests(!showRequests)}
            >
              <i className="ti-files" />
              <span>All Requests</span>
            </Link>

            {showRequests && (
              <ul>
                <li>
                  <Link to="/vendorManagement/approved-requests">
                    <i className="fa fa-check" />
                    Approved
                  </Link>
                </li>
                {role === 'INITIATOR' && 
                <li>
                <Link to="/vendorManagement/preapproved-requests">
                  <i className="fa fa-history" />
                  Pre-Approved
                </Link>
              </li>
                }
                

                <li>
                  <Link to="/vendorManagement/rejected-requests">
                    <i className="fa fa-times" />
                    Rejected
                  </Link>
                </li>

                {role !== "INITIATOR" && (
                  <div className="d-flex">
                    <li>
                      <Link to="/vendorManagement/pending-requests">
                        <i className="fa fa-history" />
                        Pending
                      </Link>
                    </li>
                    {/* <Space size="middle">
                      <Badge count={pendingRequests.length} size="small">
                        <BellFilled style={{ fontSize: "20px", color:"gray"}} />
                      </Badge>
                    </Space> */}
                  </div>
                )}
              </ul>
            )}
          </li>

          <li>
            <Link to="/vendorManagement/activity-log">
              <i className="fa fa-bell" />
              Activity Log
            </Link>
          </li>

          <li>
            <Link
              to="/"
              onClick={() => {
                toast.success("Logout Successful");
                sessionStorage.clear();
              }}
            >
              <i className="fa fa-sign-out" />
              Logout
            </Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Index;
