import React, {useEffect} from 'react';
import { BrowserRouter  } from "react-router-dom";
import '../src/assets/css/style.css'
import { fetchBankBranches } from './services/ui-slice';
import { useDispatch } from 'react-redux';



import RouteComponent from './routes';


function App() {
 

  return (
    <BrowserRouter>
    <RouteComponent />
    </BrowserRouter>
  );
}

export default App;
