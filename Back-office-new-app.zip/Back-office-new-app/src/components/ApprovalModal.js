import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { approveSavings } from "../services/savingsAcct/approveSlice";
import { useNavigate } from "react-router-dom";
import Loader from "./Loader";

const ApprovalModal = ({ id }) => {
  const  {loading, user, error} = useSelector((state)=> state.approveSavings)

  
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const staffId = "264";
  

  const handleApprove = () => {
    dispatch(approveSavings( {id, staffId,navigate}));
  };
  

  return (
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h1 className="modal-title fs-5" id="approveModalLabel">
            Approve Request?
          </h1>
          <button
            type="button"
            className="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
          ></button>
        </div>
        <div className="modal-body">
          Do you confirm that you want to Approve this Request?
        </div>
        <div className="modal-footer">
          <button
            type="button"
            className="btn btn-secondary"
            data-bs-dismiss="modal"
          >
            Close
          </button>
          <button
            onClick={handleApprove}
            type="button"
            className="btn btn-primary"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
};

export default ApprovalModal;
