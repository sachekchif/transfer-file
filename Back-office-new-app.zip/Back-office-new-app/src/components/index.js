import Sidebar from "./Sidebar";
import SavingsAccount from "./SavingsAccount";
import CorporateAccount from "./CorporateAccount";
import KiddiesAccount from "./KiddiesAccount";
import ChartDisplay from "./ChartComponent";
import Cards from "./Cards";
import Filter from "./Filter";
import DrawerComponent from "./Drawer";
import SavingsAcctDetails from "./SavingsDetails";
import CustomerDocTab from "./CustomerDocTab";
import CustomerInfoTab from "./CustomerInfoTab";
import ApprovalModal from "./ApprovalModal";
import RejectionModal from "./RejectionModal";
import TabItem from "./Tab";
import CorporateCusInfoTab from "./CorporateCusInfoTab";
import CorporateCusDocTab from "./CorporateCusDocTab";
import CorporateDirTab from "./CorporateDirTab";
import DirectorInfoTab from "./DirectorInfoTab";
import DirectorDocumentsTab from "./DirectorDocumentsTab";
import ChildInfoTab from "./ChildInfoTab";
import ChildDocTab from "./CustomerDocTab";
import GuardianDetails from "./GuardianDetails";
import GuardianInfoTab from "./GuardianInfoTab";
import GuardianDocTab from "./GuardianDocTab";
import Loader from "./Loader";
import DocumentModal from "./DocumentModal";



export {
  Sidebar,
  SavingsAccount,
  CorporateAccount,
  KiddiesAccount,
  ChartDisplay,
  Cards,
  Filter,
  DrawerComponent,
  SavingsAcctDetails,
  CustomerDocTab,
  CustomerInfoTab,
  ApprovalModal,
  RejectionModal,
  TabItem,
  CorporateCusInfoTab,
  CorporateCusDocTab,
  CorporateDirTab,
  DirectorInfoTab,
  DirectorDocumentsTab,
  ChildInfoTab,
  ChildDocTab,
  GuardianDetails,
  GuardianInfoTab,
  GuardianDocTab,
  Loader,
  DocumentModal
};
