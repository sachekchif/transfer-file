import React, {useState, useEffect} from "react";
import { Table } from "antd";
import wordDoc from "../assets/images/word.svg";
import pdfDoc from "../assets/images/adobe-pdf-icon.svg";
import imgDoc from "../assets/images/gallery.svg";
import davidPdf from "../assets/images/david.pdf";
import { itemRender, onShowSizeChange } from "./Pagination";
import { useSelector } from "react-redux";
import { getDate } from "../utils";
import DocumentModal from "./DocumentModal";

const dat = [
    {
      id: 1,
      documentTitle: "NIN Document",
      documentType: wordDoc,
      UpdatedBy: "James Ogbemudian",
      uploadedDate: "Uploaded on 27-09-2023",
    },
    {
      id: 2,
      documentTitle: "International Passport",
      documentType: pdfDoc,
      UpdatedBy: "James Ogbemudian",
      uploadedDate: "Uploaded on 27-09-2023",
    },
    {
      id: 3,
      documentTitle: "Utility Bill",
      documentType: imgDoc,
      UpdatedBy: "James Ogbemudian",
      uploadedDate: "Uploaded on 27-09-2023",
    },
  ];

 
const DirectorDocumentsTab = () => {
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [viewDocument, setViewDocument] = useState(false);

  const  {loading, error, data} = useSelector((state)=> state.getCorporateDir)
console.log({data})
  const documentsArray = data.dircUpload.map((item)=> item.documentList).flat()[0]
  console.log(documentsArray)

 const openDocumentModal = (documentRef) => {
    setSelectedDocument(documentRef);
    setViewDocument(true);
  };
  const columns = [
    // {
    //   title: "Document Type",
     
    //   dataIndex: "documentType",
    //   render: (text, record, index) => (
    //     <div>
    //       <img
    //         src={text}
    //         className="img-fluid rounded-start"
    //         width="50px"
    //         height="50px"
    //       />
    //     </div>
    //   ),
    // },
  
    {
      title: "Title",
      dataIndex: "documentName",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "Uploaded By",
      dataIndex: "createdDate",
      render: (text, record) => <p className="table-avatar">{getDate(text)}</p>,
    },
  
    {
      title: "Action",
      title: () => (
        <div className="text-center">
         Action
        </div>
      ),
      render: (text, record) => (
        <div className="d-flex align-items-center justify-content-center">
          <button
            type="button"
            className="btn btn-sm btn-outline-primary me-3 col-lg-5 col-md-4 col-sm-12"
            data-bs-toggle="modal"
            data-bs-target="#documentModal"
            onClick={() =>
              openDocumentModal(text.doc)
            }
          >
            View
          </button>
  
          <button
            type="button"
            className="btn btn-sm btn-outline-danger me-3 col-lg-5 col-md-6 col-sm-12"
            data-bs-toggle="modal"
            data-bs-target="#deleteModal"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];
  


  return (
    <div>
      <div
        className="main-tab-content"
        style={{ height: "auto", overflowY: "auto", overflowX: "hidden" }}
      >
        <div className="row">
        <div className="table-responsive border-primary mb-5">
    
    <Table
      className="table-striped"
      pagination={{
        total: { documentsArray },
        showTotal: (total, range) =>
          `Showing ${range[0]} to ${range[1]} of ${total} entries`,
        showSizeChanger: true,
        onShowSizeChange: onShowSizeChange,
        itemRender: itemRender,
      }}
      style={{ overflowX: "auto" }}
      columns={columns}
      dataSource={documentsArray}
      rowKey={(record) => record.id}
    
    />
  </div>
        </div>
      <DocumentModal document={selectedDocument} />

        <div
          className="modal fade"
          id="deleteModal"
          tabindex="-1"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h1 className="modal-title fs-5" id="exampleModalLabel">
                  Delete Document
                </h1>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div className="modal-body">
                Are you sure you want to Delete this Document?
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Close
                </button>
                <button type="button" className="btn btn-primary">
                  Save changes
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DirectorDocumentsTab