import React from "react";
import { useSelector } from "react-redux";

const DirectorInfoTab = () => {
  const  {loading, error,data} = useSelector((state)=> state.getCorporateDir)
  return (
    <div>
      <div
        class="main-tab-content"
        style={{ height: "auto", overflowY: "auto", overflowX: "hidden" }}
      >
        <div class="row">
          <div class="form-group col-4  mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Fullname</label>
              <h5>
                <strong>{data.directorName}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">BVN</label>
              <h5>
                <strong>{data.bvn ? data.bvn : 'N/A'}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Email Address</label>
              <h5>
                <strong>{data.emailAddress ? data.emailAddress: 'N/A'}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Date of Birth</label>
              <h5>
                <strong>{data.dateOfBirth}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Gender</label>
              <h5>
                <strong>{data.gender}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Address</label>
              <h5>
                <strong>
                 {data.address}
                </strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Country of Origin</label>
              <h5>
                <strong>{data.countryofOrigin ? data.countryofOrigin :'N/A' }</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">State of Origin</label>
              <h5>
                <strong>{data.stateOfOrigin}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">
                Local Government Area
              </label>
              <h5>
                <strong>{data.localGovernment}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">State of Residence</label>
              <h5>
                <strong>{data.stateOfResidence ? data.stateOfResidence :'N/A' }</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">
                Identification Type
              </label>
              <h5>
                <strong>{data.identificationType}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">ID Number</label>
              <h5>
                <strong>{data.idNumber}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Date of Issue</label>
              <h5>
                <strong>{data.dateOfIssue ? data.dateOfIssue : 'N/A'}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Place of Issue</label>
              <h5>
                <strong>{data.placeIssue}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Marital Status</label>
              <h5>
                <strong>{data.maritalStatus ? data.maritalStatus :'N/A' }</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Religion</label>
              <h5>
                <strong>{data.religion}</strong>
              </h5>
            </div>
          </div>

          <h4 class="mt-5 mb-3">Next of Kin</h4>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Name</label>
              <h5>
                <strong>{data.nextofKinName ? data.nextofKinName :'N/A'}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Phone Number</label>
              <h5>
                <strong>{data.nextofKinPhoneNumber ? data.nextofKinPhoneNumber :'N/A' }</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Relationship</label>
              <h5>
                <strong>{data.relationShip ? data.relationShip : 'N/A' }</strong>
              </h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DirectorInfoTab;
