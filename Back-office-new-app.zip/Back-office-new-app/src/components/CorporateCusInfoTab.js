import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { getDate } from "../utils";

const CorporateCusInfoTab = () => {
  const { data } = useSelector((state) => state.singleCorporate);
  const { loading, branch } = useSelector((state) => state.ui);
  console.log({ branch, loading });

  const getBranchName = (brCode) => {
    if (!branch || branch.length === 0) {
      return;
    }

    const matchingBranch = branch.find((bran) => bran.value === brCode);
    return matchingBranch ? matchingBranch.text : null;
  };

  return (
    <div
      className="tab-pane active"
      id="timeline"
      role="tabpanel"
      aria-labelledby="timeline-tab"
      tabindex="0"
    >
      <div
        className="main-tab-content"
        style={{ height: "auto", overflowY: "auto", overflowX: "hidden" }}
      >
        <div className="row">
          <div className="form-group col-12 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">Account Status</label>
              <h5>
                <div className="card-text acct-success">
                  <span>
                    <i className="bi bi-dot text-success"></i>
                  </span>
                  {data.status}
                </div>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">Business Name</label>
              <h5>
                <strong>{data.businessName}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">Email Address</label>
              <h5>
                <strong>{data.emailAddress}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">Tin No</label>
              <h5>
                <strong>{data.tin}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">Phone Number</label>
              <h5>
                <strong>{data.phoneNumber}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">RC Number</label>
              <h5>
                <strong>{data.rcNumber}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">
                Account Currency
              </label>
              <h5>
                <strong>{data.accountCurrency}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">
                Preferred Branch
              </label>
              <h5>
                <strong>{getBranchName(data.preferedBranch)}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">Scuml Number</label>
              <h5>
                <strong>{data.scumlNumber}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">
                Date of Registration
              </label>
              <h5>
                <strong>{data.dateofRegistration}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">
                Expected Monthly Turnover
              </label>
              <h5>
                <strong>{data.expectedMonthlyTurnover}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">
                Purpose of Account
              </label>
              <h5>
                <strong>{data.purposeofAccount}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">Date Created</label>
              <h5>
                <strong>{getDate(data.createdDate)}</strong>
              </h5>
            </div>
          </div>

          <div className="form-group col-4 mb-3">
            <div className="d-flex flex-column">
              <label className="text-secondary fs-6 mb-2">Account Number</label>
              <h5>
                <strong>{data.accountNumber}</strong>
              </h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CorporateCusInfoTab;
