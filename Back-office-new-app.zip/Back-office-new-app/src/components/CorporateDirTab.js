import React, {useState, useEffect } from "react";
import { Table } from "antd";
import { itemRender, onShowSizeChange } from "./Pagination";
import { Link, useParams } from "react-router-dom";
import { fetchSingleDir } from "../services/corporateSavings/getDirDetailsSlice";
import { useSelector, useDispatch } from "react-redux";


  
const CorporateDirTab = () => {
  const [coporateData, setCorporateData] = useState([])
  const { id } = useParams();
  const staffId = "264";
  const dispatch = useDispatch();

  const  {loading, error,data} = useSelector((state)=> state.getCorporateDir)
  console.log({data})
console.log('hello world')
  useEffect(()=>{
    dispatch(fetchSingleDir({id, staffId}))
    setCorporateData(data.dircUpload)
  },[])
  console.log({coporateData})
    const columns = [
        {
          title: "Title",
          dataIndex: "title",
          render: (text, record, index) => (
           <div className="mb-1">Mr</div>
          ),
        },
    
        {
          title: "Fullname",
          dataIndex: "directorName",
          render: (text, record) => <p className="table-avatar">{text}</p>,
        },
        {
          title: "Email Address",
          dataIndex: "email",
          render: (text, record) => <p className="table-avatar">email</p>,
        },
        {
          title: "BVN",
          dataIndex: "directorBVN",
          render: (text, record) => <p className="table-avatar">{text}</p>,
        },
        {
          title: "Action",
          render: (text, record) => (
            <div className="btn-group dropup  ">
              <Link to={`/corporate-details-dir/${id}`}
                // onClick={showDrawer}
                className="btn text-white btn-primary btn-sm"
              >
                <span className="mx-3">View</span>
              </Link>
            </div>
          ),
        },
      ];
  return (
    <div>
      <div className="tab-content">
        <div
          className="tab-pane active"
          id="director-info"
          role="tabpanel"
          aria-labelledby="director-info-tab"
          tabindex="0"
        >
          <div className="input-group mb-3">
            <input
              type="text"
              className="form-control search"
              placeholder="Search a Keyword"
              aria-label="Username"
              aria-describedby="basic-addon1"
            />
            <span className="input-group-text">
              <i className="bi bi-search"></i>
            </span>
          </div>
          {/* </div> --> */}

          <div
            className="main-tab-content mb-3"
            style={{height:"auto", overflowY:"auto", overflowX:"hidden"}}
          >
            <div className="row">
              <div className="table-responsive border-primary mb-5">
              <Table
                  className="table-striped"
                  pagination={{
                    total: { coporateData },
                    showTotal: (total, range) =>
                      `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                    showSizeChanger: true,
                    onShowSizeChange: onShowSizeChange,
                    itemRender: itemRender,
                  }}
                  style={{ overflowX: "auto" }}
                  columns={columns}
                  // bordered
                  dataSource={coporateData}
                  rowKey={(record) => record.id}
                  // onChange={console.log("change")}
                />

               
              </div>
            </div>
          </div>
        </div>
      </div>

    
    </div>
  );
};

export default CorporateDirTab;
