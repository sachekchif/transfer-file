import React from 'react'

const DocumentModal = ({document}) => {
  return (
    <div
    className="modal"
    id="documentModal"
    tabindex="-1"
    aria-labelledby="documentModalLabel"
    aria-hidden="true"
  >
    <div className="modal-dialog modal-xl">
      <div className="modal-content">
        <div className="modal-header">
        

          <button
            type="button"
            className="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
          ></button>
        </div>

        <div className="modal-body">
          <iframe
            src={document}
            style={{ width: "100%", height: "500px" }}
          ></iframe>
        </div>

        <div className="modal-footer">
          <button
            type="button"
            className="btn btn-danger"
            data-bs-dismiss="modal"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  </div>
  )
}

export default DocumentModal