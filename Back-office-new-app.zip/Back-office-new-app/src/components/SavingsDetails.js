import React from 'react'

const SavingsAcctDetails = () => {
  return (
    <div>ViewProfile</div>
  )
}

export default SavingsAcctDetails