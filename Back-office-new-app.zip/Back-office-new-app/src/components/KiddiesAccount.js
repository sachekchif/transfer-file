import React from 'react'

const KiddiesAccount = () => {
  return (
    <div>KiddiesAccount</div>
  )
}

export default KiddiesAccount