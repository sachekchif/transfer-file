import React from 'react'

const InstantSavings = () => {
  return (
    <div>InstantSavings</div>
  )
}

export default InstantSavings