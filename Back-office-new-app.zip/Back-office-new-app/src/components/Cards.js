import React, {useState, useEffect} from 'react'
import Card from './card'
import { nearestThousand } from '../utils'
import { fetchUsers } from '../services/instantSavings/instantSlice'
import { fetchSavings } from '../services/savingsAcct/savingsSlice'
import { fetchCurrentUsers } from '../services/currentSavings/currentSlice'
import { fetchCorporateUsers } from '../services/corporateSavings/corporateSlice'
import { fetchKiddiesUsers } from '../services/kiddiesSavings/kiddiesSlice'
import { useDispatch, useSelector } from 'react-redux'
import { calculatePercentageIncrease } from '../utils'



const Cards = (props) => {
    const [cardDetails, setCardDetails] =useState( [
        {
            id:1,
            title:"Instant Savings",
            totalAcct:0,
            acctPercent:"20%",
            icon:"fas fa-piggy-bank",
            iconColor:"icon-bg-peach",
            bgColor:"hsl(6, 100%, 95%)",
            url:'/instant-savings'
           
        },
        {
            id:2,
            title:"Savings Account",
            totalAcct:0,
            acctPercent:"20%",
            icon:"fas fa-university",
            iconColor:"icon-bg-blue",
            bgColor:"hsl(213, 82%, 95%)",
            url:'/savings-account'
           
        },
        {
            id:3,
            title:"Current Accounts",
            totalAcct:0,
            acctPercent:"20%",
            icon:"fas fa-user-tie",
            iconColor:"icon-bg-yellow",
            bgColor:"hsl(48, 100%, 95%)",
            url:'/current-account'
         
        },
        {
            id:4,
            title:"Corporate Accounts",
            totalAcct:0,
            acctPercent:"20%",
            icon:"fas fa-briefcase",
            iconColor:"icon-bg-cyan",
            bgColor:"hsl(180, 58%, 95%)",
            url:'/corporate-account'
           
    
    
        },
        // {
        //     id:5,
        //     title:"Kiddies Account",
        //     totalAcct:0,
        //     acctPercent:"20%",
        //     icon:"fas fa-child",
        //     iconColor:"icon-bg-purple",
        //     bgColor:"hsl(282, 80%, 95%)",
        //     url:'/kiddies-account'
           
        // },
        
    ])
  
const [totalInstantAcct, setTotalInstantAcct] = useState(0)
const [staffId, setStaffId] = useState('')
const [currentMonth, setCurrentMonth] = useState([])
const [previousMonth, setPreviousMonth] = useState([])
const user = JSON.parse(localStorage.getItem('user'))
const dispatch = useDispatch();

const kiddiesData = useSelector(
    (state) => state.kiddies.data
  );
const currentAccountData = useSelector(
    (state) => state.currentAccount.data
  );


const InstantSavings = useSelector((state) => state.instant.data);
const savingsData = useSelector(
    (state) => state.savings.data
  );

  const corporateSavingsData = useSelector(
    (state) => state.getAllCorporate.data
  );

  useEffect(()=>{
    const getDataForMonths = ()=>{
        const currentDate = new Date();
        const currentMonth = currentDate.getMonth();
        const lastMonth = new Date(currentDate)
        lastMonth.setMonth(lastMonth.getMonth() - 1)

        const currentMonthData = corporateSavingsData.filter((item)=> new Date(item.currentDate).getMonth() === currentMonth)

        const previousMonthData = corporateSavingsData.filter(
            (item) =>
              new Date(item.createdDate
                ).getMonth() === lastMonth.getMonth() &&
              new Date(item.createdDate
                ).getFullYear() === lastMonth.getFullYear()
          );
          setCurrentMonth(currentMonthData);
          setPreviousMonth(previousMonthData);
    }
    getDataForMonths();
  },[corporateSavingsData,currentAccountData,savingsData,InstantSavings])

 
  const percentageIncrease = calculatePercentageIncrease(
    currentMonth,
    previousMonth
  );

  console.log({percentageIncrease,corporateSavingsData})

  useEffect(()=>{
    dispatch(fetchKiddiesUsers(staffId));
  },[])

  useEffect(()=>{
    dispatch(fetchCorporateUsers(staffId));
  },[dispatch, staffId])

  useEffect(()=>{
    dispatch(fetchCurrentUsers(staffId));
  },[dispatch, staffId])

  useEffect(() => {
    dispatch(fetchSavings(staffId));
  
  }, [dispatch, staffId]);

  useEffect(()=>{
    setStaffId(user.staffId)
   },[])

//   console.log({data})

useEffect(() => {
    const InstantSum = InstantSavings.length;
    const SavingsSum = savingsData.length;
    const currentAcctSum = currentAccountData.length;
    const corporateSum = corporateSavingsData.length;
    // const kiddiesSum = kiddiesData.length; 
    console.log({currentAcctSum})
    console.log({SavingsSum})
   
    const updatedCardDetails = cardDetails.map((card) => {
        if (card.title === "Instant Savings") {
          return {
            ...card,
            totalAcct: InstantSum,
          };
        }
        if (card.title === "Savings Account") {
            return {
              ...card,
              totalAcct: SavingsSum,
            };
          }
          if (card.title === "Current Accounts") {
            return {
              ...card,
              totalAcct: currentAcctSum,
            };
          }
          if (card.title === "Corporate Accounts") {
            return {
              ...card,
              totalAcct: corporateSum,
            };
          }
          // if (card.title === "Kiddies Account") {
          //   return {
          //     ...card,
          //     totalAcct: kiddiesSum,
          //   };
          // }
        return card;
      });
     
      setCardDetails(updatedCardDetails);
  }, [dispatch, staffId]);

  useEffect(()=>{
    dispatch(fetchUsers(staffId));
  
    setTotalInstantAcct(InstantSavings)
},[dispatch, staffId])

console.log({totalInstantAcct})


  return (
    <div className='row mb-5 g-3'>
        {cardDetails.map((card)=>
         <Card 
         key={card.id}
         url={card.url}
         title={card.title}
         totalAccts={nearestThousand(card.totalAcct)}
         acctPercent={card.acctPercent}
         icon={card.icon}
         iconColor={card.iconColor}
         color={card.bgColor}
     

         />
        )}
        
    </div>
   
  )
}

export default Cards