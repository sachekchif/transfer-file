
import React from 'react'
import { LineChart,Legend, Line,ResponsiveContainer,AreaChart,Area, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';

const data = [
    { month: "Jan", value: 400 },
    { month: "Feb", value: 300 },
    { month: "Mar", value: 600 },
    { month: "Apr", value: 800 },
    { month: "May", value: 900 },
    { month: "Jun", value: 1200 },
    { month: "Jul", value: 1500 },
    { month: "Aug", value: 1800 },
    { month: "Sep", value: 2000 },
    { month: "Oct", value: 1700 },
    { month: "Nov", value: 1000 },
    { month: "Dec", value: 800 },
  ];

  const CustomTooltip = ({ active, payload, label }) => {
  if (active) {
    // Customize the content of the tooltip here
    return (
      <div
        style={{
          width: "200px",
          height: "103px",
          backgroundColor: "#ffffff",
          padding: "15px 0 0 15px",
         
          
        }}
      >
        <p style={{ fontSize: "12px", color: "grey" }}>Amount</p>
        <p style={{ fontSize: "20px", fontWeight: 500 }}>
          {payload[0].value}
        </p>
        <p
          style={{ fontSize: "14px", color: "grey" }}
        >{`${label}, 2021`}</p>
      </div>
    );
  }
  return null;
};
const ChartDisplay = ({height}) => {
  return (
    <ResponsiveContainer width="100%" height={height}>
     <AreaChart 
      data={data}
      margin={{
        top: 10,
        right: 30,
        left: 0,
        bottom: 0
      }}
    >
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="month" />
      <YAxis />
      <Tooltip />
      <Area type="monotone" dataKey="value" stroke="#8884d8" fill="#8884d8" />
    </AreaChart>
    </ResponsiveContainer>
  
 
  )
}

export default ChartDisplay