
import React, { useState } from 'react';
import { Button, Drawer, Radio, Space } from 'antd';
import { useDispatch,useSelector  } from 'react-redux';
import { uiActions } from '../services/ui-slice';

const DrawerComponent = (props) => {
  const {children, title,id} = props
 
    const dispatch = useDispatch()
    const drawerState = useSelector((state)=> state.ui.drawerIsVisible)
    const [placement, setPlacement] = useState('right');
   
    const onClose = () => {
      dispatch(uiActions.toggle())
    };
    const onChange = (e) => {
      setPlacement(e.target.value);
    };
  return (
    <div>
      
      <Drawer
        id={id}
        title={title}
        placement={placement}
        closable={false}
        onClose={onClose}
        open={drawerState}
        key={placement}
      >
        {children}
      </Drawer>
    </div>
  )
}

export default DrawerComponent