import React from "react";
import { useSelector, useDispatch } from "react-redux";

const ChildInfoTab = () => {
  const { data } = useSelector((state) => state.getSingleKiddies);
  const { loading, branch } = useSelector((state) => state.ui);

  const getBranchName = (brCode) => {
    if (!branch || branch.length === 0) {
      return;
    }

    const matchingBranch = branch.find((bran) => bran.value === brCode);
    return matchingBranch ? matchingBranch.text : null;
  };
  return (
    <div>
      <div
        class="main-tab-content"
        style={{ height: "auto", overflowY: "auto", overflowX: "hidden" }}
      >
        <div class="row">
          <div class="form-group col-12  mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Status</label>
              <h5>
                <div class="card-text acct-warning">{data.status}</div>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">
                Modified By - Staff ID
              </label>
              <h5>
                <strong>{data.modifiedBy}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Fullname</label>
              <h5>
                <strong>{data.fullName}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Email Address</label>
              <h5>
                <strong>{data.email}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Address</label>
              <h5>
                <strong>{data.customerAddress}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Gender</label>
              <h5>
                <strong>{data.gender}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Date of Birth</label>
              <h5>
                <strong>{data.dateOfBirth}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Phone Number</label>
              <h5>
                <strong>{data.phoneNumber}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Place of Birth</label>
              <h5>
                <strong>{data.placeOfBirth}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">State of Origin</label>
              <h5>
                <strong>{data.stateOfOrigin}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">State of Residence</label>
              <h5>
                <strong>{data.stateOfResidence}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">
                Local Government Area
              </label>
              <h5>
                <strong>{data.lga}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Religion</label>
              <h5>
                <strong>{data.religionDescription}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Account Number</label>
              <h5>
                <strong>{data.accountNumber}</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Document ID Number</label>
              <h5>
                <strong>{data.idNumber}</strong>
              </h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChildInfoTab;
