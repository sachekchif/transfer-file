import React from "react";

const GuardianInfoTab = () => {
  return (
    <div
      class="tab-pane active"
      id="guardian"
      role="tabpanel"
      aria-labelledby="guardian-tab"
      tabindex="0"
    >
      <div
        class="main-tab-content"
        style={{height:"auto", overflowY:"auto", overflowX:"hidden"}}
      >
        <div class="row">
          <div class="form-group col-4  mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Fullname</label>
              <h5>
                <strong>James Majekodunmi</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Email Address</label>
              <h5>
                <strong>daddysemail@gmail.com</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">BVN</label>
              <h5>
                <strong>13994039823</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Gender</label>
              <h5>
                <strong>Male</strong>
              </h5>
            </div>
          </div>

          <div class="form-group col-4 mb-3">
            <div class="d-flex flex-column">
              <label class="text-secondary fs-6 mb-2">Introducer Code</label>
              <h5>
                <strong>STB0419</strong>
              </h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GuardianInfoTab;
