import React from 'react'

const CorporateAccount = () => {
  return (
    <div>CorporateAccount</div>
  )
}

export default CorporateAccount