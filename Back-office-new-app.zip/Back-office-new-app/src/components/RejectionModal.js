import React from 'react'

const RejectionModal = () => {
  return (
    <div className="modal-dialog">
    <div className="modal-content">
      <div className="modal-header">
        <h1 className="modal-title fs-5" id="rejectModalLabel">
          Are you sure you want to Reject this Customer?
        </h1>
        <button
          type="button"
          className="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
        ></button>
      </div>

      <div className="modal-body">
        <label className="text-secondary mb-5">
          This action cannot be undone. Please provide a reason
          for rejecting the customer below:
        </label>
        <div className="">
          <textarea
            className="form-control"
            id=""
            rows="2"
            style={{width:"100%", resize: "none"}}
          ></textarea>
        </div>
      </div>

      <div className="modal-footer">
        <button
          type="button"
          className="btn btn-outline-danger"
          data-bs-dismiss="modal"
        >
          Close
        </button>
        <button type="button" className="btn btn-primary">
          Confirm
        </button>
      </div>
    </div>
  </div>
  )
}

export default RejectionModal