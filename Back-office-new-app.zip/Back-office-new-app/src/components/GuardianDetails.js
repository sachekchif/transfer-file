import React from "react";
import { itemRender, onShowSizeChange } from "./Pagination";
import { Table } from "antd";

const data = [
  {
    id: 1,
    fullName: "John Majekodunmi Doe",
    gender: "Male",
    email: "daddysemail@gmail.com",
    bvn: "91394924824",
    introducerCode: "STN0024",
  },
  {
    id: 2,
    fullName: "Joan Ofuobi Odinaka",
    gender: "Female",
    email: "daddysemail@gmail.com",
    bvn: "91394924824",
    introducerCode: "STN0024",
  },
];

const columns = [
  {
    title: "Fullname",

    dataIndex: "fullName",
    render: (text, record) => <p className="table-avatar">{text}</p>,
  },

  {
    title: "Email Address",
    dataIndex: "email",
    render: (text, record) => <p className="table-avatar">{text}</p>,
  },
  {
    title: "Introducer Code",
    dataIndex: "introducerCode",
    render: (text, record) => <p className="table-avatar">{text}</p>,
  },

  {
    title: "Action",
    render: (text, record) => (
      <button
        type="button"
        className="btn btn-sm btn-outline-primary me-3 col-lg-5 col-md-4 col-sm-12"
       
      >
        View
      </button>
    ),
  },
];
const GuardianDetails = () => {
  return (
    <div>
      {/* <!-- Tab Content for the Guardian Information Tabs Shows Here  --> */}
      <div className="tab-content">
        {/* <!-- Guardian Information Tab Content  --> */}
        {/* <!-- <div className="tab-pane active" id="guardian-info" role="tabpanel" aria-labelledby="guardian-info-tab" tabindex="0"> --> */}

        <div
          className="main-tab-content mb-3"
          style={{ height: "auto", overflowY: "auto", overflowX: "hidden" }}
        >
          <div className="row">
            <div className="table-responsive border-primary mb-5">
              <Table
                className="table-striped"
                pagination={{
                  total: { data },
                  showTotal: (total, range) =>
                    `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                  showSizeChanger: true,
                  onShowSizeChange: onShowSizeChange,
                  itemRender: itemRender,
                }}
                style={{ overflowX: "auto" }}
                columns={columns}
                dataSource={data}
                rowKey={(record) => record.id}
              />
            </div>
          </div>
        </div>
        {/* <!-- </div> --> */}
      </div>
    </div>
  );
};

export default GuardianDetails;
