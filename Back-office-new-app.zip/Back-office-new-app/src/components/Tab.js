import React from 'react'

const TabItem = ({ active, onClick, id, target, icon, text }) => (
    <li className="nav-item" role="presentation">
      <button
        className={`nav-link ${active ? 'active' : ''}`}
        id={id}
        data-bs-toggle="tab"
        data-bs-target={target}
        type="button"
        role="tab"
        aria-controls={target.slice(1)}
        aria-selected={active}
        onClick={onClick}
      >
        <i className={icon}></i>
        {text}
      </button>
    </li>
  );

export default TabItem