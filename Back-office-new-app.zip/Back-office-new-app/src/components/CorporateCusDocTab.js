import React, {useState, useEffect } from "react";
import { Table } from "antd";
import wordDoc from "../assets/images/word.svg";
import pdfDoc from "../assets/images/adobe-pdf-icon.svg";
import imgDoc from "../assets/images/gallery.svg";
import davidPdf from "../assets/images/david.pdf";
import { itemRender, onShowSizeChange } from "./Pagination";
import { useSelector, useDispatch } from "react-redux";
import { fetchCustDoc } from "../services/corporateSavings/getCustomerDocSlice";
import { Link, useParams, useNavigate } from "react-router-dom";
import DocumentModal from "./DocumentModal";
import { getDate } from "../utils";





const CorporateCusDocTab = () => {
  const { id } = useParams();
  const [selectedDocument, setSelectedDocument]= useState(null)
  const [staffId, setStaffId] = useState('')
  const dispatch = useDispatch();
  const user = JSON.parse(localStorage.getItem('user'))
  const { loading, error, data } = useSelector(
    (state) => state.customerDoc
  );
  const openDocumentModal =(documentRef)=>{
    setSelectedDocument(documentRef)
  }
  console.log({data})

  useEffect(()=>{
    setStaffId(user.staffId)
   },[])

  useEffect(()=>{
    dispatch(fetchCustDoc({staffId, id}))
  },[])

  return (
    <div>
      <div
        className="main-tab-content"
        style={{ height: "auto", overflowY: "auto", overflowX: "hidden" }}
      >
        <div className="row">
          <div className="table-responsive border-primary mb-5">
            <table
              className="table table-hover mb-5"
              style={{ wordWrap: "normal", height: "auto" }}
            >
              <thead>
                <tr className="bg-secondary-subtle">
                  <th>Document Type</th>
                  <th>Title</th>
                  <th>Date Uploaded</th>
                  <th class="text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                  {(data?.documentType)}
                  </td>
                  <td>{data?.documentType}</td>
                  <td>
                  {getDate(data?.createdDate)}
                  </td>
                  <td>
                    <div className="d-flex align-items-center justify-content-center">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-primary me-3 col-lg-5 col-md-4 col-sm-12"
                        data-bs-toggle="modal"
                        data-bs-target="#documentModal"
                        onClick={()=>openDocumentModal(data?.documentData)}
                      >
                        View
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-danger me-3 col-lg-5 col-md-6 col-sm-12"
                        data-bs-toggle="modal"
                        data-bs-target="#deleteModal"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* <div className="row">
          <div className="table-responsive border-primary mb-5">
            <Table
              className="table-striped"
              pagination={{
                total: { dat },
                showTotal: (total, range) =>
                  `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                showSizeChanger: true,
                onShowSizeChange: onShowSizeChange,
                itemRender: itemRender,
              }}
              style={{ overflowX: "auto" }}
              columns={columns}
              dataSource={dat}
              rowKey={(record) => record.id}
            />
          </div>
        </div> */}

    <DocumentModal document={selectedDocument} />

        <div
          className="modal fade"
          id="deleteModal"
          tabindex="-1"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h1 className="modal-title fs-5" id="exampleModalLabel">
                  Delete Document
                </h1>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <div className="modal-body">
                Are you sure you want to Delete this Document?
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Close
                </button>
                <button type="button" className="btn btn-primary">
                  Save changes
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CorporateCusDocTab;
