import React from 'react'

const SavingsAccount = () => {
  return (
    <div>SavingsAccount</div>
  )
}

export default SavingsAccount