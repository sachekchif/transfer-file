import React, { useState, useEffect } from "react";
import { Table } from "antd";
import { useSelector } from "react-redux";
import { itemRender, onShowSizeChange } from "./Pagination";
import DocumentModal from "./DocumentModal";
import { formatFullDate } from "../utils";


const CustomerDocTab = ({user}) => {
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [customerDoc, setCustomerDoc] = useState([]);
 

  const columns = [

    {
      title: "Title",
      dataIndex: "documentName",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "Uploaded By",
      dataIndex: "createdDate",
      render: (text, record) => <p className="table-avatar">{formatFullDate(text)}</p>,
    },

    {
      title: "Action",
      title: () => <div className="text-center">Action</div>,
      render: (text, record) => (
        <div className="d-flex align-items-center justify-content-center">
          <button
            type="button"
            className="btn btn-sm btn-outline-primary me-3 col-lg-5 col-md-4 col-sm-12"
            data-bs-toggle="modal"
            data-bs-target="#documentModal"
            onClick={() => openDocumentModal(record.documentData)}
          >
            View
          </button>

          <button
            type="button"
            className="btn btn-sm btn-outline-danger me-3 col-lg-5 col-md-6 col-sm-12"
            data-bs-toggle="modal"
            data-bs-target="#deleteModal"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];


  const openDocumentModal = (documentRef) => {
    setSelectedDocument(documentRef);
  
  };
 
  useEffect(() => {
    setCustomerDoc(user.docUpload);
  }, []);

  return (
    <div>
      <div
        className="main-tab-content"
        style={{ height: "auto", overflowY: "auto", overflowX: "hidden" }}
      >
        <div className="row">
          <div className="table-responsive border-primary mb-5">
            <Table
              className="table-striped"
              pagination={{
                total: { customerDoc },
                showTotal: (total, range) =>
                  `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                showSizeChanger: true,
                onShowSizeChange: onShowSizeChange,
                itemRender: itemRender,
              }}
              style={{ overflowX: "auto" }}
              columns={columns}
              dataSource={customerDoc}
              rowKey={(record) => record.id}
            />
          </div>
          <DocumentModal document={selectedDocument} />
        </div>
      </div>
    </div>
  );
};

export default CustomerDocTab;
