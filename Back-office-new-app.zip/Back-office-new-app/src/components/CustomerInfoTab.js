import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { getDate } from "../utils";

const CustomerInfoTab = ({user}) => {
  console.log({user})

  const { data } = useSelector((state) => state.getSingleCurrent);
  const { loading, branch } = useSelector((state) => state.ui);

  const getBranchName = (brCode) => {
    if (!branch || branch.length === 0) {
      return;
    }

    const matchingBranch = branch.find((bran) => bran.value === brCode);
    return matchingBranch ? matchingBranch.text : null;
  };

  console.log({user})
  return (
    <div
    className="tab-pane active"
    id="timeline"
    role="tabpanel"
    aria-labelledby="timeline-tab"
    tabindex="0"
  >
    <div
      className="main-tab-content"
      style={{height:"auto", overflowY:"auto", overflowX:"hidden"}}
    >
      <div className="row">
        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Fullname</label>
            <h5>
              <strong>{user.fullName}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Email Address</label>
            <h5>
            <strong>{user.email !== null ? user.email : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Address</label>
            <h5>
              <strong>{user.address !== null ? user.address : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">BVN</label>
            <h5>
              <strong>{user.bvn !== null ? user.bvn : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Gender</label>
            <h5>
              <strong>{user.gender !== null ? user.gender : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Date of Birth</label>
            <h5>
              <strong>{user.dateOfBirth !== null ? user.dateOfBirth : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Phone Number</label>
            <h5>
              <strong>{user.phoneNumber !== null ? user.phoneNumber : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Marital Status</label>
            <h5>
              <strong>{user.maritalStatus !== null ? user.maritalStatus : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">
              Mother's Maiden Name
            </label>
            <h5>
              <strong>{user.motherMaidenName !== null ? user.motherMaidenName : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Place of Birth</label>
            <h5>
              <strong>{user.placeOfBirth !== null ? user.placeOfBirth : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">State of Origin</label>
            <h5>
              <strong>{user.stateOfOrigin !== null ? user.stateOfOrigin : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">State of Residence</label>
            <h5>
              <strong>{user.stateOfResidence !== null ? user.stateOfResidence : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">
              Local Government Area
            </label>
            <h5>
              <strong>{user.localGovernment !== null ? user.localGovernment : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Religion</label>
            <h5>
              <strong>{user.religion !== null ? user.religion : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Account Type</label>
            <h5>
              <strong>{user.accountType !== null ? user.accountType : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Account Number</label>
            <h5>
              <strong>{user.accountNumber !== null ? user.accountNumber : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Document ID Number</label>
            <h5>
              <strong>{user.idNumber !== null ? user.idNumber : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Expiry Date</label>
            <h5>
              <strong>{user.idCardExt !== null ? user.idCardExt : 'null'}</strong>
            </h5>
          </div>
        </div>

        <h4 className="mt-5 mb-3">Employment Details</h4>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Company Name</label>
            <h5>
              <strong>{user.businessName !== null ? user.businessName : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Address</label>
            <h5>
              <strong>{user.businessAddress !== null ? user.businessAddress : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Phone Number</label>
            <h5>
              <strong>{user.phoneNumber !== null ? user.phoneNumber : 'null'}</strong>
            </h5>
          </div>
        </div>

        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Company Email</label>
            <h5>
              <strong>{user.emailAddress !== null ? user.emailAddress : 'null'}</strong>
            </h5>
          </div>
        </div>
{/* 
        <div className="form-group col-4 mb-3">
          <div className="d-flex flex-column">
            <label className="text-secondary fs-6 mb-2">Job Title</label>
            <h5>
              <strong>{user.emailAddress !== null ? user.emailAddress : 'null'}</strong>
            </h5>
          </div>
        </div> */}
      </div>
    </div>
  </div>
  );
};

export default CustomerInfoTab;
