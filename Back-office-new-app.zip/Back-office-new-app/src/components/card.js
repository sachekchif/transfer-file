import React from 'react'
import { Link } from 'react-router-dom';

const Card = ({ title, totalAccts, url, acctPercent, icon, iconColor, color }) => {
  return (
    <div className="col-12 col-lg-4 col-md-6 col-sm-12">
      <Link to={url} style={{ textDecoration: 'none' }}>
        <div className="card mb-3 d-flex p-3 rounded-4" style={{ backgroundColor: `${color}` }}>
          <div className="fw-medium mb-4 fs-5">{title}</div>

          <div className={`card-icon icon-circle d-flex align-items-center justify-content-center ${iconColor}`}>
            <i className={`${icon} fa-2x text-white`}></i>
          </div>

          <h1 className="card-title fw-semibold">{totalAccts}</h1>

          <div className="d-flex">
            <h6 className="card-percent acct-success me-3 d-flex">
              <span className="arrow-green">+{acctPercent}</span>
            </h6>
            <span>More Accounts opened this month.</span>
          </div>
        </div>
      </Link>
    </div>
  );
};

export default Card