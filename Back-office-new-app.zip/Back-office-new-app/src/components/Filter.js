import React, {useEffect, useState} from "react";
import { searchSavings } from "../services/savingsAcct/savingsSlice";
import { useDispatch} from "react-redux";

const Filter = ({mySearch,onStatusChange}) => {
  const dispatch = useDispatch()
  const [searchData, setSearchData] = useState("")
  const [startDate, setStartDate] = useState(null)
  const [endDate, setEndate] = useState(null)
 

  const handleDateChange = (date, type) => {
    if (type === "start") {
      setStartDate(date);
    } else if (type === "end") {
      setEndate(date);
    }
  };

  useEffect(()=>{
    dispatch(mySearch(searchData))
  },[searchData])
  return (
    <div>
      <div className="mb-5">
        <div className="row mb-3">
          <div className="col-lg-12 col-md-12 col-sm-12 d-flex">
            <div className="col-lg-3 col-md-6 col-sm-12 me-4">
              <label className="align-self-center mb-2">From Date</label>
              <input value={startDate} onChange={(date) => handleDateChange(date, "start")} type="date" className="form-control" />
            </div>

            <div className="col-lg-3 col-md-6 col-sm-12 me-4">
              <label className="align-self-center mb-2">To Date</label>
              <input value={endDate} onChange={(date) => handleDateChange(date, "end")} type="date" className="form-control" />
            </div>

            <div className="col-lg-3 col-md-3 col-sm-12">
              <label className="mb-2">&nbsp;</label>
              <div className="dropdown">
                <button
                  className="btn btn-primary dropdown-toggle show"
                  type="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  Filter by Status
                </button>

                <ul className="dropdown-menu">
                  <li  style={{ cursor: 'pointer' }}>
                    <a className="dropdown-item"

                    onClick={()=>onStatusChange('APPROVED')}
                    >
                      <span>
                        <i className="bi bi-check2"></i>
                      </span>
                      Approved
                    </a>
                  </li>

                  <li  style={{ cursor: 'pointer' }}>
                    <a className="dropdown-item"
                    onClick={()=>onStatusChange('PENDING')}
                    >
                      <span>
                        <i className="bi bi-exclamation-lg"></i>
                      </span>
                      Pending
                    </a>
                  </li>

                  <li  style={{ cursor: 'pointer' }}>
                    <a className="dropdown-item"
                    onClick={()=>onStatusChange('REJECTED')}
                    >
                      <span>
                        <i className="bi bi-x"></i>
                      </span>
                      Rejected
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="row mb-3">
        <div className="form-group col-4">
          <div className="input-group">
            <input
              type="text"
              className="form-control search"
              placeholder="Search by name"
              aria-label="Username"
              aria-describedby="basic-addon1"
              id="search"
              value={searchData}
              onChange={(e)=>setSearchData(e.target.value)}
            />
            <span className="input-group-text">
              <i className="bi bi-search"></i>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Filter;
