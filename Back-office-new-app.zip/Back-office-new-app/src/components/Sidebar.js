import React,{useState, useEffect} from "react";
import logo from "../assets/images/logo-green.png";
import image from "../assets/images/bongis.jpg";
import { Link, useNavigate,useLocation } from "react-router-dom";
import { logout } from "../services/Authentication/loginSlice";
import { useDispatch } from "react-redux";

const sidebarLinks=[
    {
        id:1,
        text:"Dashboard",
        icon:"bi bi-grid-fill",
        navigateTo:"/"
       
    },
    {
        id:2,
        text:"Instant Savings",
        icon:"bi bi-piggy-bank-fill",
        navigateTo:"/instant-savings"
       
    },
    {
        id:3,
        text:"Savings Account",
        icon:"bi bi-bank2",
        navigateTo:"/savings-account"
       
    },
    {
        id:4,
        text:"Current Account",
        icon:"bi bi-person-bounding-box",
        navigateTo:"/current-account"
       
    },
    {
        id:5,
        text:"Corporate Account",
        icon:"bi bi-briefcase-fill",
        navigateTo:"/corporate-account"
        
    },
    // {
    //     id:6,
    //     text:" Kiddies Account",
    //     icon:"bi bi-person-fill",
    //     navigateTo:"/kiddies-account"
       
    // },
]

const Sidebar = () => {
  const location = useLocation()
   const dispatch = useDispatch()
  const navigate = useNavigate()
  const [userName, setUserName] = useState('')
   const userData = JSON.parse(localStorage.getItem('user')) 
    const [activeState, setActiveState] = useState(null)

 useEffect(()=>{
  setUserName(userData?.staffName)
 },[userName])


    const handleActiveState =(active)=>{
        setActiveState(active)
        // navigate(`${navigateRoute}`)

    }

    useEffect(()=>{
      setActiveState(location.pathname)
    },[location.pathname])

    const handleLogout =()=>{
      localStorage.clear();
      dispatch(logout())
      navigate('/login')
    }
    
    const initials = (fullName)=>{
      const stringedName = fullName.toString();
      const parts = stringedName.split(' ');
      if(parts.length >=2){
        const firstName = parts[0].charAt(0);
        const lastName =parts[1].charAt(0);
        return `${firstName} ${lastName}`
      }else if(parts.length === 1){
        return parts[0].charAt(0)
      }else{
        return ''
      }

    }
    console.log(initials(userName))
   
    
  return (
    <div className="left-sidebar d-flex flex-column flex-shrink-0 p-3 bg-body-tertiary">
      {/* <!-- Sidebar Logo --> */}
      <a className="d-flex align-items-center link-body-emphasis text-decoration-none">
        <img src={logo} width="250px" height="125px" />
      </a>

      <hr />

      {/* <!-- Sidebar Links --> */}
      <ul className="nav nav-pills flex-column mb-auto">
        {sidebarLinks.map((link)=>
        <li key={link.id} 
        // onClick={() => handleActiveState(link.id, link.navigateTo)}
        className="nav-item mb-3"
        >
        <Link
        onClick={() => handleActiveState(link.navigateTo)}
        to={link.navigateTo}
         className={`nav-link link-body-emphasis ${activeState === link.navigateTo ? 'active' : ''}`}
        >
          <i className={`${link.icon} mx-1`}></i>
          {link.text}
        </Link>
      </li>
        )}
        
      </ul>

      <hr />

      {/* <!-- Profile Dropdown --> */}
      <div className="dropdown">
        <a
          href="#"
          className="d-flex align-items-center link-body-emphasis text-decoration-none dropdown-toggle"
          data-bs-toggle="dropdown"
          aria-expanded="false"
        >
          {/* <img
            src={image}
            alt=""
            className="rounded-circle me-2"
            width="32"
            height="32"
          /> */}
          <i className="fa fa-user " aria-hidden="true"  
            ></i>

          <div>{userName}</div>
        </a>

        <ul className="dropdown-menu text-small shadow">
          <li>
            <hr className="dropdown-divider" />
          </li>

          <li>
            <button onClick={handleLogout} className="dropdown-item" >
              Logout
            </button>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
