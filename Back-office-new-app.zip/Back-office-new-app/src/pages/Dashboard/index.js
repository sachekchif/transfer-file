import React from 'react'
// import { Sidebar,Dashboard } from '../../components'
import { Cards, ChartDisplay } from '../../components'

const Dashboard = () => {
  return (
    <div>
      <div className="row mb-5">
        <div className="mt-5">
          <div className="page-title">
            <h1 className="h3 fw-bold">DASHBOARD</h1>
          </div>
        </div>
      </div>
      {/* <!-- Beginning of Accounts Section  --> */}
      <div className="row mb-1">
        <div className="page-title">
          <h5 className=" fw-bold">Accounts</h5>
        </div>
      </div>
      <div className="row mb-5 g-3">
        <Cards />
      </div>
      {/* <!-- Beginning of Overview Section  --> */}
      <div className="row mb-1">
        <div className="page-title d-flex">
          <h5 className=" fw-bold">Overview</h5>
        </div>
      </div>
      <div className="row mb-5">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <div class="card border-secondary-subtle mb-3">
            <div class="card-body">
              <div class="col-lg-12 col-md-12 col-sm-12 mb-5 d-flex">
                <div class="col-lg-10 col-md-4 col-sm-12">
                  <h5>All Accounts</h5>
                </div>

                <div class="dropdown col-lg-2 col-md-8 col-sm-12">
                  {/* <!-- <button type="button" class="btn btn-dark me-3">Export to Excel</button> --> */}
                  <button
                    class="btn btn-outline-primary dropdown-toggle"
                    type="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Select Year
                  </button>

                  <ul class="dropdown-menu">
                    <li>
                      <a class="dropdown-item" href="#">
                        2023
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        2022
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        2021
                      </a>
                    </li>
                  </ul>
                </div>
              </div>

              {/* <!-- Graph Comes Here--> */}
              <div className="col-lg-12 col-md-12 col-sm-12">
                <h5 className="float-start col-lg-12 col-md-12 col-sm-12">
                <ChartDisplay width="100%" height={400} />
                </h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard