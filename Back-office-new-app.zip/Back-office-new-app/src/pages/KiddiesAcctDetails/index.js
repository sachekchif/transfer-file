import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import {
  TabItem,
  ApprovalModal,
  RejectionModal,
  ChildInfoTab,
  ChildDocTab,
  GuardianDetails,
} from "../../components";
import { BulletList } from "react-content-loader";
import { useSelector, useDispatch } from "react-redux";
import { fetchSingleKiddies } from "../../services/kiddiesSavings/getSingleKiddiesSlice";
import {} from "../../utils";
import { fetchBankBranches } from "../../services/ui-slice";
import { calculateAge } from "../../utils";
import { approveKiddies } from "../../services/kiddiesSavings/approveSlice";
import Loader from "../../assets/images/loader.gif";
import { rejectKiddies } from "../../services/kiddiesSavings/rejectSlice";

const KiddiesAcctDetails = () => {
  const navigate = useNavigate();
  const [staffRoleDetails, setStaffRoleDetails] = useState([])
  const { id } = useParams();
  const [staffId, setStaffId]  = useState('')
  const user = JSON.parse(localStorage.getItem('user'))
  const dispatch = useDispatch();
  const { loading, error, data } = useSelector(
    (state) => state.getSingleKiddies
  );

  const load = useSelector((state) => state.approveKiddies.loading);
  console.log({load})

  const loadReject = useSelector((state)=> state.rejectKiddies.loading)

  console.log({ data });

  useEffect(() => {
    dispatch(fetchSingleKiddies({ staffId, id }));
  }, []);

  useEffect(()=>{
    setStaffId(user.staffId)
    setStaffRoleDetails(user.permissionDetails
     )
    },[])
  useEffect(() => {
    dispatch(fetchBankBranches());
  }, []);

  const handleApprove = () => {
    dispatch(approveKiddies({ id, staffId, navigate }));
  };

  const handleReject =()=>{
    dispatch(rejectKiddies({staffId,id,navigate}))
  }
  const [detail, setDetail] = useState("first");
  const tabs = [
    {
      id: "first",
      target: "#timeline",
      icon: "fas fa-list-ul me-3",
      text: "Child Information",
    },
    {
      id: "second",
      target: "#documents",
      icon: "bi bi-files-alt me-3",
      text: "Child Documents",
    },
    {
      id: "third",
      target: "#director",
      icon: "bi bi-people me-3",
      text: "Guardian Details",
    },
  ];

  return (
    <div>
      {loading ? (
        <MyBulletListLoader />
      ) : (
        <div>
          <div className="row mb-3 mt-5">
            <Link to="/kiddies-account">
              <div className="mb-3 d-flex">
                <div className="me-3">
                  <i className="fas fa-arrow-left text-secondary"></i>
                </div>
                <p className="text-secondary">
                  Back to <span>Kiddies Accounts</span>
                </p>
              </div>
            </Link>

            <div className="mb-3">
              <h4>
                <strong>{data.fullName}</strong>
              </h4>
              <div className="d-flex text-primary">
                <label className="me-1">{`${data.gender}, ${calculateAge(
                  data.dateOfBirth
                )}`}</label>
              </div>
            </div>
          </div>
          <div className="row mb-5">
            <div className="col-lg-12 col-md-12 col-sm-12">
              <div className="card border-secondary-subtle mb-3">
                <div className="card-body">
                  <ul className="nav nav-tabs" id="myTab" role="tablist">
                    {tabs.map((tab) => (
                      <TabItem
                        key={tab.id}
                        active={detail === tab.id}
                        onClick={() => setDetail(tab.id)}
                        {...tab}
                      />
                    ))}
                  </ul>
                  <div className="tab-content p-3">
                    {detail === "first" && <ChildInfoTab />}
                    {detail === "second" && <ChildDocTab />}
                    {detail === "third" && <GuardianDetails />}
                  </div>
                  <div className="d-flex align-items-center justify-content-center mb-5 mt-5">
                    <button
                      type="button"
                      class="btn btn-success me-5 col-lg-3 col-md-5 col-sm-12"
                      onClick={handleApprove}
                    >
                 
                      {load ? (
                        <img src={Loader} height={20} alt="loader" />
                      ) : (
                        " Approve"
                      )}
                    </button>

                    <button
                      type="button"
                      class="btn btn-danger col-lg-3 col-md-5 col-sm-12"
                      onClick={handleReject}
                    > 
                      {loadReject ? (
                        <img src={Loader} height={20} alt="loader" />
                      ) : (
                        " Reject"
                      )}
                    </button>
                  </div>
                  {/* <!-- Approval Modal --> */}
                  {/* <div
                className="modal fade"
                id="approveModal"
                tabindex="-1"
                aria-labelledby="approveModalLabel"
                aria-hidden="true"
              >
                <ApprovalModal />
              </div> */}
                  {/* <!-- Rejection Modal --> */}
                  {/* <div
                className="modal fade"
                id="rejectModal"
                tabindex="-1"
                aria-labelledby="rejectModalLabel"
                aria-hidden="true"
              >
                <RejectionModal />
              </div> */}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default KiddiesAcctDetails;
const MyBulletListLoader = () => <BulletList />;
