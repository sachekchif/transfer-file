import React,{useState, useEffect} from "react";
import { Table } from "antd";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Filter, DrawerComponent } from "../../components";
import { itemRender, onShowSizeChange } from "../../components/Pagination";
import { uiActions } from "../../services/ui-slice";
import { getDate, formatDob } from "../../utils";
import { fetchBankBranches } from "../../services/ui-slice";
import { fetchCorporateUsers } from "../../services/corporateSavings/corporateSlice";
import { searchCorporate } from "../../services/corporateSavings/corporateSlice";
import { BulletList } from "react-content-loader";




const CorporateAccount = () => {
 
  const [staffId, setStaffId] = useState('')
  const user = JSON.parse(localStorage.getItem('user'))
 
 
 useEffect(()=>{
  setStaffId(user.staffId)
 },[])
 console.log({user})
 

  const navigate = useNavigate()
  const dispatch = useDispatch();
  const [viewId, setViewId] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
 
  
  const { drawerIsVisible, gender, branch } = useSelector((state) => state.ui);
  const { data, loading, error, searchData } = useSelector(
    (state) => state.getAllCorporate
  );
console.log({data, loading, error, searchData})

const handleStatusChange =(status)=>{
  setSelectedStatus(status)
  
}

const dataByStatus =
  data.filter((singleData) => singleData.status === selectedStatus).length > 0
    ? data.filter((singleData) => singleData.status === selectedStatus)
    : data.filter((singleData) => singleData);


const filteredData = 
 searchData.length > 0
    ? data.filter((item) =>
        item.businessName.toLowerCase().startsWith(searchData.toLowerCase())
      )
    : dataByStatus;

    const getBranchName = (brCode) => {
      const matchingBranch = branch?.find((bran) => bran.value == brCode);
      return matchingBranch ? matchingBranch.text : 'null';
    };
  

    const matchingUser = data.find((user) => user.id === viewId);

    const showDrawer = (id) => {
      setViewId(id);
      dispatch(uiActions.toggle(id));
    };

  const handleViewDetails=()=>{
    navigate(`/corporate-details/${viewId}`)
    showDrawer()
  }

  useEffect(() => {
    dispatch(fetchCorporateUsers(staffId));
    dispatch(fetchBankBranches());
  }, [dispatch, staffId]);

  
  const columns = [
    {
      title: "Business Name",
      dataIndex: "businessName",
      render: (text, record, index) => (
        <div className="flex-column">
          <div className="mb-1">{text}</div>
          {/* <div className="text-body-secondary">Male</div> */}
        </div>
      ),
    },

    {
      title: "Tin No",
      dataIndex: "tin",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "Date of Registration",
      dataIndex: "dateIssue",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "Purpose of Account",
      dataIndex: "purposeofAccount",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "Date Created",
      dataIndex: "createdDate",
      render: (text, record) => <p className="table-avatar">{getDate(text)}</p>,
    },
    {
      title: "Preferred Branch",
      dataIndex: "branchcode",
      render: (text, record) => <p className="table-avatar">{getBranchName(text)}</p>,
    },
    {
      title: "Status",
      dataIndex: "status",
      render: (text, record) => (
        <label
          className={
            text === "PENDING"
              ? "card-text acct-warning"
              : text === "REJECTED"
              ? "card-text acct-failed"
              : text === "SUCCESSFUL" || "APPROVED"
              ? "card-text acct-success"
              : text === "DECLINED"
              ? "declined_class"
              : ""
          }
        >
          {text}
        </label>
      ),
    },

    {
      title: "Action",
      render: (text, record) => (
        <div className="btn-group dropup  ">
          <button
             onClick={() => showDrawer(record.id)}
            className="btn text-white btn-primary btn-sm"
          >
            <span className="mx-3">View</span>
          </button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="row mb-5">
        <div className="mt-5">
          <div className="page-title">
            <h1 className="h3 fw-bold">CORPORATE ACCOUNTS</h1>
          </div>
        </div>
      </div>
      <Filter mySearch={searchCorporate} onStatusChange={handleStatusChange} />
      <div className="row mb-5">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <div className="card border-secondary-subtle mb-3">
            <div className="card-body">
              <div className="table-responsive border-primary mb-5">
              {loading ? (
                  <MyBulletListLoader />
                ) : (
                <Table
                  className="table-striped"
                  pagination={{
                    total: { filteredData },
                    showTotal: (total, range) =>
                      `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                    showSizeChanger: true,
                    onShowSizeChange: onShowSizeChange,
                    itemRender: itemRender,
                  }}
                  style={{ overflowX: "auto" }}
                  columns={columns}
                  // bordered
                  dataSource={filteredData}
                  rowKey={(record) => record.id}
                  // onChange={console.log("change")}
                />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      {drawerIsVisible && (
        <DrawerComponent title="Account Details">
          <div>
            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Business Name
              </label>
              <h6>{matchingUser.businessName}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Business Email Address
              </label>
              <h6>{matchingUser.emailAddress}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Tin No</label>
              <h6>{matchingUser.tin}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Phone Number
              </label>
              <h6>{matchingUser.phoneNumber}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">RC Number</label>
              <h6>{matchingUser.rcNumber}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Account Currency
              </label>
              <h6>{matchingUser.accountCurrency}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Prefered Branch
              </label>
              <h6>{getBranchName(matchingUser.preferedBranch)}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Date Created
              </label>
              <h6>{getDate(matchingUser.dateofRegistration)}</h6>
            </div>

            <div className="channel-title mb-5">
              <label className="text-dark-emphasis fw-medium">Status        </label>
              <h6>
                <span className="badge acct-warning fs-6 text-danger">
                  {matchingUser.status}
                </span>
              </h6>
            </div>

            <div className="d-flex align-items-center justify-content-center mb-5 col-12">
              <button
                className="btn text-white btn-primary"
                onClick={handleViewDetails}
              >
                <span className="mx-3">View Full Profile </span>
              </button>
            </div>
          </div>
        </DrawerComponent>
      )}
    </div>
  );
};

export default CorporateAccount;
const MyBulletListLoader = () => <BulletList />;