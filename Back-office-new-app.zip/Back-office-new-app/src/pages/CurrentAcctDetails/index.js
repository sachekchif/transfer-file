import React, { useState, useEffect } from "react";
import {
  CustomerInfoTab,
  CustomerDocTab,
  ApprovalModal,
  RejectionModal,
  TabItem,
} from "../../components";
import { Link, useParams, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { fetchSingleCurrent } from "../../services/currentSavings/getSingleCurrentById";
import { fetchBankBranches } from "../../services/ui-slice";
import { BulletList } from "react-content-loader";
import { approveCurrent } from "../../services/currentSavings/approveCurrentSlice";
import { preApproveCurrent } from "../../services/currentSavings/preApproveSlice";
import { rejectCurrent } from "../../services/currentSavings/rejectCurrentSlice";
import loader from "../../assets/images/loader.gif"

const CurrentAcctDetails = () => {
 
 
  const [staffId, setStaffId]  = useState('')
 const [staffRoleDetails, setStaffRoleDetails] = useState([])
 const user = JSON.parse(localStorage.getItem('user'))
  const navigate = useNavigate();
  const { id } = useParams();
  const dispatch = useDispatch();
  const { loading, error, data } = useSelector(
    (state) => state.getSingleCurrent
  );
  useEffect(()=>{
    setStaffId(user.staffId)
    setStaffRoleDetails(user.permissionDetails
     )
    },[])

    const staffRoleName= staffRoleDetails[5]
  const staffRole =staffRoleName?.roleName

  useEffect(() => {
    dispatch(fetchSingleCurrent({ staffId, id }));
  }, []);

  useEffect(() => {
    dispatch(fetchBankBranches());
  }, []);

  const handlePreApprove = () => {
    dispatch(preApproveCurrent( {id, staffId,navigate}));
  };

  const handleApprove = () => {
    dispatch(approveCurrent({ id, staffId, navigate }));
  };

  const handleReject = () => {
    dispatch(rejectCurrent({ staffId, id, navigate }));
  };

  const [detail, setDetail] = useState("first");
  const tabs = [
    {
      id: "first",
      target: "#timeline",
      icon: "fas fa-list-ul me-3",
      text: "Customer Information",
    },
    {
      id: "second",
      target: "#documents",
      icon: "bi bi-files-alt me-3",
      text: "Customer Documents",
    },
  ];
  return (
    <div>
      {loading ? (
        <MyBulletListLoader />
      ) : (
        <div>
          <div className="row mb-3 mt-5">
            <Link to="/current-account">
              <div className="mb-3 d-flex">
                <div className="me-3">
                  <i className="fas fa-arrow-left text-secondary"></i>
                </div>
                <p className="text-secondary">
                  Back to <span>Current Accounts</span>
                </p>
              </div>
            </Link>

            <div className="mb-3">
              <h4>
                <strong>{data.fullName}</strong>
              </h4>
              <div className="d-flex text-primary">
                <label className="me-2">BVN :</label>
                <label>{data.bvn}</label>
              </div>
            </div>
          </div>

          <div className="row mb-5">
            <div className="col-lg-12 col-md-12 col-sm-12">
              <div className="card border-secondary-subtle mb-3">
                <div className="card-body">
                  <ul className="nav nav-tabs" id="myTab" role="tablist">
                    {tabs.map((tab) => (
                      <TabItem
                        key={tab.id}
                        active={detail === tab.id}
                        onClick={() => setDetail(tab.id)}
                        {...tab}
                      />
                    ))}
                  </ul>
                  <div className="tab-content p-3">
                    {detail === "first" && <CustomerInfoTab user={data}/>}
                    {detail === "second" && <CustomerDocTab user={data} />}
                  </div>
                  <div className="d-flex align-items-center justify-content-center mb-5 mt-5">
                    
                    {(staffRole === 'INITIATOR' && (data.status !== 'SUCCESSFUL' && data.status !== 'APPROVED')  )  &&(
                      <button
                      type="button"
                      class="btn btn-success me-5 col-lg-3 col-md-5 col-sm-12"
                      onClick={handlePreApprove}
                    >
                     {loading ? <img src={loader} height={20} width={20}/> : "Pre Approve"}
                    </button>
                    )}
                    {(staffRole === 'SUPER ADMIN' && (data.status !== 'SUCCESSFUL' && data.status !== 'APPROVED')  )  &&(
                      <button
                      type="button"
                      class="btn btn-success me-5 col-lg-3 col-md-5 col-sm-12"
                      onClick={handleApprove}
                    >
                     {loading ? <img src={loader} height={20} width={20}/> : "Approve"}
                    </button>
                    )}
                     
                    {(data.status  !== 'APPROVED' && data.status !== 'SUCCESSFUL') && (
                      <button
                      type="button"
                      class="btn btn-danger col-lg-3 col-md-5 col-sm-12"
                      onClick={handleReject}
                    >
                      Reject
                    </button>
                    )}
                    
                  </div>
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CurrentAcctDetails;
const MyBulletListLoader = () => <BulletList />;
