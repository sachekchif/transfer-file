import React,{useState, useEffect} from "react";
import { Table } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { Filter, DrawerComponent } from "../../components";
import { itemRender, onShowSizeChange } from "../../components/Pagination";
import { uiActions } from "../../services/ui-slice";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { BulletList } from "react-content-loader";
import { fetchKiddiesUsers } from "../../services/kiddiesSavings/kiddiesSlice";
import { searchKiddies } from "../../services/kiddiesSavings/kiddiesSlice";
import { getDate, formatDob, calculatePercentageIncrease } from "../../utils";
import { fetchBankBranches } from "../../services/ui-slice";



const KiddiesAccount = () => {
  const [staffId, setStaffId] = useState('')
  const user = JSON.parse(localStorage.getItem('user'))
  const [viewId, setViewId] = useState("");
  const navigate = useNavigate()
  const dispatch = useDispatch();
  const { drawerIsVisible, gender, branch } = useSelector((state) => state.ui);
  const { data, loading, error, searchData } = useSelector(
    (state) => state.kiddies
  );

  const filteredData =
  typeof searchData === "string"
    ? data.filter((item) =>
        item.fullName.toLowerCase().includes(searchData.toLowerCase())
      )
    : data;

    const getBranchName = (brCode) => {
      const matchingBranch = branch?.find((bran) => bran.value == brCode);
      return matchingBranch ? matchingBranch.text : 'null';
    };
    const matchingUser = data.find((user) => user.id === viewId);
    const showDrawer = (id) => {
      setViewId(id);
      dispatch(uiActions.toggle(id));
    };

    const handleViewDetails=()=>{
      navigate(`/kiddies-details/${viewId}`)
      showDrawer()
    }

    
  useEffect(()=>{
    setStaffId(user.staffId)
   },[])
   
    useEffect(() => {
      dispatch(fetchKiddiesUsers(staffId));
      dispatch(fetchBankBranches());
    }, [dispatch, staffId]);

  const columns = [
    {
      title: "Fullname",
      dataIndex: "fullName",
      render: (text, record, index) => (
        <div className="flex-column">
          <div className="mb-1">{record.fullName}</div>
          <div className="text-body-secondary">{record.gender}</div>
        </div>
      ),
    },

    {
      title: "BVN",
      dataIndex: "bvn",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "Account Number",
      dataIndex: "accountNumber",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "DOB",
      dataIndex: "dateOfBirth",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "Branch",
      dataIndex: "branchcode",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "Date Created",
      dataIndex: "dateCreated",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "Status",
      dataIndex: "status",
      render: (text, record) => (
        <label
          className={
            text === "PENDING"
              ? "card-text acct-warning"
              : text === "REJECTED"
              ? "card-text acct-failed"
              : text === "SUCCESSFUL" || "APPROVED"
              ? "card-text acct-success"
              : text === "DECLINED"
              ? "declined_class"
              : ""
          }
        >
          {text}
        </label>
      ),
    },
    {
      title: "Action",
      render: (text, record) => (
        <div className="btn-group dropup  ">
          <button
             onClick={() => showDrawer(record.id)}
            className="btn text-white btn-primary btn-sm"
          >
            <span className="mx-3">View</span>
          </button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="row mb-5">
        <div className="mt-5">
          <div className="page-title">
            <h1 className="h3 fw-bold">KIDDIES ACCOUNT</h1>
          </div>
        </div>
      </div>
      <Filter mySearch={searchKiddies} />
      <div className="row mb-5">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <div className="card border-secondary-subtle mb-3">
            <div className="card-body">
              <div className="table-responsive border-primary mb-5">
              {loading ? (
                  <MyBulletListLoader />
                ) : (
                <Table
                  className="table-striped"
                  pagination={{
                    total: { filteredData },
                    showTotal: (total, range) =>
                      `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                    showSizeChanger: true,
                    onShowSizeChange: onShowSizeChange,
                    itemRender: itemRender,
                  }}
                  style={{ overflowX: "auto" }}
                  columns={columns}
                  // bordered
                  dataSource={filteredData}
                  rowKey={(record) => record.id}
                  // onChange={console.log("change")}
                />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      {drawerIsVisible && (
        <DrawerComponent title="Account Details">
          <div>
            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Fullname</label>
              <h6>{matchingUser.fullName}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Gender</label>
              <h6>{matchingUser.gender}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">BVN</label>
              <h6>{matchingUser.bvn}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Account Number
              </label>
              <h6>{matchingUser.accountNumber}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Date of Birth
              </label>
              <h6>{formatDob(matchingUser.dateOfBirth)}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Branch</label>
              <h6>{getBranchName(matchingUser.branchcode)}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Address</label>
              <h6>{matchingUser.address}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Phone Number
              </label>
              <h6>{matchingUser.phoneNumber}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Date Created
              </label>
              <h6>{getDate(matchingUser.createdDate)}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Status</label>
              <h6>
              <span className={`badge ${matchingUser.status=== 'SUCCESSFUL'? "acct-success" : "acct-warning"} fs-6 `}>
                  {matchingUser.status}
                </span>
              </h6>
            </div>
            <div className="d-flex align-items-center justify-content-center mb-5 col-12">
            <button
                className="btn text-white btn-primary"
                onClick={handleViewDetails}
              >
                <span className="mx-3">View Full Profile </span>
              </button>
            </div>
          </div>
        </DrawerComponent>
      )}
    </div>
  );
};

export default KiddiesAccount;
const MyBulletListLoader = () => <BulletList />;
