
import CorporateAccount from "./CorporateAccount";
import InstantSavings from "./InstantSavings/indes";
import KiddiesAccount from "./KiddiesAccount";
import SavingsAccount from "./SavingsAccount";
import CurrentAccount from "./CurrentAccount";
import Dashboard from "./Dashboard";
import SavingsAcctDetails from "./SavingsAcctDetails";
import CurrentAcctDetails from "./CurrentAcctDetails";
import CorporateAccountDetails from "./CorporateAcctDetails";
import DirectorDetails from "./DirectorDetails";
import KiddiesAcctDetails from "./KiddiesAcctDetails/index.js";
import KiddiesGuardianDetails from "./kiddiesGuardianDetails.js";
// import CurrentSavings from "./CurrentAccount";
import LoginPage from "./Login";

export {
  Dashboard,
  CorporateAccount,
  InstantSavings,
  KiddiesAccount,
  SavingsAccount,
  CurrentAccount,
  SavingsAcctDetails,
  CurrentAcctDetails,
  CorporateAccountDetails,
  DirectorDetails,
  KiddiesAcctDetails,
  KiddiesGuardianDetails,
  LoginPage
};
