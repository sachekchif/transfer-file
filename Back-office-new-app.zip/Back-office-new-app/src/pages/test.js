import React, { useEffect } from 'react';
import { fetchUsers } from '../services/instantSavings/instantSlice';
import { useSelector, useDispatch } from 'react-redux'





const Test = () => {
  const {data, loading, error} = useSelector(state => state.instant)
  const dispatch = useDispatch()
  console.log({data, loading,error})
  const staffId = '403'
  useEffect(() => {
    dispatch(fetchUsers(staffId))
  }, [])


  // }
  return (
   
    <div>
dashboard
  </div>
  );
};

export default Test;


//  the challenge i am experiencing now is that when i refresh my page,the active state is set to null.but what i want is that when i refresh, the active state should be the same active state.how do i set this in this code
