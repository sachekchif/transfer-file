import React, {useEffect, useState} from "react";
import sun from '../../assets/images/sun.png';
import logo from '../../assets/images/new_logo.png';
import useInput from "../../common/inputValidation";
import { LoginUser } from "../../services/Authentication/loginSlice";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { Loader } from "../../components";
import loader1 from '../../assets/images/loader.gif'



const isNotEmpty = (value) => value.trim() !== "";
const isEmailValid = (value) => {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
};


const LoginPage = () => {

const {loading,isAuthenticated } = useSelector((state)=> state.login)
  const dispatch = useDispatch()
  const navigate = useNavigate();

 const {
  value: email,
  isValid: emailIsValid,
  hasError: emailHasError,
  valueChangeHandler: emailChangeHandler,
  inputBlurHandler: emailBlurHandler,
  reset: resetEmail,
} = useInput(isNotEmpty);

const {
  value: password,
  isValid: passwordIsValid,
  hasError: passwordHasError,
  valueChangeHandler:passwordChangeHandler,
  inputBlurHandler: passwordBlurHandler,
  reset: resetPassword,
} = useInput(isNotEmpty);

let formIsValid = false;
// if(emailIsValid && passwordIsValid){
// }
formIsValid= emailIsValid && passwordIsValid;

const loginData={
  email,
  password,
  navigate,
  dispatch
}


 const getInputClasses=(hasError)=>{
  return hasError ? 'form-control invalid' : 'form-control'
 }
 const emailClasses = getInputClasses(emailHasError)
 const passwordClasses =getInputClasses(passwordHasError)
 
 const handleLogin=(e)=>{
  e.preventDefault();
  dispatch(LoginUser(loginData))
  resetEmail();
  resetPassword()
 }


 



  return (
    <>
   
      {
        !isAuthenticated &&
        <div>
      <div className="d-flex align-items-center justify-contents-center">
        <div className="left-side-login col-lg-6 col-md-12 col-sm-12 p-5">
          <div className="logo mb-3">
            <img src={sun} alt="" className="form-logo" />
          </div>
  
          <div className="text-primary-emphasis col-12 mb-5">
            <h5 className="display-6 mb-3">
              <strong>Welcome, Please Login</strong>
            </h5>
            <h6>Enter the correct login details in the fields below</h6>
          </div>
  
          <div className="col-lg-12 col-md-12 col-sm-12">
            <form>
              <div className="form-group mb-3 col-lg-10 col-md-12 col-sm-12 mb-5">
                <label className="form-label">Email</label>
                <div className="input-group mb-3">
                  <span className="input-group-text">
                    <i className="bi bi-envelope-fill"></i>
                  </span>
                  <input
                    type="text"
                    className={emailClasses}
                    placeholder="Enter your email"
                    value={email}
                    onChange={emailChangeHandler}
                    onBlur={emailBlurHandler}
                  />
                 
                </div>
                {emailHasError && (
                  <p className="error-text mb-5">provide a valid email.</p>
                )}
              </div>
  
              <div className="form-group mb-3 col-lg-10 col-md-12 col-sm-12 mb-5">
                <label className="form-label">Password</label>
                <div className="input-group mb-3">
                  <span className="input-group-text" id="basic-addon1">
                    <i className="bi bi-lock-fill"></i>
                  </span>
                  <input
                    type="password"
                    className={passwordClasses}
                    placeholder="Enter your password"
                    value={password}
                    onChange={passwordChangeHandler}
                    onBlur={passwordBlurHandler}
                  />
                
                </div>
                {passwordHasError && (
                  <p className="error-text mb-5">field cannot be empty.</p>
                )}
              </div>
  
           
              <div className="d-grid col-lg-6 col-md-6 col-sm-12 mx-auto mt-5">
                <button
                  className="btn btn-lg stb-color"
                  onClick={handleLogin}
                  disabled={!formIsValid}
                >  
                  {loading ?  <img src={loader1} height={20} width={20}/> : 'Login'} 
                </button>
              </div>
            </form>
          </div>
        </div>
  
        <div className="right-side-login col-lg-6 col-md-12 col-sm-12 p-5">
          <div className="logo mb-3">
            <img
              src={logo}
              alt=""
              className="form-logo"
            />
          </div>
        </div>
      </div>
      </div>
 
      }
    
    </>
  );
};

export default LoginPage;
