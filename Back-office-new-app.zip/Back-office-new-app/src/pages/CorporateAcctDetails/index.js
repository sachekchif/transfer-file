import React, { useState, useEffect } from "react";
import loader from '../../assets/images/loader.gif'
import {
  ApprovalModal,
  RejectionModal,
  TabItem,
  CorporateCusInfoTab,
  CorporateCusDocTab,
  CorporateDirTab,
 
} from "../../components";


import { Link, useParams,useNavigate } from "react-router-dom";
import { fetchSingleCorporate } from "../../services/corporateSavings/getCorporateByIdSlice";
import { fetchBankBranches } from "../../services/ui-slice";
import { useDispatch, useSelector } from "react-redux";
import { approveCorporate } from "../../services/corporateSavings/approveCorporateSlice";
import { preApproveCorporate } from "../../services/corporateSavings/pre-approveSlice";
import { rejectCorporate } from "../../services/corporateSavings/rejectCorporateSlice";
import { fetchSingleDir } from "../../services/corporateSavings/getDirDetailsSlice";

import { BulletList } from "react-content-loader";

const CorporateAccountDetails = () => {
 const [staffId, setStaffId]  = useState('')
 const [staffRoleDetails, setStaffRoleDetails] = useState([])
 const user = JSON.parse(localStorage.getItem('user'))

  
  const { id } = useParams();
  const dispatch = useDispatch();
  const [detail, setDetail] = useState("first");
  const { loading, error, data } = useSelector(
    (state) => state.singleCorporate
  );
  const navigate = useNavigate();
  useEffect(()=>{
   setStaffId(user.staffId)
   setStaffRoleDetails(user.permissionDetails
    )
   },[])


 

  useEffect(() => {
    dispatch(fetchSingleCorporate({ staffId, id }));
    dispatch(fetchSingleDir({ staffId, id }))
  }, []);

  useEffect(() => {
    dispatch(fetchBankBranches());
  }, []);

  const staffRoleName= staffRoleDetails[4]
  const staffRole =staffRoleName?.roleName

 
const handlePreApprove = () => {
  dispatch(preApproveCorporate( {id, staffId,navigate}));
};

  const handleApprove = () => {
    dispatch(approveCorporate( {id, staffId,navigate}));
  };
  
  const handleReject =()=>{
    dispatch(rejectCorporate({staffId,id,navigate}))
  }
  const tabs = [
    {
      id: "first",
      target: "#timeline",
      icon: "fas fa-list-ul me-3",
      text: "Customer Information",
    },
    {
      id: "second",
      target: "#documents",
      icon: "bi bi-files-alt me-3",
      text: "Customer Documents",
    },
    {
      id: "third",
      target: "#director",
      icon: "bi bi-people me-3",
      text: "Directors Details",
    },
  ];
  return (
    <div>
      <div className="row mb-3 mt-5">
        <a href="savings.html">
          <div className="mb-3 d-flex">
            <div className="me-3">
              <i className="fas fa-arrow-left text-secondary"></i>
            </div>
            <Link to="/corporate-account" className="text-secondary">
              Back to <span>Corporate Accounts</span>
            </Link>
          </div>
        </a>

        <div className="mb-3">
          <h4>
            <strong>{data.fullName}</strong>
          </h4>
          <div className="d-flex text-primary">
            <label className="me-2">BVN :</label>
            <label>{data.bvn}</label>
          </div>
        </div>
      </div>

      <div className="row mb-5">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <div className="card border-secondary-subtle mb-3">
            {loading ? <MyBulletListLoader /> : (
                <div className="card-body">
                <ul className="nav nav-tabs" id="myTab" role="tablist">
                  {tabs.map((tab) => (
                    <TabItem
                      key={tab.id}
                      active={detail === tab.id}
                      onClick={() => setDetail(tab.id)}
                      {...tab}
                    />
                  ))}
                </ul>
               
                <div className="tab-content p-3">
                  {detail === "first" && <CorporateCusInfoTab />}
                  {detail === "second" && <CorporateCusDocTab />}
                  {detail === "third" && <CorporateDirTab />}
                </div>
                <div className="d-flex align-items-center justify-content-center mb-5 mt-5">
                    
                    {(staffRole === 'INITIATOR' && (data.status !== 'SUCCESSFUL' && data.status !== 'APPROVED')  )  &&(
                      <button
                      type="button"
                      class="btn btn-success me-5 col-lg-3 col-md-5 col-sm-12"
                      onClick={handlePreApprove}
                    >
                     {loading ? <img src={loader} height={20} width={20}/> : "Pre Approve"}
                    </button>
                    )}
                    {(staffRole === 'SUPER ADMIN' && (data.status !== 'SUCCESSFUL' && data.status !== 'APPROVED')  )  &&(
                      <button
                      type="button"
                      class="btn btn-success me-5 col-lg-3 col-md-5 col-sm-12"
                      onClick={handleApprove}
                    >
                     {loading ? <img src={loader} height={20} width={20}/> : "Approve"}
                    </button>
                    )}
                     
                    {(data.status  !== 'APPROVED' && data.status !== 'SUCCESSFUL') && (
                      <button
                      type="button"
                      class="btn btn-danger col-lg-3 col-md-5 col-sm-12"
                      onClick={handleReject}
                    >
                      Reject
                    </button>
                    )}
                    
                  </div>
            
              </div>
            ) }
          
          </div>
        </div>
      </div>
    </div>
  );
};

export default CorporateAccountDetails;
const MyBulletListLoader = () => <BulletList />;
