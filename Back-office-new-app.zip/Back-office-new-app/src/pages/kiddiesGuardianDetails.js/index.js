import React, {useState} from 'react'
import { Link } from 'react-router-dom'
import { GuardianInfoTab,GuardianDocTab,TabItem,ApprovalModal,RejectionModal } from '../../components';


const KiddiesGuardianDetails = () => {
    const [detail, setDetail] = useState("first");
     const tabs = [
      {
        id: "first",
        target: "#timeline",
        icon: "fas fa-list-ul me-3",
        text: "Guardian Information",
      },
      {
        id: "second",
        target: "#documents",
        icon: "bi bi-files-alt me-3",
        text: "Guardian Documents",
      },
     
    ];
  return (
    <div>
         <div className="row mb-3 mt-5">
                <Link to="/kiddies-details/:id">
                    <div className="mb-3 d-flex">
                        <div className="me-3">
                            <i className="fas fa-arrow-left text-secondary"></i>
                        </div>
                        <p className="text-secondary">Back to <span>Child's Profile</span></p>
                    </div>
                </Link>

                <div className="mb-3">
                    <h4><strong>James Majekodunmi</strong></h4>
                    <div className="d-flex text-primary">
                        <label className="me-1">Father</label>
                    </div>
                </div>
            </div>
            <div className="row mb-5">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <div className="card border-secondary-subtle mb-3">
            <div className="card-body">
              <ul className="nav nav-tabs" id="myTab" role="tablist">
                {tabs.map((tab) => (
                  <TabItem
                    key={tab.id}
                    active={detail === tab.id}
                    onClick={() => setDetail(tab.id)}
                    {...tab}
                  />
                ))}
              </ul>
              <div className="tab-content p-3">
                {detail === "first" && <GuardianInfoTab />}
                {detail === "second" && <GuardianDocTab />}
              </div>
              <div className="d-flex align-items-center justify-content-center mb-5 mt-5">
                <button
                  type="button"
                  class="btn btn-success me-5 col-lg-3 col-md-5 col-sm-12"
                  data-bs-toggle="modal"
                  data-bs-target="#approveModal"
                >
                  Approve
                </button>

                <button
                  type="button"
                  class="btn btn-danger col-lg-3 col-md-5 col-sm-12"
                  data-bs-toggle="modal"
                  data-bs-target="#rejectModal"
                >
                  Reject
                </button>
              </div>
              {/* <!-- Approval Modal --> */}
              <div
                className="modal fade"
                id="approveModal"
                tabindex="-1"
                aria-labelledby="approveModalLabel"
                aria-hidden="true"
              >
                <ApprovalModal />
              </div>
              {/* <!-- Rejection Modal --> */}
              <div
                className="modal fade"
                id="rejectModal"
                tabindex="-1"
                aria-labelledby="rejectModalLabel"
                aria-hidden="true"
              >
                <RejectionModal />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default KiddiesGuardianDetails