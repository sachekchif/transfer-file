import React, { useState, useEffect } from "react";
import { Table } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { Filter, DrawerComponent } from "../../components";
import { itemRender, onShowSizeChange } from "../../components/Pagination";
import { uiActions } from "../../services/ui-slice";
import { fetchUsers } from "../../services/instantSavings/instantSlice";
import { getDate, formatDob } from "../../utils";
import { BulletList } from "react-content-loader";
import { searchUser } from "../../services/instantSavings/instantSlice";
import { fetchBankBranches } from "../../services/ui-slice";


const InstantSavings = () => {
  const [viewId, setViewId]= useState('')
  const [selectedStatus, setSelectedStatus] = useState("");
  const [staffId, setStaffId] = useState('')
  const user = JSON.parse(localStorage.getItem('user'))


  const dispatch = useDispatch();

  const { drawerIsVisible, gender, branch } = useSelector((state) => state.ui);
  const { data, error, loading,searchData} = useSelector((state) => state.instant);


  const handleStatusChange =(status)=>{
    setSelectedStatus(status)
    
  }

  const getBranchName = (brCode) => {
    const matchingBranch = branch?.find((bran) => bran.value == brCode);
    return matchingBranch ? matchingBranch.text : 'null';
  };
  

  const matchingUser = data.find((user)=> user.id === viewId)
  
 
  const dataByStatus =
  data.filter((singleData) => singleData.status === selectedStatus).length > 0
    ? data.filter((singleData) => singleData.status === selectedStatus)
    : data.filter((singleData) => singleData);


const filteredData = 
 searchData.length > 0
    ? data.filter((item) =>
        item.fullName.toLowerCase().startsWith(searchData.toLowerCase())
      )
    : dataByStatus;

  const showDrawer = (id) => {
    setViewId(id)
    dispatch(uiActions.toggle(id));
  };

  useEffect(()=>{
    setStaffId(user.staffId)
   },[])

  useEffect(() => {
    dispatch(fetchUsers(staffId));
    dispatch(fetchBankBranches())
  }, [dispatch, staffId]);

  const columns = [
    {
      title: "Fullname",
      dataIndex: "fullName",
      render: (text, record, index) => (
        <div className="flex-column">
          <div className="mb-1">{record.fullName}</div>
          <div className="text-body-secondary">
            {record.gender === "1"
              ? "Male"
              : record.gender === "2"
              ? "Female"
              : null}
          </div>
        </div>
      ),
    },

    {
      title: "BVN",
      dataIndex: "bvn",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "Phomne Number",
      dataIndex: "phoneNumber",
      render: (text, record) => <p className="table-avatar">{text}</p>,
    },
    {
      title: "DOB",
      dataIndex: "dateOfBirth",
      render: (text, record) => (
        <p className="table-avatar">{formatDob(text)}</p>
      ),
    },
    {
      title: "Branch",
      dataIndex: "branchcode",
      render: (text, record) => (
        <p className="table-avatar">{getBranchName(text)}</p>
      ),
    },
    {
      title: "Date Created",
      dataIndex: "createdDate",
      render: (text, record) => <p className="table-avatar">{getDate(text)}</p>,
    },

    {
      title: "Action",
      render: (text, record) => (
        <div className="btn-group dropup  ">
          <button
            onClick={() => showDrawer(record.id)}
            className="btn text-white btn-primary btn-sm"
          >
            <span className="mx-3">View</span>
          </button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="row mb-5">
        <div className="mt-5">
          <div className="page-title">
            <h1 className="h3 fw-bold">INSTANT SAVINGS</h1>
          </div>
        </div>
      </div>
      <Filter mySearch={searchUser} onStatusChange={handleStatusChange}/>
      <div className="row mb-5">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <div className="card border-secondary-subtle mb-3">
            <div className="card-body">
              <div className="table-responsive border-primary mb-5">
                {loading ? (
                  <MyBulletListLoader />
                ) : (
                  <Table
                  className="table-striped"
                  pagination={{
                    total: filteredData,
                    showTotal: (total, range) =>
                      `Showing ${range[0]} to ${range[1]} of ${total} entries`,
                    showSizeChanger: true,
                    onShowSizeChange: onShowSizeChange,
                    itemRender: itemRender,
                  }}
                  style={{ overflowX: "auto" }}
                  columns={columns}
                  dataSource={filteredData}
                  rowKey={(record) => record.id}
                />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      {drawerIsVisible && (
        <DrawerComponent title="Account Details">
          <div>
            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Fullname</label>
              <h6>{matchingUser.fullName}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Gender</label>
              <h6>{matchingUser.gender === '1' ? 'Male':matchingUser.gender ==='2'? 'Female': null}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">BVN</label>
              <h6>{matchingUser.bvn}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Account Number
              </label>
              <h6>{matchingUser.accountNumber}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Date of Birth
              </label>
              <h6>{formatDob(matchingUser.dateOfBirth)}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Branch</label>
              <h6>{getBranchName(matchingUser.branchcode)}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Address</label>
              <h6>{matchingUser.cutomerAddress}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Phone Number
              </label>
              <h6>{matchingUser.phoneNumber}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">
                Date Created
              </label>
              <h6>{getDate(matchingUser.createdDate)}</h6>
            </div>

            <div className="channel-title mb-3">
              <label className="text-dark-emphasis fw-medium">Status</label>
              <h6>
                <span className={`badge ${matchingUser.status=== 'SUCCESSFUL'? "acct-success" : "acct-warning"} fs-6 `}>
                  {matchingUser.status}
                </span>
              </h6>
            </div>
          </div>
        </DrawerComponent>
      )}
    </div>
  );
};

export default InstantSavings;
const MyBulletListLoader = () => <BulletList />;
