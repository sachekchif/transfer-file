import React, {useState} from "react";
import { Link } from "react-router-dom";
import { TabItem,DirectorInfoTab,DirectorDocumentsTab } from "../../components";
import { useSelector, useDispatch } from "react-redux";



const tabs = [
  {
    id: "first",
    target: "#director",
    icon: "fas fa-list-ul me-3",
    text: "Director Information",
  },
  {
    id: "second",
    target: "#documents",
    icon: "bi bi-files-alt me-3",
    text: " Director Documents",
  }
  
];

const DirectorDetails = () => {
    const [detail, setDetail] = useState("first");
    const  {data} = useSelector((state)=> state.getCorporateDir)

  return (
    <div>
      <div className="row mb-3 mt-5">
        <Link to="/corporate-details/:id"
        
        >
          <div className="mb-3 d-flex">
            <div className="me-3">
              <i className="fas fa-arrow-left text-secondary"></i>
            </div>
            <p className="text-secondary">
              Back to <span>Company's Profile</span>
            </p>
          </div>
        </Link>

        <div className="mb-3">
          <h4>
            <strong>{data.directorName}</strong>
          </h4>
          <div className="d-flex text-primary">
            <label className="me-1">Managing Director</label>
          </div>
        </div>
      </div>
      <div className="row mb-5">
        <div className="col-lg-12 col-md-12 col-sm-12">
            <div className="card border-secondary-subtle mb-3">
                <div className="card-body">
                <ul className="nav nav-tabs" id="myTab" role="tablist">
                {tabs.map((tab) => (
                  <TabItem
                    key={tab.id}
                    active={detail === tab.id}
                    onClick={() => setDetail(tab.id)}
                    {...tab}
                  />
                ))}
              </ul>
              <div className="tab-content p-3">
                    {detail === "first" && (
                        <DirectorInfoTab />
                    )}
                    {detail === "second" && (
                        <DirectorDocumentsTab />
                    )}
    
                  </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default DirectorDetails;
