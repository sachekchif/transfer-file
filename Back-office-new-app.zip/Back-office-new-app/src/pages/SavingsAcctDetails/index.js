import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  CustomerInfoTab,
  CustomerDocTab,
  TabItem,
} from "../../components";
import { useSelector, useDispatch } from "react-redux";
import { fetchSavings } from "../../services/savingsAcct/savingsSlice";
import { rejectSavings } from "../../services/savingsAcct/rejectSlice";
import { approveSavings } from "../../services/savingsAcct/approveSlice";
import { Link,useNavigate } from "react-router-dom";
import { fetchSingleSavings } from "../../services/savingsAcct/getSavingsByIdSlice";
import { BulletList } from "react-content-loader";
import { preApproveSavings } from "../../services/savingsAcct/preApproveSlice";
import loader from "../../assets/images/loader.gif";

const SavingsAcctDetails = () => {
  const [staffId, setStaffId]  = useState('')
 const [staffRoleDetails, setStaffRoleDetails] = useState([])
 const user = JSON.parse(localStorage.getItem('user'))
  const dispatch = useDispatch();


  const { loading, data, error } = useSelector((state) => state.singleSavings);
 
  const [detail, setDetail] = useState("first");
  const { id } = useParams();
  console.log({data})
 
  

  
  const navigate = useNavigate();

  const handlePreApprove = () => {
    dispatch(preApproveSavings( {id, staffId,navigate}));
  };
  const handleApprove = () => {
    dispatch(approveSavings( {id, staffId,navigate}));
  };

 
  const handleReject =()=>{
    dispatch(rejectSavings({staffId,id,navigate}))
  }
  useEffect(()=>{
    setStaffId(user.staffId)
    setStaffRoleDetails(user.permissionDetails
     )
    },[])

  useEffect(() => {
    dispatch(fetchSavings(staffId));
  }, []);
  const staffRoleName= staffRoleDetails[2]
  const staffRole =staffRoleName?.roleName
  
  useEffect(() => {
    dispatch(fetchSingleSavings({ staffId, id }));
  }, []);

  const tabs = [
    {
      id: "first",
      target: "#timeline",
      icon: "fas fa-list-ul me-3",
      text: "Customer Information",
    },
    {
      id: "second",
      target: "#documents",
      icon: "bi bi-files-alt me-3",
      text: "Customer Documents",
    },
  ];
  return (
    <div>
       {loading ? (
        <MyBulletListLoader />
      ) : (
    <div>
      <div className="row mb-3 mt-5">
        <a href="savings.html">
          <div className="mb-3 d-flex">
            <div className="me-3">
              <i className="fas fa-arrow-left text-secondary"></i>
            </div>
            <Link to="/savings-account" className="text-secondary">
              Back to <span>Savings Accounts</span>
            </Link>
          </div>
        </a>

        <div className="mb-3">
          <h4>
            <strong>{data.fullName}</strong>
          </h4>
          <div className="d-flex text-primary">
            <label className="me-2">BVN :</label>
            <label>{data.bvn}</label>
          </div>
        </div>
      </div>

      <div className="row mb-5">
        <div className="col-lg-12 col-md-12 col-sm-12">
          <div className="card border-secondary-subtle mb-3">
            <div className="card-body">
              <ul className="nav nav-tabs" id="myTab" role="tablist">
                {tabs.map((tab) => (
                  <TabItem
                    key={tab.id}
                    active={detail === tab.id}
                    onClick={() => setDetail(tab.id)}
                    {...tab}
                  />
                ))}
              </ul>

              <div className="tab-content p-3">
                {detail == "first" && <CustomerInfoTab user={data} />}
                {detail == "second" && <CustomerDocTab user={data} />}
              </div>

              <div className="d-flex align-items-center justify-content-center mb-5 mt-5">
                    
                    {(staffRole === 'INITIATOR' && (data.status !== 'SUCCESSFUL' && data.status !== 'APPROVED' && data.status !== 'REJECTED')  )  &&(
                      <button
                      type="button"
                      class="btn btn-success me-5 col-lg-3 col-md-5 col-sm-12"
                      onClick={handlePreApprove}
                    >
                     {loading ? <img src={loader} height={20} width={20}/> : "Pre Approve"}
                    </button>
                    )}
                    {(staffRole === 'SUPER ADMIN' && (data.status !== 'SUCCESSFUL' && data.status !== 'APPROVED' && data.status !== 'REJECTED')  )  &&(
                      <button
                      type="button"
                      class="btn btn-success me-5 col-lg-3 col-md-5 col-sm-12"
                      onClick={handleApprove}
                    >
                     {loading ? <img src={loader} height={20} width={20}/> : "Approve"}
                    </button>
                    )}
                     
                    {(data.status  !== 'APPROVED' && data.status !== 'SUCCESSFUL' && data.status !== 'REJECTED') && (
                      <button
                      type="button"
                      class="btn btn-danger col-lg-3 col-md-5 col-sm-12"
                      onClick={handleReject}
                    >
                      Reject
                    </button>
                    )}
                    
                  </div>
             
            </div>
          </div>
        </div>
      </div>
    </div>
     )}
    </div>
  );
};

export default SavingsAcctDetails;
const MyBulletListLoader = () => <BulletList />;
