import React from "react";
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useSelector } from "react-redux";



const token = localStorage.getItem('user');
// console.log('Current pathname:', location.pathname); 


  
export const ProtectedRoutes = ({children}) => {
    const  {isAuthenticated} = useSelector((state)=> state.login)
    const isLoggedIn = !!isAuthenticated;
    const location = useLocation();
    const path = location.pathname
    if(!isLoggedIn && !path.endsWith('/login')){
      return(
        <Navigate to="/login"
        state={{from: location}}
        replace
         />
       
      )
    }else if(isLoggedIn && path.endsWith('/login')){
      return(
        <Navigate
        to="/"
        state={{from: location}} 
        replace
        />
      )
    }


  return children;
}

