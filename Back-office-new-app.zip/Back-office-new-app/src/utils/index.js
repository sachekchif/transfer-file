
export const nearestThousand =(num)=>{
  if(num < 999){
    return num
  }
  
    return `${num/1000}k`
}

// export const baseUrl = 'http://10.11.200.98:7009/suntrust/vendor/api'
export const baseUrl = 'https://openapi.suntrustng.com/AccountOpeningPortalBE_API/api'
export const bankRanchUrl ="https://ubanking.suntrustng.com/AccountOpeningV2/api/v1/AccountOpening/GetBranch"

export const getDate =(dateString)=>{
    const dateTime = new Date(dateString);
  const year = dateTime.getFullYear();
  const month = (dateTime.getMonth() + 1).toString().padStart(2, '0');
  const day = dateTime.getDate().toString().padStart(2, '0');

  const extractedDate = `${year}-${month}-${day}`;
  return extractedDate;
  }

export const formatDob =(inputDate)=> {
    // Check if the inputDate is already in the desired format
    const regex = /^\d{2}-[A-Za-z]{3}-\d{4}$/;
    if (regex.test(inputDate)) {
      return inputDate; // Return the value as is if already in the format "DD-Mon-YYYY"
    }
  
    // Manually extract day, month, and year from the input date string
    const day = inputDate.slice(0, 2);
    const month = inputDate.slice(2, 4);
    const year = inputDate.slice(4);
  
    // Create a new Date object using the extracted values (Note: Months are 0-indexed in Date)
    const date = new Date(`${year}-${month}-${day}`);
  
    // Get the formatted day, month, and year from the date
    const formattedDay = String(date.getDate()).padStart(2, "0");
    const formattedMonth = date.toLocaleString("default", { month: "short" });
    const formattedYear = date.getFullYear();
  
    // Format the date in the desired format
    const formattedDate = `${formattedDay}-${formattedMonth}-${formattedYear}`;
  
    return formattedDate;
  }

 export const formatCurrency =(amount) => {
    const formatter = new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 2,
    });
  
    return formatter.format(amount);
  }

  export const calculateAge = (dateOfBirth)=>{
    const today = new Date();
    const birthDate = new Date(dateOfBirth);

    const yearsDiff = today.getFullYear() - birthDate.getFullYear();
    const monthsDiff = today.getMonth() - birthDate.getMonth();
    const daysDiff = today.getDate() - birthDate.getDate();

    if(yearsDiff < 1){
      return `${monthsDiff} months old`
    }
    // if(monthsDiff < 0 || (monthsDiff === 0 && daysDiff < 0)){
    //   yearsDiff--;
    // }
    return `${yearsDiff} years old`;
  }

 
 export const formatFullDate = (date) => {
      const splitDate = date.split(",");
      console.log(splitDate)
      const day = splitDate[0]
      const month = splitDate[1]
      const year = splitDate[splitDate.length - 1].trim().split(" ").slice()[0];
      
      return `${day}, ${month}, ${year}`
  }

  export const calculatePercentageIncrease = (current, previous)=>{
  const currentMonth = current.reduce((total, item)=> total + item.value, 0)
  const previousMonth = previous.reduce((total,item)=> total + item.value, 0)

  if(previousMonth === 0){
    return "N/A"
  }
  const percentageIncrease = ((currentMonth - previousMonth)/previousMonth ) * 100;
  return percentageIncrease.toFixed(2) + "%"
  }

  
  

  