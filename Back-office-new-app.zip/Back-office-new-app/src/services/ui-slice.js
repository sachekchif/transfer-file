import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { bankRanchUrl } from "../utils";
import Swal from "sweetalert2";



export const fetchBankBranches = createAsyncThunk(
    'user/bankBranches',
    async(data,{rejectWithValue})=>{
        try {
            const response = await axios.get(bankRanchUrl)
            console.log({response})
            return response.data
        } catch (error) {
            Swal.fire("Something Went Wrong!", "", "error");
            return rejectWithValue(error.response.data)
        }
    }
)

const uiSlice= createSlice({
    name:"ui",
    loading:false,
    error:null,
    branch:[],
    initialState:{drawerIsVisible: false,
        notification:null,
         selectedId:null,
         
        },
    reducers:{
        toggle(state, action){
            state.drawerIsVisible = !state.drawerIsVisible;
            state.selectedId = action.payload;
           
        },
    
        showNotification(state, action){
            state.notification={
                status: action.payload.status,
                title: action.payload.title,
                message: action.payload.message
            }
        }
    },
    extraReducers(builder){
        builder.addCase(fetchBankBranches.pending, (state, action)=>{
            state.loading = true;
        })

        // .addCase(fetchBankBranches.fulfilled, (state, action)=>{
        //     state.loading =false;
        //     state.branch =action.payload,
        //     state.error = null
        // })
        .addCase(fetchBankBranches.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload
        })
    }
})

export const uiActions = uiSlice.actions

export default uiSlice.reducer;