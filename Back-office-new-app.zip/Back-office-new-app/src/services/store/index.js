import { configureStore } from "@reduxjs/toolkit";
import uiReducer from '../ui-slice'
import savingsReducer from '../savingsAcct/savingsSlice'
import kiddiesReducer from '../kiddiesSavings/kiddiesSlice'
import instantReducer from '../instantSavings/instantSlice'
import savingsSingle from '../savingsAcct/getSavingsByIdSlice'
import approveSavingsReducer from "../savingsAcct/approveSlice";
import  rejectSavingsReducer from "../savingsAcct/rejectSlice";
import preApproveReducer from "../savingsAcct/preApproveSlice";
import corporateReducer from "../corporateSavings/corporateSlice";
import corporateSingleReducer from "../corporateSavings/getCorporateByIdSlice";
import approveCorporateReducer from "../corporateSavings/approveCorporateSlice";
import rejectCorporateReducer from "../corporateSavings/rejectCorporateSlice";
import currentReducer from '../currentSavings/currentSlice';
import preApproveCurrent from '../currentSavings/preApproveSlice'
import CorporateSingleDir from '../corporateSavings/getDirDetailsSlice';
import preApproveCorporate from '../corporateSavings/pre-approveSlice'
import currentSingleReducer from '../currentSavings/getSingleCurrentById';
import approveCurrentReducer from "../currentSavings/approveCurrentSlice";
import rejectCurrentReducer from "../currentSavings/rejectCurrentSlice";
import kiddiesSingleReducer from '../kiddiesSavings/getSingleKiddiesSlice';
import approveKiddiesReducer from '../kiddiesSavings/approveSlice';
import rejectKiddiesReducer from '../kiddiesSavings/rejectSlice';
import customerDocumentReducer from '../corporateSavings/getCustomerDocSlice';
import loginReducer from '../Authentication/loginSlice';




const store =configureStore({
   reducer:{
    ui:uiReducer,
    instant:instantReducer,
    savings:savingsReducer,
    singleSavings:savingsSingle,
    getAllCorporate:corporateReducer,
    kiddies:kiddiesReducer,
    approveSavings:approveSavingsReducer,
    rejectSavings:rejectSavingsReducer,
    preApproveSavings:preApproveReducer,
    singleCorporate:corporateSingleReducer,
    approveCorporate:approveCorporateReducer,
    rejectCorperate:rejectCorporateReducer,
    getCorporateDir:CorporateSingleDir,
    corporatePreApprove:preApproveCorporate,
    currentAccount:currentReducer,
    preApproveCurrent:preApproveCurrent,
    getSingleCurrent:currentSingleReducer,
    approveCurrent:approveCurrentReducer,
    rejectCurrent:rejectCurrentReducer,
    getSingleKiddies:kiddiesSingleReducer,
    approveKiddies:approveKiddiesReducer,
    rejectKiddies:rejectKiddiesReducer,
    customerDoc:customerDocumentReducer,
    login:loginReducer
   } 
})

export default store