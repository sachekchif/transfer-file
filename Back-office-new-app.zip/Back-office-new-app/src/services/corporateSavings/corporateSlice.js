import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../utils";

const initialState ={
    loading:false,
    data:[],
    error:"",
    searchData:[],
}
export const fetchCorporateUsers = createAsyncThunk(
    'corporate/fetchUsers',
    async (  staffId, { rejectWithValue }) => {
      try {
        
        const response = await axios.post(`${baseUrl}/CoperateAccount/getAllCorperateAccount`,
         {
          staffId,
         
        });
  
        return response.data;
      } catch (error) {
        return rejectWithValue(error.response.data);
      }
    }
  );


const corporateSlice = createSlice({
    name: 'corporate',
    initialState,
    reducers: {
        searchCorporate:(state, action)=>{
        console.log(action.payload)
        state.searchData = action.payload
      },
    },
    extraReducers(builder) {
      builder
        .addCase(fetchCorporateUsers.pending, (state, action) => {
          state.loading = true;
        })
        .addCase(fetchCorporateUsers.fulfilled, (state, action) => {
          state.loading = false;
          state.data = action.payload;
          state.error = null;
        })
        .addCase(fetchCorporateUsers.rejected, (state, action) => {
          state.loading = false;
          state.users=[]
          state.error = action.payload;
        });
    },
  });

export default corporateSlice.reducer
export const {searchCorporate} = corporateSlice.actions