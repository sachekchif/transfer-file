import axios from 'axios';
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { baseUrl } from '../../utils';

const initialState = {
  loading: false,
  error: null,
  data: {},
};

export const fetchCustDoc = createAsyncThunk(
  'corporate/fetchCustDocument',
  async ({ id, staffId }, { rejectWithValue }) => {
    console.log("hit here")
    try {
        const response = await axios.post(
            `${baseUrl}/CoperateAccount/${id}/getIdImage`,
            { id, staffId }
          );
 
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const corporateSingleCustSlice = createSlice({
  name: 'singleCustDoc',
  initialState,
  reducers: {},
  extraReducers(builder) {
    builder
      .addCase(fetchCustDoc.pending, (state, action) => {
        state.loading = true;
      })
      .addCase(fetchCustDoc.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
        state.error = null;
      })
      .addCase(fetchCustDoc.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default corporateSingleCustSlice.reducer;
