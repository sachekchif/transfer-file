import axios from 'axios';
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { baseUrl } from '../../utils';

const initialState = {
  loading: false,
  error: null,
  data: {},
};

export const fetchSingleDir = createAsyncThunk(
  'corporate/fetchSingleDirector',
  async ({ id, staffId }, { rejectWithValue }) => {
    console.log("hit here")
    try {
        const response = await axios.post(
            `${baseUrl}/CoperateAccount/${id}/getByInfoId`,
            { id, staffId }
          );

      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const corporateSingleDirSlice = createSlice({
  name: 'singleDir',
  initialState,
  reducers: {},
  extraReducers(builder) {
    builder
      .addCase(fetchSingleDir.pending, (state, action) => {
        state.loading = true;
      })
      .addCase(fetchSingleDir.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
        state.error = null;
      })
      .addCase(fetchSingleDir.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default corporateSingleDirSlice.reducer;
