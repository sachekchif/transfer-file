import axios from 'axios';
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { baseUrl } from '../../utils';

const initialState = {
  loading: false,
  error: null,
  data: {},
};

export const fetchSingleCorporate = createAsyncThunk(
  'corporate/fetchSingleCorporate',
  async ({ id, staffId }, { rejectWithValue }) => {
    console.log("hit here")
    try {
        const response = await axios.post(
            `${baseUrl}/CoperateAccount/${id}`,
            { id, staffId }
          );

      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const corporateSingleSlice = createSlice({
  name: 'singleCorporate',
  initialState,
  reducers: {},
  extraReducers(builder) {
    builder
      .addCase(fetchSingleCorporate.pending, (state, action) => {
        state.loading = true;
      })
      .addCase(fetchSingleCorporate.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
        state.error = null;
      })
      .addCase(fetchSingleCorporate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default corporateSingleSlice.reducer;
