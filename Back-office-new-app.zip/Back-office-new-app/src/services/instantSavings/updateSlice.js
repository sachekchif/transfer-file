import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { baseUrl } from "../../utils";


const initialState = {
    loading:false,
    user:{},
    error:""
}

const updateUser = createAsyncThunk( "user/updateUser", async(data, {rejectWithValue})=>{

    const response = await fetch(`${baseUrl}/`,
    {
        method: "PUT",
        mode:"cors",
        headers:{
            "Content-Type": "application/json"
        },
        body:JSON.stringify(data)
    }
    )
    try {
        const result = await response.json();
        return result
    } catch (error) {
        return rejectWithValue(error)
    }

})

const updateSlice= createSlice({
    name:'user',
    initialState,
    extraReducers: builder =>{
        builder.addCase(updateUser.pending, state =>{
            state.loading=true   
        })
        builder.addCase(updateUser.fulfilled, (state, action)=>{
            state.loading =false
            state.user = action.payload
        })
        builder.addCase(updateUser.rejected, (state, action)=>{
            state.loading = false
            state.error = action.payload.message
        })
    }
})
 


export default updateSlice.reducer

