import axios from 'axios';
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { baseUrl } from '../../utils';

const initialState = {
  loading: false,
  error: null,
  data: [],
  searchData:[],
};

export const fetchUsers = createAsyncThunk(
  'user/fetchUsers',
  async (staffId, { rejectWithValue }) => {
    try {
      
      const response = await axios.post(`${baseUrl}/SavingsAccount/instant-savings`,
       {
        staffId,
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const userSlice = createSlice({
  name: 'allProducts',
  initialState,
  reducers: {
    searchUser:(state, action)=>{
      console.log(action.payload)
      state.searchData = action.payload
    },
  },
  extraReducers(builder) {
    builder
      .addCase(fetchUsers.pending, (state, action) => {
        state.loading = true;
      })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
        state.error = null;
      })
      .addCase(fetchUsers.rejected, (state, action) => {
        state.loading = false;
        state.users=[]
        state.error = action.payload;
      });
  },
});

export default userSlice.reducer;
export const {searchUser} = userSlice.actions;
