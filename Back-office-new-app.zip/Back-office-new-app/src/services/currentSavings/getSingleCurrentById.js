import axios from 'axios';
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { baseUrl } from '../../utils';

const initialState = {
  loading: false,
  error: null,
  data: {},
};

export const fetchSingleCurrent = createAsyncThunk(
  'current/fetchSingleCurrent',
  async ({ id, staffId }, { rejectWithValue }) => {
    console.log("hit here")
    try {
        const response = await axios.post(
            `${baseUrl}/CurrentAccount/${id}`,
            { id, staffId }
          );

      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const currentSingleSlice = createSlice({
  name: 'singleCurrent',
  initialState,
  reducers: {},
  extraReducers(builder) {
    builder
      .addCase(fetchSingleCurrent.pending, (state, action) => {
        state.loading = true;
      })
      .addCase(fetchSingleCurrent.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
        state.error = null;
      })
      .addCase(fetchSingleCurrent.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default currentSingleSlice.reducer;
