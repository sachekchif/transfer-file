import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import Swal from "sweetalert2";
import axios from "axios";
import { baseUrl } from "../../utils";

const initialState = {
  loading: false,
  user: {},
  error: "",
};

export const rejectCurrent = createAsyncThunk(
  "current/rejectCurrent",
  async ({ id, staffId, navigate }) => {
    try {
      const inputValue = await Swal.fire({
        title: "Input Value",
        input: "text",
        inputLabel: "Enter a value",
        showCancelButton: true,
        inputValidator: (value) => {
          if (!value) {
            return "Value cannot be empty";
          }
        },
      });

      if (inputValue.isConfirmed) {
        const response = await axios.post(
          `${baseUrl}/CurrentAccount/${id}/reject`,
          { id, staffId, inputValue: inputValue.value }
        );
            console.log({response})
        if (response.status === 200) {
            Swal.fire("Successful", "Successful!", "success").then((result)=>{
                navigate("/current-account")
            });
          return response.data;
        }
      } else {
        Swal.fire("Rejected", "Operation cancelled.", "error");
      }
    } catch (error) {
      if (error.response) {
        throw error.response.data;
      } else {
        throw error.message;
      }
    }
  }
);

const rejectCurrentSlice = createSlice({
  name: "current/reject",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(rejectCurrent.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(rejectCurrent.fulfilled, (state, action) => {
      state.loading = false;
      state.user = action.payload;
      state.error = "";
    });
    builder.addCase(rejectCurrent.rejected, (state, action) => {
      state.loading = false;
      state.user = {};
      state.error = action.error.message;
    });
  },
});

export default rejectCurrentSlice.reducer;
