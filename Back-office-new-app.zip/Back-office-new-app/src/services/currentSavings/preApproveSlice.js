import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import Swal from "sweetalert2";
import axios from "axios";
import { baseUrl } from "../../utils";

const initialState = {
  loading: false,
  user: {},
  error: "",
};
export const preApproveCurrent = createAsyncThunk(
    "corporate/pre-approveCurrent",
    async ({ id, staffId, navigate }) => {
      try {
        const swalResult = await Swal.fire({
          title: "Do you want to approve this request?",
        //   showDenyButton: true,
          showCancelButton: true,
          confirmButtonText: "Submit",
        });
  
        if (swalResult.isConfirmed) {
          const response = await axios.post(
            `${baseUrl}/CurrentAccount/${id}/preapprove`,
            { id, staffId }
          );
  
          if (response.status === 200) {
            Swal.fire("Successful", "Successful!", "success").then((result) => {
              navigate("/corporate-account");
            });
            return response.data;
          }
        
        } else {
          Swal.fire("Cancelled", "Operation cancelled.", "error");
        }
        
      } catch (e) {
        if (e.response) {
          throw e.response.data;
        } else {
          throw e.message;
        }
      }
    }
  );
  

const preApproveCurrentSLice = createSlice({
  name: "current/pre-approve",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(preApproveCurrent.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(preApproveCurrent.fulfilled, (state, action) => {
      state.loading = false;
      state.user = action.payload;
      state.error = "";
    });
    builder.addCase(preApproveCurrent.rejected, (state, action) => {
      state.loading = false;
      state.user = {};
      state.error = action.error.message;
    });
  },
});

export default preApproveCurrentSLice.reducer;
