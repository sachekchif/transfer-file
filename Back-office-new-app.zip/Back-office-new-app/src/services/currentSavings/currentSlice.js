import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { baseUrl } from "../../utils";
import axios from "axios";

const initialState ={
    loading:false,
    data:[],
    error:"",
    searchData:[],
}
export const fetchCurrentUsers = createAsyncThunk(
    'current/fetchCurrent',
    async (staffId, { rejectWithValue }) => {
      console.log('sta:',staffId)
      try {
        
        const response = await axios.post(`${baseUrl}/CurrentAccount/all`,
         {
          staffId,
        });
  
        return response.data;
      } catch (error) {
        return rejectWithValue(error.response.data);
      }
    }
  );

// export const fetchCurrentUsers = createAsyncThunk("current/fetchCurrent", async()=>{
//     const response = await fetch(
//         `${baseUrl}/CurrentAccount/all`,
//         {
//             method: "GET",
//             mode:"cors",
//             headers:{
//                 "Content-Type":"application/json"
               
//             }
//         }
//     );
//     console.log('current', response)
//     if(!response.ok){
//         throw new Error('Failed to fetch users')
//     }
//     const data = await response.json()
//     return data;
// })

const currentSlice=createSlice({
    name:"current",
    initialState,
    reducers: {
        searchCurrent:(state, action)=>{
        console.log(action.payload)
        state.searchData = action.payload
      },
    },
    extraReducers: builder =>{
        builder.addCase(fetchCurrentUsers.pending, state =>{
            state.loading = true
        })
    //     builder.addCase(fetchCurrentUsers.fulfilled, (state, action)=>{
    //         state.loading = false,
    //         state.data = action.payload,
    //         state.error=""
    // })
    builder.addCase(fetchCurrentUsers.rejected, (state, action)=>{
        state.loading = false
        state.data = []
        state.error = action.error.message
    })
    }
})

export default currentSlice.reducer
export const {searchCurrent} = currentSlice.actions