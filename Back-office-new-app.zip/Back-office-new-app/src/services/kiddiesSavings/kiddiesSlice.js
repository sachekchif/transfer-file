import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { baseUrl } from "../../utils";

const initialState ={
    loading:false,
    data:[],
    error:"",
    searchData:[],
}
export const fetchKiddiesUsers = createAsyncThunk(
    'kiddies/fetchUsers',
    async (staffId, { rejectWithValue }) => {
      try {
        
        const response = await axios.post(`${baseUrl}/KiddiesAccount/get-all-kiddies`,
         {
          staffId,
        });

        console.log({response})
  
        return response.data;
      } catch (error) {
        return rejectWithValue(error.response.data);
      }
    }
  );


const kiddiesSlice = createSlice({
    name: 'kiddies',
    initialState,
    reducers: {
        searchKiddies:(state, action)=>{
        console.log(action.payload)
        state.searchData = action.payload
      },
    },
    extraReducers(builder) {
      builder
        .addCase(fetchKiddiesUsers.pending, (state, action) => {
          state.loading = true;
        })
        .addCase(fetchKiddiesUsers.fulfilled, (state, action) => {
          state.loading = false;
          state.data = action.payload;
          state.error = null;
        })
        .addCase(fetchKiddiesUsers.rejected, (state, action) => {
          state.loading = false;
          state.users=[]
          state.error = action.payload;
        });
    },
  });

export default kiddiesSlice.reducer
export const {searchKiddies} = kiddiesSlice.actions