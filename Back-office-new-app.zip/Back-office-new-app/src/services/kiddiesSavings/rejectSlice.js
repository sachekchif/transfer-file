import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import Swal from "sweetalert2";
import axios from "axios";
import { baseUrl } from "../../utils";

const initialState = {
  loading: false,
  data: {},
  error: "",
};

export const rejectKiddies = createAsyncThunk(
  "kiddies/rejectKiddies",
  async ({ id, staffId, navigate }) => {
    try {
      const inputValue = await Swal.fire({
        title: "Input Value",
        input: "text",
        inputLabel: "Enter a value",
        showCancelButton: true,
        inputValidator: (value) => {
          if (!value) {
            return "Value cannot be empty";
          }
        },
      });

      if (inputValue.isConfirmed) {
        const response = await axios.post(
          `${baseUrl}/KiddiesAccount/${id}/reject`,
          { id, staffId, inputValue: inputValue.value }
        );
            console.log({response})
        if (response.status === 200) {
            Swal.fire("Successful", "Successful!", "success").then((result)=>{
                navigate("/kiddies-account")
            });
          return response.data;
        }
      } else {
        Swal.fire("Rejected", "Operation cancelled.", "error");
      }
    } catch (error) {
      if (error.response) {
        throw error.response.data;
      } else {
        throw error.message;
      }
    }
  }
);

const rejectKiddiesSlice = createSlice({
  name: "kiddies/reject",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(rejectKiddies.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(rejectKiddies.fulfilled, (state, action) => {
      state.loading = false;
      state.data = action.payload;
      state.error = "";
    });
    builder.addCase(rejectKiddies.rejected, (state, action) => {
      state.loading = false;
      state.data = {};
      state.error = action.error.message;
    });
  },
});

export default rejectKiddiesSlice.reducer;
