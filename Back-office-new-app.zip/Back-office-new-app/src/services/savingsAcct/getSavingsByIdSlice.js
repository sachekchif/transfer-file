import axios from 'axios';
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { baseUrl } from '../../utils';

const initialState = {
  loading: false,
  error: null,
  data: {},
};

export const fetchSingleSavings = createAsyncThunk(
  'savings/fetchSingleSavings',
  async ({ id, staffId }, { rejectWithValue }) => {
    console.log("hit here")
    try {
      const response = await axios.post(`${baseUrl}/SavingsAccount/${id}`, 
        { id, staffId }
      );

      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const savingsSingleSlice = createSlice({
  name: 'singleSavings',
  initialState,
  reducers: {},
  extraReducers(builder) {
    builder
      .addCase(fetchSingleSavings.pending, (state, action) => {
        state.loading = true;
      })
      .addCase(fetchSingleSavings.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
        state.error = null;
      })
      .addCase(fetchSingleSavings.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default savingsSingleSlice.reducer;
