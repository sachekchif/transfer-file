import axios from 'axios';
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { baseUrl } from '../../utils';

const initialState = {
  loading: false,
  error: null,
  data: [],
  searchData:[],
  branch: '',
};

export const fetchSavings = createAsyncThunk(
  'savings/fetchSavings',
  async (staffId, { rejectWithValue }) => {
    try {
      
      const response = await axios.post(`${baseUrl}/SavingsAccount/savings`,
       {
        staffId,
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

const savingsSlice = createSlice({
  name: 'allSavings',
  initialState,
  reducers: {
    searchSavings:(state, action)=>{
    //   console.log(action.payload)
      state.searchData = action.payload
    },
  },
  extraReducers(builder) {
    builder
      .addCase(fetchSavings.pending, (state, action) => {
        state.loading = true;
      })
      .addCase(fetchSavings.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
        state.error = null;
      })
      .addCase(fetchSavings.rejected, (state, action) => {
        state.loading = false;
        // state.users=[]
        state.error = action.payload;
      });
  },
});

export default savingsSlice.reducer
export const {searchSavings} = savingsSlice.actions;

