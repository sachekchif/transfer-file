import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import Swal from "sweetalert2";
import axios from "axios";
import { baseUrl } from "../../utils";
import { fetchSavings } from "./savingsSlice";
import { useNavigate } from "react-router-dom";

const initialState = {
  loading: false,
  user: {},
  error: "",
};
export const approveSavings = createAsyncThunk(
    "savings/approveSavings",
    async ({ id, staffId, navigate }) => {
      try {
        const swalResult = await Swal.fire({
          title: "Do you want to approve this request?",
        //   showDenyButton: true,
          showCancelButton: true,
          confirmButtonText: "Submit",
        });
  
        if (swalResult.isConfirmed) {
          const response = await axios.post(
            `${baseUrl}/SavingsAccount/approve/${id}`,
            { id, staffId }
          );
  
          if (response.status === 200) {
            Swal.fire("Successful", "Successful!", "success").then((result) => {
              navigate("/savings-account");
            });
            return response.data;
          }
        
        } else {
          Swal.fire("Cancelled", "Operation cancelled.", "error");
        }
        
      } catch (e) {
        if (e.response) {
          throw e.response.data;
        } else {
          throw e.message;
        }
      }
    }
  );
  

const approveSavingsSLice = createSlice({
  name: "savings/approve",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(approveSavings.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(approveSavings.fulfilled, (state, action) => {
      state.loading = false;
      state.user = action.payload;
      state.error = "";
    });
    builder.addCase(approveSavings.rejected, (state, action) => {
      state.loading = false;
      state.user = {};
      state.error = action.error.message;
    });
  },
});

export default approveSavingsSLice.reducer;
