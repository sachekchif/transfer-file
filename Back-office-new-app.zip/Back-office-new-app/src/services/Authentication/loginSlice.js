import { createSlice, createAsyncThunk} from "@reduxjs/toolkit";
import Swal from "sweetalert2";
import { baseUrl } from "../../utils";



const userFromStorage = localStorage.getItem('user');
const isAuthenticatedFromStorage = userFromStorage ? true : false;
console.log({isAuthenticatedFromStorage})
export const  LoginUser = createAsyncThunk(
  "loginUser",
  async (data, {rejectWithValue} ) => {
    const { navigate, dispatch, ...rest } = data;
    try {
      const response = await fetch( `${baseUrl}/Home/login`,    {
        method:"POST",
        mode:'cors',
        headers:{
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data),
    })

    console.log({response})
     
      if (!response.ok) {
        Swal.fire({
          title: "Oops",
          text: "Invalid Login Credentials",
          icon: "error",
        }).then((result) => {});
      } else {
        const resData = await response.json();
          console.log({resData})
        let user = resData.status;

        if (resData.statuscode === '00') {
          // delete data.password;
          localStorage.setItem("user", JSON.stringify(resData));
          dispatch(login())
          navigate("/");

        }
      }
      return response.ok ? data : rejectWithValue("Invalid login credentials");
    } catch (e) {
      console.log({e})
      if (e) {
        Swal.fire({
          title: "Oops",
          text: "Something went wrong, please try again",
          icon: "error",
        }).then((result) => {
          
        });
      }
      return rejectWithValue(e.response.data);
    }
  }
);

const initialState = {
  isAuthenticated: isAuthenticatedFromStorage,
  error: "",
  error2: "",
  isSuccessful: false,
  loading: false,
 
} ;

const loginSlice = createSlice({
  name: "login",
  initialState,
  reducers: {
    login: (state) => {
      state.isAuthenticated = true;
    },
    logout: (state) => {
      state.isAuthenticated = false;
    },
  },
  extraReducers(builder) {
    builder
      .addCase(LoginUser.pending, (state, action) => {
        state.loading = true;
      })
      .addCase(
        LoginUser.fulfilled,
        (state, action) => {
          state.loading = false;
          state.response = action.payload;
          state.error = "";
           state.isSuccessful = true;
        }
      )
      .addCase(LoginUser.rejected, (state, action) => {
        state.error = action.payload;
        state.loading = false;
        state.isSuccessful = false;
      });
  },
});

export default loginSlice.reducer;
export const { logout,login } = loginSlice.actions;
