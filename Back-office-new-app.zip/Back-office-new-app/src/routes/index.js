import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Test from "../pages/test";
import {
  Dashboard,
  CorporateAccount,
  InstantSavings,
  KiddiesAccount,
  SavingsAccount,
  CurrentAccount,
  SavingsAcctDetails,
  CurrentAcctDetails,
  CorporateAccountDetails,
  DirectorDetails,
  KiddiesAcctDetails,
  KiddiesGuardianDetails,
  LoginPage,
} from "../pages";
import { ProtectedRoutes,ProtectLogin } from "../utils/protectedRoutes";
import { Sidebar } from "../components";

const RouteComponent = () => {
  const location = useLocation();

  const renderSidebar = location.pathname !== "/login";

  return (
    <div>
      <div>
        {renderSidebar && <Sidebar />}
        <div className={`${renderSidebar ? "right-panel p-3" : null} `}>
          <Routes>
            <Route exact path="/"
             element={
              <ProtectedRoutes>
             <Dashboard />
             </ProtectedRoutes>
            } 
             />
            <Route exact path="/login"
             element={
              <ProtectedRoutes>
              <LoginPage />   
            </ProtectedRoutes>
            }
              />
            <Route
              path="/instant-savings"
              element={
                <ProtectedRoutes>
                  <InstantSavings />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/savings-account"
              element={
                <ProtectedRoutes>
                  <SavingsAccount />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/corporate-account"
              element={
                <ProtectedRoutes>
                  <CorporateAccount />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/kiddies-account"
              element={
                <ProtectedRoutes>
                  <KiddiesAccount />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/corporate-account"
              element={
                <ProtectedRoutes>
                  <CorporateAccount />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/current-account"
              element={
                <ProtectedRoutes>
                  <CurrentAccount />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/savings-details/:id"
              element={
                <ProtectedRoutes>
                  <SavingsAcctDetails />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/current-details/:id"
              element={
                <ProtectedRoutes>
                  <CurrentAcctDetails />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/corporate-details/:id"
              element={
                <ProtectedRoutes>
                  <CorporateAccountDetails />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/corporate-details-dir/:id"
              element={
                <ProtectedRoutes>
                  <DirectorDetails />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/kiddies-details/:id"
              element={
                <ProtectedRoutes>
                  <KiddiesAcctDetails />
                </ProtectedRoutes>
              }
            />
            <Route
              path="/kiddies-guardian/:id"
              element={
                <ProtectedRoutes>
                  <KiddiesGuardianDetails />
                </ProtectedRoutes>
              }
            />
            {/* <Route path="/test" element={<Test />} /> */}
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default RouteComponent;
