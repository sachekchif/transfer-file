const sampleData = [
  {
    id: 1,
    name: "John",
    age: 30,
    hobbies: [
      {dicId:'adfdsdb', docNumber:1, docType:'Word'},
      {dicId:'jghhk', docNumber:2, docType:'Pdf'}
   ],
  },
  {
    id: 2,
    name: "Alice",
    age: 25,
    hobbies: [
      {dicId:'hgidhfhl', docNumber:1, docType:'Word'},
      {dicId:'sdfi', docNumber:2, docType:'Pdf'}
   ],
  },
  {
    id: 3,
    name: "Bob",
    age: 35,
    hobbies: [
      {dicId:'jgskgd', docNumber:1, docType:'Word'},
      {dicId:'gkiif', docNumber:2, docType:'Pdf'}
   ],
  },
];
